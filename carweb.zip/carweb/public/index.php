<?php
declare(strict_types=1);

// Procura o núcleo da aplicação: normalmente em ../app (estrutura padrão), mas também em ./app,
// caso o conteúdo de public/ tenha sido copiado direto para a pasta do projeto.
$bootstrap = is_file(__DIR__ . '/../app/core/bootstrap.php') ? __DIR__ . '/../app/core/bootstrap.php' : __DIR__ . '/app/core/bootstrap.php';
if (!is_file($bootstrap)) {
    http_response_code(500);
    exit('CarWeb: pasta "app" não encontrada. Copie o projeto inteiro (com as pastas app, public e database) para htdocs/carweb.');
}
require $bootstrap;

// Com "php -S", entrega diretamente os arquivos estáticos (css, js, imagens).
if (PHP_SAPI === 'cli-server') {
    $arquivo = __DIR__ . (parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) ?: '/');
    if (is_file($arquivo) && basename($arquivo) !== 'index.php') {
        return false;
    }
}

enviar_cabecalhos_seguranca();
Auth::iniciar();

$r = new Router();

// Páginas públicas
$r->get('/',                      fn() => PaginaController::inicio());
$r->get('/buscar',                fn() => PaginaController::buscar());
$r->get('/alugar',                fn() => VeiculoController::listar('locacao'));
$r->get('/comprar',               fn() => VeiculoController::listar('venda'));
$r->get('/ofertas',               fn() => VeiculoController::ofertas());
$r->get('/diagnostico',           fn() => DiagnosticoController::mostrar());   // só em localhost
$r->get('/ajuda',                 fn() => PaginaController::ajuda());
$r->get('/veiculo/{id}',          fn(int $id) => VeiculoController::mostrar($id));

// Conta
$r->get('/entrar',                fn() => AuthController::formLogin());
$r->post('/entrar',               fn() => AuthController::login());
$r->get('/cadastro',              fn() => AuthController::formCadastro());
$r->post('/cadastro',             fn() => AuthController::cadastrar());
$r->post('/sair',                 fn() => AuthController::sair());

// Cadastro de veículos em lote (XML)
$r->get('/veiculos/importar',     fn() => ImportacaoController::formulario());
$r->get('/veiculos/modelo',       fn() => ImportacaoController::modelo());
$r->post('/veiculos/importar',    fn() => ImportacaoController::importar());

// Minha conta e favoritos
$r->get('/minha-conta',           fn() => ContaController::formulario());
$r->post('/minha-conta',          fn() => ContaController::salvarDados());
$r->post('/minha-conta/senha',    fn() => ContaController::trocarSenha());
$r->get('/favoritos',             fn() => ContaController::favoritos());
$r->post('/veiculo/{id}/favorito', fn(int $id) => ContaController::alternarFavorito($id));

// Cliente: locação e interesse
$r->post('/veiculo/{id}/reservar', fn(int $id) => ReservaController::reservar($id));
$r->post('/veiculo/{id}/interesse', fn(int $id) => ReservaController::interesse($id));
$r->get('/minhas-reservas',       fn() => ReservaController::minhas());
$r->post('/reserva/{id}/cancelar', fn(int $id) => ReservaController::cancelar($id));

// Anunciante
$r->get('/vender',                fn() => VeiculoController::formNovo());
$r->get('/veiculo/novo',          fn() => VeiculoController::formNovo());
$r->post('/veiculo/novo',         fn() => VeiculoController::criar());
$r->get('/meus-veiculos',         fn() => VeiculoController::meus());
$r->get('/veiculo/{id}/editar',   fn(int $id) => VeiculoController::formEditar($id));
$r->post('/veiculo/{id}/editar',  fn(int $id) => VeiculoController::atualizar($id));
$r->post('/veiculo/{id}/inativar', fn(int $id) => VeiculoController::inativar($id));
$r->get('/solicitacoes',          fn() => ReservaController::solicitacoes());
$r->post('/reserva/{id}/status',  fn(int $id) => ReservaController::atualizarStatus($id));

// Administrador
$r->get('/admin',                 fn() => AdminController::painel());
$r->get('/admin/usuarios',        fn() => AdminController::usuarios());
$r->post('/admin/usuarios/{id}/perfil', fn(int $id) => AdminController::definirPerfil($id));
$r->post('/admin/usuarios/{id}/ativo',  fn(int $id) => AdminController::alternarAtivo($id));
$r->get('/admin/veiculos',        fn() => AdminController::veiculos());

$r->executar($_SERVER['REQUEST_METHOD'] ?? 'GET', rota_atual());
