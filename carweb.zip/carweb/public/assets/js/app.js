(function () {
  'use strict';
  // Confirmação antes de ações destrutivas (formulários com data-confirmar).
  document.querySelectorAll('form[data-confirmar]').forEach(function (f) {
    f.addEventListener('submit', function (ev) {
      if (!window.confirm(f.getAttribute('data-confirmar'))) { ev.preventDefault(); }
    });
  });

  // Estimativa do valor da locação (o valor oficial é sempre recalculado no servidor).
  var form = document.getElementById('form-reserva');
  var out = document.getElementById('estimativa');
  if (form && out) {
    var diaria = parseFloat(form.getAttribute('data-diaria') || '0');
    var hora = parseFloat(form.getAttribute('data-hora') || '0');
    var moeda = function (v) { return v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }); };
    var modo = function () { var r = form.elements['modalidade']; return r && r.value === 'hora' ? 'hora' : 'dia'; };
    var atualizar = function () {
      if (modo() === 'hora') {
        var d = form.elements['data_hora'], h = parseInt(form.elements['hora_inicio'].value, 10), n = parseInt(form.elements['horas'].value, 10);
        if (!d.value) { out.textContent = 'Escolha a data para ver a estimativa.'; return; }
        if (h + n > 24) { out.textContent = 'A locação por hora deve terminar até as 24h do mesmo dia.'; return; }
        out.textContent = n + (n === 1 ? ' hora' : ' horas') + ' (' + ('0' + h).slice(-2) + 'h às ' + (h + n) + 'h) · estimativa: ' + moeda(n * hora);
        return;
      }
      var ini = form.elements['retirada'], fim = form.elements['devolucao'];
      if (!ini.value || !fim.value) { out.textContent = 'Escolha as datas para ver a estimativa.'; return; }
      var dias = Math.round((new Date(fim.value) - new Date(ini.value)) / 86400000);
      if (isNaN(dias) || dias < 1) { out.textContent = 'A devolução deve ser posterior à retirada.'; return; }
      out.textContent = dias + (dias === 1 ? ' dia' : ' dias') + ' · estimativa: ' + moeda(dias * diaria);
      fim.min = ini.value;
    };
    form.addEventListener('change', atualizar);
    atualizar();
  }
})();

// Carrossel de fotos do veículo: setas, miniaturas, teclado e deslizar (a faixa também rola sem JavaScript).
(function () {
  'use strict';
  document.querySelectorAll('[data-carrossel]').forEach(function (c) {
    var faixa = c.querySelector('.carrossel__faixa');
    var minis = c.querySelectorAll('.carrossel__mini');
    var atual = c.querySelector('[data-atual]');
    var total = faixa.children.length;
    var indice = function () { return Math.max(0, Math.min(total - 1, Math.round(faixa.scrollLeft / faixa.clientWidth))); };
    var ir = function (i) { i = (i + total) % total; faixa.scrollTo({ left: i * faixa.clientWidth, behavior: 'smooth' }); };
    var marcar = function () {
      var i = indice();
      if (atual) { atual.textContent = String(i + 1); }
      minis.forEach(function (m, k) { m.classList.toggle('ativa', k === i); });
    };
    c.querySelectorAll('[data-dir]').forEach(function (b) {
      b.addEventListener('click', function () { ir(indice() + parseInt(b.getAttribute('data-dir'), 10)); });
    });
    minis.forEach(function (m) { m.addEventListener('click', function () { ir(parseInt(m.getAttribute('data-ir'), 10)); }); });
    c.addEventListener('keydown', function (ev) {
      if (ev.key === 'ArrowLeft') { ev.preventDefault(); ir(indice() - 1); }
      if (ev.key === 'ArrowRight') { ev.preventDefault(); ir(indice() + 1); }
    });
    faixa.addEventListener('scroll', function () { window.requestAnimationFrame(marcar); });
  });
})();
