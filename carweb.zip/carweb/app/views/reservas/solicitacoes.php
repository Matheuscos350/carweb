<?php
/** @var array $reservas @var array $interesses */
$acoes = ['pendente' => ['confirmada' => 'Confirmar', 'cancelada' => 'Recusar'], 'confirmada' => ['concluida' => 'Concluir', 'cancelada' => 'Cancelar']];
?>
<h1>Solicitações recebidas</h1>
<h2 class="titulo-secao">Locações</h2>
<?php if (!$reservas): ?>
    <p class="vazio">Nenhuma solicitação de locação.</p>
<?php else: ?>
    <table class="tabela">
        <thead><tr><th>Veículo</th><th>Cliente</th><th>Período</th><th>Valor</th><th>Situação</th><th>Ações</th></tr></thead>
        <tbody>
        <?php foreach ($reservas as $r): ?>
            <tr>
                <td><?= e($r['marca'] . ' ' . $r['modelo']) ?></td>
                <td><?= e($r['nome_locatario']) ?><br><small><?= e($r['cliente_email']) ?> · <?= e($r['cliente_telefone'] ?? 'sem telefone') ?></small><br>
                    <small><?= e(strtoupper($r['tipo_documento'])) ?> <?= e(Dominio::mascararDocumento($r['documento'], $r['tipo_documento'])) ?></small></td>
                <td><?= e(periodo_br($r)) ?><br><small><?= e(Dominio::MODALIDADES[$r['modalidade']] ?? '') ?></small></td>
                <td><?= e(brl((float) $r['valor_total'])) ?></td>
                <td><span class="status status--<?= e($r['status']) ?>"><?= e(ucfirst($r['status'])) ?></span></td>
                <td class="acoes-linha">
                    <?php foreach ($acoes[$r['status']] ?? [] as $novo => $rotulo): ?>
                        <form method="post" action="<?= e(url('/reserva/' . $r['id'] . '/status')) ?>">
                            <?= Csrf::campo() ?>
                            <input type="hidden" name="status" value="<?= e($novo) ?>">
                            <button class="link" type="submit"><?= e($rotulo) ?></button>
                        </form>
                    <?php endforeach; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>

<h2 class="titulo-secao">Interessados em compra</h2>
<?php if (!$interesses): ?>
    <p class="vazio">Nenhum interessado ainda.</p>
<?php else: ?>
    <table class="tabela">
        <thead><tr><th>Veículo</th><th>Interessado</th><th>Contato</th><th>Mensagem</th><th>Data</th></tr></thead>
        <tbody>
        <?php foreach ($interesses as $i): ?>
            <tr>
                <td><?= e($i['marca'] . ' ' . $i['modelo']) ?></td>
                <td><?= e($i['cliente_nome']) ?></td>
                <td><?= e($i['cliente_email']) ?><br><small><?= e($i['cliente_telefone'] ?? 'sem telefone') ?></small></td>
                <td><?= e($i['mensagem'] ?? '—') ?></td>
                <td><?= e(date('d/m/Y', strtotime($i['criado_em']))) ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>
