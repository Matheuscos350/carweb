<?php /** @var array $reservas @var array $interesses */ ?>
<h1>Minhas reservas</h1>
<?php if (!$reservas): ?>
    <p class="vazio">Você ainda não fez nenhuma reserva. <a href="<?= e(url('/alugar')) ?>">Ver veículos para alugar</a>.</p>
<?php else: ?>
    <table class="tabela">
        <thead><tr><th>Veículo</th><th>Período</th><th>Valor</th><th>Documento</th><th>Situação</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($reservas as $r): ?>
            <tr>
                <td><a href="<?= e(url('/veiculo/' . $r['veiculo_id'])) ?>"><?= e($r['marca'] . ' ' . $r['modelo']) ?></a></td>
                <td><?= e(periodo_br($r)) ?><br><small><?= e(Dominio::MODALIDADES[$r['modalidade']] ?? '') ?></small></td>
                <td><?= e(brl((float) $r['valor_total'])) ?></td>
                <td><?= e(strtoupper($r['tipo_documento'])) ?> <?= e(Dominio::mascararDocumento($r['documento'], $r['tipo_documento'])) ?></td>
                <td><span class="status status--<?= e($r['status']) ?>"><?= e(ucfirst($r['status'])) ?></span></td>
                <td>
                    <?php if (in_array($r['status'], ['pendente', 'confirmada'], true) && $r['data_retirada'] >= date('Y-m-d')): ?>
                        <form method="post" action="<?= e(url('/reserva/' . $r['id'] . '/cancelar')) ?>" data-confirmar="Cancelar esta reserva?">
                            <?= Csrf::campo() ?>
                            <button class="link" type="submit">Cancelar</button>
                        </form>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>

<h2 class="titulo-secao">Meus interesses de compra</h2>
<?php if (!$interesses): ?>
    <p class="vazio">Nenhum interesse registrado.</p>
<?php else: ?>
    <table class="tabela">
        <thead><tr><th>Veículo</th><th>Preço</th><th>Mensagem</th><th>Data</th></tr></thead>
        <tbody>
        <?php foreach ($interesses as $i): ?>
            <tr>
                <td><a href="<?= e(url('/veiculo/' . $i['veiculo_id'])) ?>"><?= e($i['marca'] . ' ' . $i['modelo']) ?></a></td>
                <td><?= e(brl((float) $i['preco'])) ?></td>
                <td><?= e($i['mensagem'] ?? '—') ?></td>
                <td><?= e(date('d/m/Y', strtotime($i['criado_em']))) ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>
