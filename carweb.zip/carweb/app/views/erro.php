<?php /** @var int $codigo @var string $mensagem */ ?>
<section class="caixa-centro">
    <h1>Erro <?= e($codigo) ?></h1>
    <p><?= e($mensagem) ?></p>
    <?php if (!empty($detalhe)): ?><p class="aviso aviso--erro"><strong>Detalhe técnico (só aparece em localhost):</strong><br><code><?= e($detalhe) ?></code></p><?php endif; ?>
    <a class="btn btn--azul" href="<?= e(url('/')) ?>">Voltar ao início</a>
</section>
