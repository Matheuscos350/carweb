<?php /** @var array $u */ ?>
<h1>Minha conta</h1>
<div class="duas-cartoes">
    <form class="form" method="post" action="<?= e(url('/minha-conta')) ?>">
        <?= Csrf::campo() ?>
        <h2>Dados pessoais</h2>
        <p class="ajuda-texto">Tipo de conta: <strong><?= e(Dominio::PERFIS[$u['perfil']]) ?></strong> · E-mail: <?= e($u['email']) ?></p>
        <label>Nome completo <input type="text" name="nome" required maxlength="120" value="<?= e($u['nome']) ?>"></label>
        <label>Telefone (com DDD) <input type="tel" name="telefone" maxlength="20" value="<?= e($u['telefone'] ?? '') ?>"></label>
        <button class="btn btn--azul" type="submit">Salvar dados</button>
    </form>
    <form class="form" method="post" action="<?= e(url('/minha-conta/senha')) ?>">
        <?= Csrf::campo() ?>
        <h2>Alterar senha</h2>
        <label>Senha atual <input type="password" name="senha_atual" required maxlength="72" autocomplete="current-password"></label>
        <label>Nova senha <input type="password" name="senha_nova" required minlength="8" maxlength="72" autocomplete="new-password"></label>
        <label>Confirmar nova senha <input type="password" name="senha_nova2" required maxlength="72" autocomplete="new-password"></label>
        <p class="ajuda-texto">De 8 a 72 caracteres, com pelo menos uma letra e um número.</p>
        <button class="btn btn--azul" type="submit">Alterar senha</button>
    </form>
</div>
