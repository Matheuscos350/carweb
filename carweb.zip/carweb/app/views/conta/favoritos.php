<?php /** @var array $itens */ ?>
<h1>Meus favoritos</h1>
<?php if (!$itens): ?>
    <p class="vazio">Você ainda não favoritou nenhum veículo. Toque no coração de um anúncio para salvá-lo aqui.<br>
        <a href="<?= e(url('/comprar')) ?>">Ver veículos à venda</a> · <a href="<?= e(url('/alugar')) ?>">Ver veículos para alugar</a></p>
<?php else: ?>
    <div class="grade"><?php foreach ($itens as $v) { View::parcial('card', ['v' => $v]); } ?></div>
<?php endif; ?>
