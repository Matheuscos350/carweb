<?php
/** @var string $conteudo @var string $titulo */
$u = Auth::usuario();
$atual = rota_atual();
// Anunciantes e lojas só anunciam: sem "Alugar" no menu nem "Minhas reservas". Visitantes e compradores veem tudo.
$podeAlugar = $u === null || Auth::pode('solicitar_locacao');
$ativo = fn(string ...$prefixos): string => array_filter($prefixos, fn($p) => str_starts_with($atual, $p)) ? ' ativo' : '';
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="CarWeb: compre, venda e alugue carros novos e seminovos em um só lugar.">
    <title><?= e($titulo ? $titulo . ' · CarWeb' : 'CarWeb · Compre, venda e alugue carros') ?></title>
    <link rel="stylesheet" href="<?= e(url('assets/css/app.css')) ?>">
</head>
<body>
<a class="pular" href="#conteudo">Pular para o conteúdo</a>
<header class="topo">
    <div class="wrap topo__in">
        <a class="marca" href="<?= e(url('/')) ?>">
            <span class="marca__logo" aria-hidden="true">C</span>
            <span class="marca__texto"><strong>CarWeb</strong><small>Carros novos e seminovos</small></span>
        </a>
        <input type="checkbox" id="menu-chk" class="menu-chk" aria-label="Abrir menu">
        <label for="menu-chk" class="burger" aria-hidden="true"><span></span><span></span><span></span></label>
        <nav class="menu" aria-label="Principal">
            <a class="<?= $ativo('/comprar') ?>" href="<?= e(url('/comprar')) ?>">Comprar</a>
            <a class="<?= $ativo('/vender', '/veiculo/novo', '/meus-veiculos') ?>" href="<?= e(url('/vender')) ?>">Vender</a>
            <?php if ($podeAlugar): ?><a class="<?= $ativo('/alugar') ?>" href="<?= e(url('/alugar')) ?>">Alugar</a><?php endif; ?>
            <a class="<?= $ativo('/ofertas') ?>" href="<?= e(url('/ofertas')) ?>">Ofertas</a>
            <a class="<?= $ativo('/ajuda') ?>" href="<?= e(url('/ajuda')) ?>">Ajuda</a>
        </nav>
        <div class="conta">
            <?php if ($u): ?>
                <details class="conta__menu">
                    <summary>
                        <span class="avatar" aria-hidden="true"><?= e(mb_strtoupper(mb_substr($u['nome'], 0, 1))) ?></span>
                        <span class="conta__nome"><?= e(explode(' ', $u['nome'])[0]) ?></span>
                    </summary>
                    <div class="conta__lista">
                        <p class="conta__perfil"><?= e(Dominio::PERFIS[$u['perfil']]) ?></p>
                        <a href="<?= e(url('/minha-conta')) ?>">Minha conta</a>
                        <a href="<?= e(url('/favoritos')) ?>">Favoritos</a>
                        <?php if ($podeAlugar): ?><a href="<?= e(url('/minhas-reservas')) ?>">Minhas reservas</a><?php endif; ?>
                        <?php if (Auth::pode('anunciar')): ?>
                            <a href="<?= e(url('/meus-veiculos')) ?>">Meus anúncios</a>
                            <a href="<?= e(url('/veiculos/importar')) ?>">Importar veículos (XML)</a>
                            <a href="<?= e(url('/solicitacoes')) ?>">Solicitações recebidas</a>
                        <?php endif; ?>
                        <?php if (Auth::pode('area_admin')): ?>
                            <a href="<?= e(url('/admin')) ?>">Administração</a>
                        <?php endif; ?>
                        <form method="post" action="<?= e(url('/sair')) ?>">
                            <?= Csrf::campo() ?>
                            <button class="link" type="submit">Sair</button>
                        </form>
                    </div>
                </details>
            <?php else: ?>
                <a class="btn btn--claro btn--peq" href="<?= e(url('/entrar')) ?>">Entrar</a>
                <a class="btn btn--laranja btn--peq conta__cad" href="<?= e(url('/cadastro')) ?>">Criar conta</a>
            <?php endif; ?>
        </div>
    </div>
</header>

<main id="conteudo" class="wrap principal">
    <?php foreach (Flash::ler() as $m): ?>
        <div class="aviso aviso--<?= e($m['tipo']) ?>" role="status"><?= e($m['msg']) ?></div>
    <?php endforeach; ?>
    <?= $conteudo ?>
</main>

<footer class="rodape">
    <div class="wrap rodape__grade">
        <div>
            <p class="rodape__marca">CarWeb</p>
            <p>Compre, venda e alugue carros novos e seminovos em uma única plataforma.</p>
        </div>
        <div>
            <p class="rodape__tit">Explorar</p>
            <a href="<?= e(url('/comprar')) ?>">Comprar</a>
            <?php if ($podeAlugar): ?><a href="<?= e(url('/alugar')) ?>">Alugar</a><?php endif; ?>
            <a href="<?= e(url('/ofertas')) ?>">Ofertas</a>
        </div>
        <div>
            <p class="rodape__tit">Conta</p>
            <a href="<?= e(url('/vender')) ?>">Anunciar um veículo</a>
            <?php if ($podeAlugar): ?><a href="<?= e(url('/minhas-reservas')) ?>">Minhas reservas</a><?php endif; ?>
            <a href="<?= e(url('/ajuda')) ?>">Central de ajuda</a>
        </div>
    </div>
    <div class="wrap rodape__fim">
        <p>Projeto acadêmico · Ciências da Computação, UNINOVE · Ambiente de demonstração: nenhum pagamento real é processado.</p>
    </div>
</footer>
<script src="<?= e(url('assets/js/app.js')) ?>"></script>
</body>
</html>
