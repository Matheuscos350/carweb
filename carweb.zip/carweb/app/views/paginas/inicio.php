<?php /** @var array $totais @var array $locacao @var array $venda */ ?>
<section class="heroi">
    <div class="heroi__texto">
        <p class="heroi__sobre">Carros novos e seminovos</p>
        <h1>Compre, venda ou alugue o seu carro em um só lugar</h1>
        <p>Anúncios de lojas e particulares, reserva online com cálculo automático da diária e contato direto com o anunciante.</p>
    </div>
    <form class="busca" method="get" action="<?= e(url('/buscar')) ?>">
        <div class="busca__abas" role="radiogroup" aria-label="O que você procura">
            <input type="radio" id="f-venda" name="finalidade" value="venda"><label for="f-venda">Comprar</label>
            <input type="radio" id="f-loc" name="finalidade" value="locacao" checked><label for="f-loc">Alugar</label>
        </div>
        <label>Marca ou modelo <input type="text" name="q" maxlength="60" placeholder="Ex.: Corolla, Polo, Creta"></label>
        <label>Categoria
            <select name="categoria">
                <option value="">Todas</option>
                <?php foreach (Dominio::CATEGORIAS as $k => $n): ?><option value="<?= e($k) ?>"><?= e($n) ?></option><?php endforeach; ?>
            </select>
        </label>
        <button class="btn btn--laranja btn--cheio" type="submit">Buscar veículos</button>
        <p class="busca__nota"><strong><?= e($totais['venda']) ?></strong> à venda · <strong><?= e($totais['locacao']) ?></strong> para alugar</p>
    </form>
</section>

<section class="secao">
    <h2 class="secao__tit">Escolha pela categoria</h2>
    <div class="grade grade--3">
        <?php foreach (Dominio::CATEGORIAS as $k => $n): ?>
            <article class="categoria">
                <?php View::parcial('carro', ['categoria' => $k, 'id' => array_search($k, array_keys(Dominio::CATEGORIAS), true) + 1]); ?>
                <h3><?= e($n) ?></h3>
                <p><a href="<?= e(url('/comprar?categoria=' . $k)) ?>">Comprar</a> · <a href="<?= e(url('/alugar?categoria=' . $k)) ?>">Alugar</a></p>
            </article>
        <?php endforeach; ?>
    </div>
</section>

<?php if ($locacao): ?>
<section class="secao">
    <div class="secao__topo"><h2 class="secao__tit">Alugue com as melhores diárias</h2><a href="<?= e(url('/alugar')) ?>">Ver todos &rarr;</a></div>
    <div class="grade grade--3"><?php foreach ($locacao as $v) { View::parcial('card', ['v' => $v]); } ?></div>
</section>
<?php endif; ?>

<?php if ($venda): ?>
<section class="secao">
    <div class="secao__topo"><h2 class="secao__tit">Ofertas para comprar</h2><a href="<?= e(url('/comprar')) ?>">Ver todos &rarr;</a></div>
    <div class="grade grade--3"><?php foreach ($venda as $v) { View::parcial('card', ['v' => $v]); } ?></div>
</section>
<?php endif; ?>

<section class="secao">
    <h2 class="secao__tit">Como funciona</h2>
    <ol class="passos">
        <li><span>1</span><h3>Encontre</h3><p>Pesquise por categoria, preço, câmbio e combustível. Salve os preferidos nos favoritos.</p></li>
        <li><span>2</span><h3>Escolha as datas ou demonstre interesse</h3><p>No aluguel, o sistema calcula o valor e bloqueia períodos já reservados. Na compra, você fala direto com o anunciante.</p></li>
        <li><span>3</span><h3>Acompanhe</h3><p>Veja o andamento das reservas e dos interesses na sua conta, sem pagamento dentro do sistema.</p></li>
    </ol>
</section>

<section class="chamada">
    <div>
        <h2>Tem um carro para vender ou alugar?</h2>
        <p>Crie uma conta de Anunciante ou de Loja e publique em minutos, com foto e preço.</p>
    </div>
    <a class="btn btn--laranja" href="<?= e(url(Auth::usuario() ? '/vender' : '/cadastro')) ?>">Anunciar agora</a>
</section>
