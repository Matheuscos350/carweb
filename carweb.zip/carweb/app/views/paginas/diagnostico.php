<?php /** @var array $itens @var bool $migracao */ ?>
<h1>Diagnóstico da instalação</h1>
<p class="ajuda-texto">Esta página só abre em localhost. Itens em vermelho explicam o que corrigir.</p>
<table class="tabela">
    <thead><tr><th>Verificação</th><th>Situação</th><th>Detalhe</th></tr></thead>
    <tbody>
    <?php foreach ($itens as $i): ?>
        <tr><td><?= e($i['nome']) ?></td><td><span class="status status--<?= $i['ok'] ? 'disponivel' : 'inativo' ?>"><?= $i['ok'] ? 'OK' : 'CORRIGIR' ?></span></td><td><?= e($i['msg']) ?></td></tr>
    <?php endforeach; ?>
    </tbody>
</table>
<?php if ($migracao): ?>
    <p class="aviso aviso--erro">O banco está desatualizado. No phpMyAdmin, selecione o banco <code>carweb</code>, abra a aba SQL e execute o arquivo <code>database/migracao_tudo.sql</code>.</p>
<?php endif; ?>
