<h1>Central de ajuda</h1>
<section class="texto">
    <h2>Como funciona o aluguel?</h2>
    <p>Escolha um veículo em <a href="<?= e(url('/alugar')) ?>">Alugar</a>, informe as datas de retirada e devolução, seus dados e o documento. O valor é a diária multiplicada pelo número de dias. O anunciante confirma a reserva e você acompanha tudo em “Minhas reservas”.</p>
    <h2>Quais são os requisitos?</h2>
    <p>Idade mínima de 21 anos e CNH emitida há pelo menos 2 anos.</p>
    <h2>Como comprar um veículo?</h2>
    <p>Em <a href="<?= e(url('/comprar')) ?>">Comprar</a>, demonstre interesse no anúncio. O anunciante recebe seus dados de contato e negocia diretamente com você. O sistema não processa pagamentos.</p>
    <h2>Quero anunciar. E agora?</h2>
    <p>O perfil de anunciante é concedido por um administrador. Solicite-o ao suporte.</p>
    <h2>Meus dados estão seguros?</h2>
    <p>Senhas são armazenadas com hash, documentos aparecem sempre parcialmente ocultos e seus contatos só são vistos pelo anunciante do veículo de seu interesse.</p>
    <h2>Contato</h2>
    <p>suporte@carweb.local</p>
</section>
