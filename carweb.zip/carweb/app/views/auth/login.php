<section class="caixa-centro">
    <h1>Entrar no CarWeb</h1>
    <form class="form" method="post" action="<?= e(url('/entrar')) ?>">
        <?= Csrf::campo() ?>
        <label>E-mail <input type="email" name="email" required maxlength="160" autocomplete="username" value="<?= e(old('email')) ?>"></label>
        <label>Senha <input type="password" name="senha" required maxlength="72" autocomplete="current-password"></label>
        <button class="btn btn--azul btn--cheio" type="submit">Entrar</button>
    </form>
    <p class="ajuda-texto">Ainda não tem conta? <a href="<?= e(url('/cadastro')) ?>">Cadastre-se</a>.</p>
</section>
