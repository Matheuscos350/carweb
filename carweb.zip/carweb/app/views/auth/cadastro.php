<section class="caixa-centro">
    <h1>Criar conta</h1>
    <form class="form" method="post" action="<?= e(url('/cadastro')) ?>">
        <?= Csrf::campo() ?>
        <fieldset>
            <legend>Tipo de conta</legend>
            <?php $tipoAtual = old('tipo', 'cliente'); foreach (['cliente' => 'Comprador (compra e aluga veículos)', 'anunciante' => 'Anunciante (vende ou aluga os seus veículos)', 'loja' => 'Loja (concessionária ou locadora)', 'administrador' => 'Administrador geral do site (exige código)'] as $k => $n): ?>
                <label class="radio"><input type="radio" name="tipo" value="<?= e($k) ?>" <?= $tipoAtual === $k ? 'checked' : '' ?>> <?= e($n) ?></label>
            <?php endforeach; ?>
        </fieldset>
        <label>Código de administrador (só para administrador geral)
            <input type="password" name="codigo_admin" maxlength="100" autocomplete="off">
        </label>
        <label>Nome completo <input type="text" name="nome" required maxlength="120" autocomplete="name" value="<?= e(old('nome')) ?>"></label>
        <label>E-mail <input type="email" name="email" required maxlength="160" autocomplete="email" value="<?= e(old('email')) ?>"></label>
        <label>Telefone (com DDD) <input type="tel" name="telefone" required maxlength="20" autocomplete="tel" value="<?= e(old('telefone')) ?>"></label>
        <label>Senha <input type="password" name="senha" required minlength="8" maxlength="72" autocomplete="new-password"></label>
        <p class="ajuda-texto">De 8 a 72 caracteres, com pelo menos uma letra e um número.</p>
        <label>Confirmar senha <input type="password" name="senha2" required maxlength="72" autocomplete="new-password"></label>
        <button class="btn btn--azul btn--cheio" type="submit">Cadastrar</button>
    </form>
    <p class="ajuda-texto">Seus dados são usados apenas para o funcionamento do sistema (LGPD). Já tem conta? <a href="<?= e(url('/entrar')) ?>">Entrar</a>.</p>
</section>
