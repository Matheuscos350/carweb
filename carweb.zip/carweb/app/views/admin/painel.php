<?php /** @var int $totalUsuarios @var array $veiculos @var array $reservas */ ?>
<h1>Administração</h1>
<div class="grade grade--3 cartoes">
    <div class="cartao"><small>Usuários</small><strong><?= e($totalUsuarios) ?></strong><a href="<?= e(url('/admin/usuarios')) ?>">Gerenciar</a></div>
    <div class="cartao"><small>Anúncios</small><strong><?= e(array_sum($veiculos)) ?></strong><a href="<?= e(url('/admin/veiculos')) ?>">Ver todos</a></div>
    <div class="cartao"><small>Reservas</small><strong><?= e(array_sum($reservas)) ?></strong></div>
</div>
<h2 class="titulo-secao">Anúncios por situação</h2>
<ul class="periodos">
    <?php foreach (Dominio::STATUS as $k => $n): ?><li><?= e($n) ?>: <?= e($veiculos[$k] ?? 0) ?></li><?php endforeach; ?>
</ul>
<h2 class="titulo-secao">Reservas por situação</h2>
<ul class="periodos">
    <?php foreach (['pendente', 'confirmada', 'cancelada', 'concluida'] as $k): ?><li><?= e(ucfirst($k)) ?>: <?= e($reservas[$k] ?? 0) ?></li><?php endforeach; ?>
</ul>
