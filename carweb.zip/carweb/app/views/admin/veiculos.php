<?php /** @var array $itens */ ?>
<h1>Todos os anúncios</h1>
<table class="tabela">
    <thead><tr><th>Veículo</th><th>Anunciante</th><th>Finalidade</th><th>Preço</th><th>Situação</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($itens as $v): $s = Veiculo::situacao($v); ?>
        <tr>
            <td><a href="<?= e(url('/veiculo/' . $v['id'])) ?>"><?= e($v['marca'] . ' ' . $v['modelo']) ?></a> <small>(<?= e($v['ano']) ?>)</small></td>
            <td><?= e($v['anunciante_nome']) ?></td>
            <td><?= e(Dominio::FINALIDADES[$v['finalidade']]) ?></td>
            <td><?= e(brl((float) $v['preco'])) ?></td>
            <td><span class="status status--<?= e($s) ?>"><?= e(Dominio::STATUS[$s]) ?></span></td>
            <td><a href="<?= e(url('/veiculo/' . $v['id'] . '/editar')) ?>">Editar</a></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
