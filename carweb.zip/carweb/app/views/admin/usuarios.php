<?php /** @var array $usuarios */ ?>
<h1>Usuários</h1>
<table class="tabela">
    <thead><tr><th>Nome</th><th>E-mail</th><th>Perfil</th><th>Situação</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($usuarios as $u): $eu = (int) $u['id'] === Auth::id(); ?>
        <tr>
            <td><?= e($u['nome']) ?></td>
            <td><?= e($u['email']) ?></td>
            <td>
                <?php if ($eu): ?><?= e(Dominio::PERFIS[$u['perfil']]) ?> (você)
                <?php else: ?>
                    <form class="em-linha" method="post" action="<?= e(url('/admin/usuarios/' . $u['id'] . '/perfil')) ?>">
                        <?= Csrf::campo() ?>
                        <select name="perfil" aria-label="Perfil de <?= e($u['nome']) ?>">
                            <?php foreach (Dominio::PERFIS as $k => $n): if ($k === 'visitante') { continue; } ?>
                                <option value="<?= e($k) ?>" <?= $u['perfil'] === $k ? 'selected' : '' ?>><?= e($n) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <button class="btn btn--claro" type="submit">Salvar</button>
                    </form>
                <?php endif; ?>
            </td>
            <td><?= (int) $u['ativo'] === 1 ? 'Ativo' : 'Desativado' ?></td>
            <td>
                <?php if (!$eu): ?>
                    <form method="post" action="<?= e(url('/admin/usuarios/' . $u['id'] . '/ativo')) ?>" data-confirmar="Alterar a situação deste usuário?">
                        <?= Csrf::campo() ?>
                        <button class="link" type="submit"><?= (int) $u['ativo'] === 1 ? 'Desativar' : 'Reativar' ?></button>
                    </form>
                <?php endif; ?>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
