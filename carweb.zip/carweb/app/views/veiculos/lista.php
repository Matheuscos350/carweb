<?php
/** @var string $finalidade @var array $filtros @var array $itens @var int $total @var int $pagina @var int $paginas */
$locacao = $finalidade === 'locacao';
$base = $locacao ? '/alugar' : '/comprar';
$consulta = static function (int $p) use ($filtros): string {
    $q = array_filter($filtros, static fn($v, $k) => $v !== '' && $k !== 'finalidade', ARRAY_FILTER_USE_BOTH);
    $q['pagina'] = $p;
    return http_build_query($q);
};
?>
<section class="hero hero--lista">
    <h1><?= $locacao ? 'Encontre o carro perfeito para sua viagem' : 'Seu próximo carro está aqui' ?></h1>
    <p><?= $locacao
        ? 'Modelos revisados com km livre, seguro incluso e as melhores diárias do mercado.'
        : 'Anúncios de carros novos e seminovos. Demonstre interesse e fale direto com o anunciante.' ?></p>
</section>

<div class="duas-colunas">
    <aside class="filtros">
        <form method="get" action="<?= e(url($base)) ?>">
            <h2>Filtros</h2>
            <label>Marca ou modelo
                <input type="text" name="q" value="<?= e($filtros['q']) ?>" maxlength="60" placeholder="Ex.: Polo">
            </label>
            <?php if ($locacao): ?>
                <div class="linha-2">
                    <label>Retirada <input type="date" name="retirada" value="<?= e($filtros['retirada']) ?>"></label>
                    <label>Devolução <input type="date" name="devolucao" value="<?= e($filtros['devolucao']) ?>"></label>
                </div>
            <?php endif; ?>
            <fieldset>
                <legend>Categoria</legend>
                <label class="radio"><input type="radio" name="categoria" value="" <?= $filtros['categoria'] === '' ? 'checked' : '' ?>> Todas</label>
                <?php foreach (Dominio::CATEGORIAS as $k => $nome): ?>
                    <label class="radio"><input type="radio" name="categoria" value="<?= e($k) ?>" <?= $filtros['categoria'] === $k ? 'checked' : '' ?>> <?= e($nome) ?></label>
                <?php endforeach; ?>
            </fieldset>
            <div class="linha-2">
                <label>Câmbio
                    <select name="cambio"><option value="">Todos</option>
                        <?php foreach (Dominio::CAMBIOS as $k => $n): ?><option value="<?= e($k) ?>" <?= $filtros['cambio'] === $k ? 'selected' : '' ?>><?= e($n) ?></option><?php endforeach; ?>
                    </select>
                </label>
                <label>Combustível
                    <select name="combustivel"><option value="">Todos</option>
                        <?php foreach (Dominio::COMBUSTIVEIS as $k => $n): ?><option value="<?= e($k) ?>" <?= $filtros['combustivel'] === $k ? 'selected' : '' ?>><?= e($n) ?></option><?php endforeach; ?>
                    </select>
                </label>
            </div>
            <label>Ano a partir de <input type="number" name="ano_min" min="1950" max="<?= (int) date('Y') + 1 ?>" value="<?= e($filtros['ano_min']) ?>" placeholder="Ex.: 2020"></label>
            <label><?= $locacao ? 'Diária máxima (R$)' : 'Preço máximo (R$)' ?>
                <input type="text" inputmode="decimal" name="preco_max" value="<?= e($filtros['preco_max']) ?>" placeholder="<?= $locacao ? '350' : '150.000' ?>">
            </label>
            <label>Ordenar por
                <select name="ordem">
                    <?php foreach (['recomendados' => 'Recomendados', 'menor_preco' => 'Menor preço', 'maior_preco' => 'Maior preço', 'mais_novos' => 'Mais novos'] as $k => $n): ?>
                        <option value="<?= e($k) ?>" <?= $filtros['ordem'] === $k ? 'selected' : '' ?>><?= e($n) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <button class="btn btn--azul btn--cheio" type="submit">Filtrar veículos</button>
            <a class="limpar" href="<?= e(url($base)) ?>">Limpar tudo</a>
        </form>
    </aside>

    <section>
        <header class="lista__topo">
            <h2><?= $locacao ? 'Aluguel de veículos disponíveis' : 'Veículos à venda' ?></h2>
            <p><?= e($total) ?> <?= $total === 1 ? 'veículo encontrado' : 'veículos encontrados' ?></p>
        </header>
        <?php if (!$itens): ?>
            <p class="vazio">Nenhum veículo encontrado com esses filtros.</p>
        <?php else: ?>
            <div class="grade">
                <?php foreach ($itens as $v) { View::parcial('card', ['v' => $v]); } ?>
            </div>
            <?php if ($paginas > 1): ?>
                <nav class="paginas" aria-label="Páginas">
                    <?php for ($p = 1; $p <= $paginas; $p++): ?>
                        <a class="<?= $p === $pagina ? 'atual' : '' ?>" href="<?= e(url($base) . '?' . $consulta($p)) ?>"><?= $p ?></a>
                    <?php endfor; ?>
                </nav>
            <?php endif; ?>
        <?php endif; ?>
    </section>
</div>
