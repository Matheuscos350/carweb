<?php
/** @var array|null $v veículo em edição, ou null para um novo anúncio */
$edit = $v !== null;
$valor = static fn(string $campo, string $padrao = ''): string => old($campo, $edit ? (string) ($v[$campo] ?? $padrao) : $padrao);
$acao = $edit ? '/veiculo/' . $v['id'] . '/editar' : '/veiculo/novo';
$preco = $edit ? rtrim(rtrim(number_format((float) $v['preco'], 2, ',', ''), '0'), ',') : '';
?>
<h1><?= $edit ? 'Editar anúncio' : 'Anunciar veículo' ?></h1>
<form class="form form--largo" method="post" action="<?= e(url($acao)) ?>" enctype="multipart/form-data">
    <?= Csrf::campo() ?>

    <?php if (!$edit): ?>
        <fieldset>
            <legend>Finalidade</legend>
            <label class="radio"><input type="radio" name="finalidade" value="locacao" <?= $valor('finalidade', 'locacao') === 'locacao' ? 'checked' : '' ?>> Locação (valor da diária)</label>
            <label class="radio"><input type="radio" name="finalidade" value="venda" <?= $valor('finalidade') === 'venda' ? 'checked' : '' ?>> Venda (preço à vista)</label>
        </fieldset>
    <?php else: ?>
        <p class="ajuda-texto">Finalidade: <strong><?= e(Dominio::FINALIDADES[$v['finalidade']]) ?></strong> (não pode ser alterada depois da publicação).</p>
    <?php endif; ?>

    <div class="linha-2">
        <label>Marca <input type="text" name="marca" required maxlength="60" value="<?= e($valor('marca')) ?>"></label>
        <label>Modelo <input type="text" name="modelo" required maxlength="80" value="<?= e($valor('modelo')) ?>"></label>
    </div>
    <div class="linha-3">
        <label>Ano <input type="number" name="ano" required min="1950" max="<?= (int) date('Y') + 1 ?>" value="<?= e($valor('ano')) ?>"></label>
        <label>Quilometragem <input type="number" name="quilometragem" required min="0" value="<?= e($valor('quilometragem', '0')) ?>"></label>
        <label>Lugares <input type="number" name="lugares" required min="2" max="9" value="<?= e($valor('lugares', '5')) ?>"></label>
    </div>
    <div class="linha-3">
        <label>Categoria
            <select name="categoria" required>
                <?php foreach (Dominio::CATEGORIAS as $k => $n): ?>
                    <option value="<?= e($k) ?>" <?= $valor('categoria') === $k ? 'selected' : '' ?>><?= e($n) ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <label>Câmbio
            <select name="cambio" required>
                <?php foreach (Dominio::CAMBIOS as $k => $n): ?>
                    <option value="<?= e($k) ?>" <?= $valor('cambio') === $k ? 'selected' : '' ?>><?= e($n) ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <label>Combustível
            <select name="combustivel" required>
                <?php foreach (Dominio::COMBUSTIVEIS as $k => $n): ?>
                    <option value="<?= e($k) ?>" <?= $valor('combustivel', 'flex') === $k ? 'selected' : '' ?>><?= e($n) ?></option>
                <?php endforeach; ?>
            </select>
        </label>
    </div>
    <label>Preço (R$) — diária na locação, valor total na venda
        <input type="text" name="preco" required inputmode="decimal" value="<?= e(old('preco', $preco)) ?>" placeholder="Ex.: 120 ou 108.500">
    </label>
    <?php $ehLocacao = ($edit ? $v['finalidade'] : $valor('finalidade', 'locacao')) === 'locacao'; ?>
    <label>Valor por hora (R$) — opcional, só para locação
        <input type="text" name="preco_hora" inputmode="decimal" value="<?= e(old('preco_hora', $edit && ($v['preco_hora'] ?? null) !== null ? rtrim(rtrim(number_format((float) ($v['preco_hora'] ?? null), 2, ',', ''), '0'), ',') : '')) ?>" placeholder="Ex.: 25 (em branco = só aluga por dia)">
    </label>
    <label>Descrição (até 1000 caracteres)
        <textarea name="descricao" rows="4" maxlength="1000"><?= e($valor('descricao')) ?></textarea>
    </label>
    <label>Foto de capa (JPG ou PNG, até 2 MB)
        <input type="file" name="imagem" accept="image/jpeg,image/png">
    </label>
    <?php if (Database::temTabela('veiculo_fotos')): $extras = $edit ? Veiculo::fotosExtras((int) $v['id']) : []; ?>
        <?php if ($extras): ?>
            <fieldset class="fotos-atuais">
                <legend>Fotos adicionais (marque para remover)</legend>
                <?php foreach ($extras as $f): ?>
                    <label class="foto-item">
                        <img src="<?= e(url('uploads/' . $f['arquivo'])) ?>" alt="Foto adicional do anúncio" loading="lazy">
                        <span><input type="checkbox" name="remover_fotos[]" value="<?= (int) $f['id'] ?>"> Remover</span>
                    </label>
                <?php endforeach; ?>
            </fieldset>
        <?php endif; ?>
        <label>Mais fotos para o carrossel (até <?= Veiculo::MAX_FOTOS_EXTRAS ?> além da capa; JPG ou PNG, 2 MB cada; segure Ctrl para escolher várias)
            <input type="file" name="fotos[]" accept="image/jpeg,image/png" multiple>
        </label>
    <?php else: ?>
        <p class="ajuda-texto">Para enviar várias fotos, execute <code>database/migracao_tudo.sql</code> no banco.</p>
    <?php endif; ?>

    <?php if ($edit): ?>
        <label>Situação do anúncio
            <select name="status">
                <?php
                $opcoes = [$v['status']];
                foreach (['disponivel', 'inativo', 'vendido'] as $s) {
                    if ($s !== $v['status'] && Dominio::alterarStatusVeiculo($v['status'], $s) && ($s !== 'vendido' || $v['finalidade'] === 'venda')) {
                        $opcoes[] = $s;
                    }
                }
                foreach ($opcoes as $s): ?>
                    <option value="<?= e($s) ?>" <?= $valor('status') === $s ? 'selected' : '' ?>><?= e(Dominio::STATUS[$s]) ?></option>
                <?php endforeach; ?>
            </select>
        </label>
    <?php endif; ?>

    <div class="acoes">
        <button class="btn btn--azul" type="submit"><?= $edit ? 'Salvar alterações' : 'Publicar anúncio' ?></button>
        <a class="btn btn--claro" href="<?= e(url($edit ? '/veiculo/' . $v['id'] : '/meus-veiculos')) ?>">Cancelar</a>
    </div>
</form>

<?php if ($edit && $v['status'] !== 'inativo'): ?>
    <form class="form form--largo form--perigo" method="post" action="<?= e(url('/veiculo/' . $v['id'] . '/inativar')) ?>" data-confirmar="Inativar este anúncio? Ele deixará de aparecer nas buscas.">
        <?= Csrf::campo() ?>
        <p>Inativar o anúncio o remove das buscas, mas preserva o histórico de reservas.</p>
        <button class="btn btn--vermelho" type="submit">Inativar anúncio</button>
    </form>
<?php endif; ?>
