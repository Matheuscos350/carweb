<?php /** @var array $locacao @var array $venda */ ?>
<section class="hero hero--oferta">
    <h1>Ofertas imbatíveis da semana</h1>
    <p>Os menores valores de diária e de compra entre os veículos disponíveis agora.</p>
</section>

<h2 class="titulo-secao">Menores diárias</h2>
<?php if (!$locacao): ?><p class="vazio">Nenhuma oferta de locação no momento.</p><?php else: ?>
    <div class="grade grade--3"><?php foreach ($locacao as $v) { View::parcial('card', ['v' => $v]); } ?></div>
<?php endif; ?>

<h2 class="titulo-secao">Menores preços para compra</h2>
<?php if (!$venda): ?><p class="vazio">Nenhuma oferta de venda no momento.</p><?php else: ?>
    <div class="grade grade--3"><?php foreach ($venda as $v) { View::parcial('card', ['v' => $v]); } ?></div>
<?php endif; ?>
