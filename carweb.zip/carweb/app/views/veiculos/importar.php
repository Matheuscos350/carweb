<?php /** @var array $erros @var bool $enviado */ ?>
<div class="lista__topo">
    <h1>Importar veículos por XML</h1>
    <a class="btn btn--claro" href="<?= e(url('/meus-veiculos')) ?>">Voltar aos anúncios</a>
</div>

<div class="duas-cartoes">
    <section class="form">
        <h2>1. Baixe o modelo</h2>
        <p>O modelo traz três exemplos prontos (locação com valor por hora, locação só por dia e venda) e a lista de valores aceitos em cada campo.
           Copie um bloco <code>&lt;veiculo&gt;</code> para cada carro que quiser cadastrar.</p>
        <a class="btn btn--azul" href="<?= e(url('/veiculos/modelo')) ?>">Baixar modelo (.xml)</a>
        <p class="ajuda-texto">Até 100 veículos e 1 MB por arquivo. Se houver qualquer erro, nada é importado e todos os problemas são listados de uma vez. As fotos são adicionadas depois, em “Editar anúncio”.</p>
    </section>

    <form class="form" method="post" action="<?= e(url('/veiculos/importar')) ?>" enctype="multipart/form-data">
        <?= Csrf::campo() ?>
        <h2>2. Envie o arquivo preenchido</h2>
        <label>Arquivo XML <input type="file" name="arquivo" accept=".xml,application/xml,text/xml" required></label>
        <button class="btn btn--laranja" type="submit">Importar veículos</button>
    </form>
</div>

<?php if ($enviado && $erros): ?>
    <section class="aviso aviso--erro" role="alert">
        <strong>Nenhum veículo foi importado. Corrija os itens abaixo e envie novamente:</strong>
        <ul class="lista-erros">
            <?php foreach ($erros as $e): ?><li><?= e($e) ?></li><?php endforeach; ?>
        </ul>
    </section>
<?php endif; ?>

<h2 class="titulo-secao">Campos do arquivo</h2>
<table class="tabela">
    <thead><tr><th>Campo</th><th>Obrigatório</th><th>Valores aceitos</th></tr></thead>
    <tbody>
    <tr><td><code>finalidade</code></td><td>Sim</td><td><code>venda</code> ou <code>locacao</code></td></tr>
    <tr><td><code>marca</code>, <code>modelo</code></td><td>Sim</td><td>Texto (marca até 60 e modelo até 80 caracteres)</td></tr>
    <tr><td><code>ano</code></td><td>Sim</td><td>De 1950 até o próximo ano</td></tr>
    <tr><td><code>quilometragem</code></td><td>Sim</td><td>Número inteiro, zero ou mais</td></tr>
    <tr><td><code>categoria</code></td><td>Sim</td><td><?= e(implode(', ', array_keys(Dominio::CATEGORIAS))) ?></td></tr>
    <tr><td><code>cambio</code></td><td>Sim</td><td><?= e(implode(', ', array_keys(Dominio::CAMBIOS))) ?></td></tr>
    <tr><td><code>lugares</code></td><td>Sim</td><td>De 2 a 9</td></tr>
    <tr><td><code>combustivel</code></td><td>Sim</td><td><?= e(implode(', ', array_keys(Dominio::COMBUSTIVEIS))) ?></td></tr>
    <tr><td><code>preco</code></td><td>Sim</td><td>Venda: preço à vista. Locação: valor da diária. Ex.: <code>120,00</code> ou <code>108.500,00</code></td></tr>
    <tr><td><code>preco_hora</code></td><td>Não</td><td>Só locação: valor da hora (em branco = só aluga por dia)</td></tr>
    <tr><td><code>descricao</code></td><td>Não</td><td>Até 1000 caracteres</td></tr>
    </tbody>
</table>
