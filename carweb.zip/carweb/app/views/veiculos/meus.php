<?php /** @var array $itens @var array $resumo */ ?>
<div class="lista__topo">
    <h1>Meus anúncios</h1>
    <div class="acoes">
        <a class="btn btn--claro" href="<?= e(url('/veiculos/importar')) ?>">Importar XML</a>
        <a class="btn btn--azul" href="<?= e(url('/veiculo/novo')) ?>">Novo anúncio</a>
    </div>
</div>
<div class="grade grade--3 cartoes">
    <div class="cartao"><small>Anúncios</small><strong><?= e($resumo['total']) ?></strong></div>
    <div class="cartao"><small>Disponíveis</small><strong><?= e($resumo['disponiveis']) ?></strong></div>
    <div class="cartao"><small>Solicitações pendentes</small><strong><?= e($resumo['pendentes']) ?></strong><a href="<?= e(url('/solicitacoes')) ?>">Responder</a></div>
</div>
<?php if (!$itens): ?>
    <p class="vazio">Você ainda não publicou nenhum veículo.</p>
<?php else: ?>
    <table class="tabela">
        <thead><tr><th>Veículo</th><th>Finalidade</th><th>Preço</th><th>Situação</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($itens as $v): $s = Veiculo::situacao($v); ?>
            <tr>
                <td><a href="<?= e(url('/veiculo/' . $v['id'])) ?>"><?= e($v['marca'] . ' ' . $v['modelo']) ?></a> <small>(<?= e($v['ano']) ?>)</small></td>
                <td><?= e(Dominio::FINALIDADES[$v['finalidade']]) ?></td>
                <td><?= e(brl((float) $v['preco'])) ?><?= $v['finalidade'] === 'locacao' ? '/dia' : '' ?></td>
                <td><span class="status status--<?= e($s) ?>"><?= e(Dominio::STATUS[$s]) ?></span></td>
                <td><a href="<?= e(url('/veiculo/' . $v['id'] . '/editar')) ?>">Editar</a></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>
