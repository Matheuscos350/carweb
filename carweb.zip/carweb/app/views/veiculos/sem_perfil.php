<section class="caixa-centro">
    <h1>Quer anunciar um veículo?</h1>
    <p>Sua conta é do tipo <strong>Comprador</strong>, que pode alugar veículos e demonstrar interesse em compras.</p>
    <p>Para publicar anúncios é preciso uma conta de <strong>Anunciante</strong> ou de <strong>Loja</strong>. Crie uma nova conta escolhendo
       um desses tipos ou peça a mudança do perfil a um administrador do CarWeb.</p>
    <a class="btn btn--azul" href="<?= e(url('/ajuda')) ?>">Ver a central de ajuda</a>
</section>
