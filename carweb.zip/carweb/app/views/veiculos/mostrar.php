<?php
/** @var array $v @var string $situacao @var array $periodos @var bool $eDono @var bool $jaInteresse @var bool $favorito @var array $semelhantes @var array $sim */
$locacao = $v['finalidade'] === 'locacao';
$u = Auth::usuario();
$hoje = date('Y-m-d');
?>
<p class="migalha"><a href="<?= e(url($locacao ? '/alugar' : '/comprar')) ?>">&larr; Voltar à lista</a></p>

<div class="detalhe">
    <section>
        <?php $galeria = Veiculo::galeria($v); $nomeCarro = $v['marca'] . ' ' . $v['modelo']; ?>
        <?php if (count($galeria) > 1): ?>
            <div class="carrossel" data-carrossel role="region" aria-roledescription="carrossel" aria-label="Fotos de <?= e($nomeCarro) ?>" tabindex="0">
                <div class="carrossel__faixa">
                    <?php foreach ($galeria as $i => $arq): ?>
                        <figure class="carrossel__slide" aria-label="Foto <?= $i + 1 ?> de <?= count($galeria) ?>">
                            <img src="<?= e(url('uploads/' . $arq)) ?>" alt="<?= e($nomeCarro) ?> — foto <?= $i + 1 ?>" <?= $i > 0 ? 'loading="lazy"' : '' ?>>
                        </figure>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="carrossel__btn carrossel__btn--ant" data-dir="-1" aria-label="Foto anterior">&#8249;</button>
                <button type="button" class="carrossel__btn carrossel__btn--prox" data-dir="1" aria-label="Próxima foto">&#8250;</button>
                <p class="carrossel__contador" aria-live="polite"><span data-atual>1</span> / <?= count($galeria) ?></p>
                <div class="carrossel__miniaturas">
                    <?php foreach ($galeria as $i => $arq): ?>
                        <button type="button" class="carrossel__mini<?= $i === 0 ? ' ativa' : '' ?>" data-ir="<?= $i ?>" aria-label="Ver foto <?= $i + 1 ?>"><img src="<?= e(url('uploads/' . $arq)) ?>" alt="" loading="lazy"></button>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php else: ?>
            <div class="detalhe__foto">
                <?php if ($galeria): ?>
                    <img src="<?= e(url('uploads/' . $galeria[0])) ?>" alt="<?= e($nomeCarro) ?>">
                <?php else: ?>
                    <?php View::parcial('carro', ['categoria' => $v['categoria'], 'id' => $v['id']]); ?>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        <h1><?= e($v['marca'] . ' ' . $v['modelo']) ?> <span class="status status--<?= e($situacao) ?>"><?= e(Dominio::STATUS[$situacao]) ?></span></h1>
        <p class="card__sub"><?= e($v['ano']) ?> · <?= e(number_format((int) $v['quilometragem'], 0, ',', '.')) ?> km · Anunciante: <?= e($v['anunciante_nome']) ?></p>

        <table class="ficha">
            <tr><th>Categoria</th><td><?= e(Dominio::CATEGORIAS[$v['categoria']]) ?></td></tr>
            <tr><th>Câmbio</th><td><?= e(Dominio::CAMBIOS[$v['cambio']]) ?></td></tr>
            <tr><th>Lugares</th><td><?= e($v['lugares']) ?></td></tr>
            <tr><th>Combustível</th><td><?= e(Dominio::COMBUSTIVEIS[$v['combustivel']]) ?></td></tr>
            <tr><th>Finalidade</th><td><?= e(Dominio::FINALIDADES[$v['finalidade']]) ?></td></tr>
            <?php if ($locacao): ?><tr><th>Modalidades</th><td>Por dia<?= ($v['preco_hora'] ?? null) !== null ? ' e por hora (' . e(brl((float) ($v['preco_hora'] ?? null))) . '/h)' : '' ?></td></tr><?php endif; ?>
        </table>
        <?php if ($v['descricao']): ?>
            <h2>Descrição</h2>
            <p class="descricao"><?= nl2br(e($v['descricao'])) ?></p>
        <?php endif; ?>

        <?php if ($v['status'] !== 'inativo' && $v['status'] !== 'vendido') { View::parcial('simulador', ['v' => $v, 'sim' => $sim]); } ?>

        <?php if ($periodos): ?>
            <h2>Períodos já reservados</h2>
            <ul class="periodos">
                <?php foreach ($periodos as $p): ?>
                    <li><?= e(periodo_br($p)) ?></li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </section>

    <aside class="painel-acao">
        <p class="preco preco--grande">
            <small><?= $locacao ? 'Diária' : 'Preço à vista' ?></small>
            <strong><?= e(brl((float) $v['preco'])) ?><?= $locacao ? '<span>/dia</span>' : '' ?></strong>
            <?php if ($locacao && ($v['preco_hora'] ?? null) !== null): ?><em class="preco__hora">ou <?= e(brl((float) ($v['preco_hora'] ?? null))) ?>/hora</em><?php endif; ?>
        </p>

        <?php if ($u && Auth::pode('demonstrar_interesse')): ?>
            <form method="post" action="<?= e(url('/veiculo/' . $v['id'] . '/favorito')) ?>">
                <?= Csrf::campo() ?>
                <input type="hidden" name="volta" value="<?= e('/veiculo/' . $v['id']) ?>">
                <button class="btn btn--claro btn--cheio" type="submit"><?= $favorito ? '♥ Remover dos favoritos' : '♡ Adicionar aos favoritos' ?></button>
            </form>
        <?php endif; ?>

        <?php if ($eDono || Auth::pode('editar_qualquer_anuncio')): ?>
            <a class="btn btn--azul btn--cheio" href="<?= e(url('/veiculo/' . $v['id'] . '/editar')) ?>">Editar anúncio</a>
        <?php endif; ?>

        <?php if ($v['status'] !== 'disponivel'): ?>
            <p class="aviso aviso--info">Este veículo está <?= e(mb_strtolower(Dominio::STATUS[$v['status']])) ?> e não aceita novas solicitações.</p>
        <?php elseif ($eDono): ?>
            <p class="aviso aviso--info">Este é o seu anúncio.</p>
        <?php elseif (!$u): ?>
            <a class="btn btn--laranja btn--cheio" href="<?= e(url('/entrar')) ?>">Entre para <?= $locacao ? 'reservar' : 'demonstrar interesse' ?></a>
            <p class="ajuda-texto">Ainda não tem conta? <a href="<?= e(url('/cadastro')) ?>">Cadastre-se</a>.</p>
        <?php elseif ($locacao && Auth::pode('solicitar_locacao')): ?>
            <form method="post" action="<?= e(url('/veiculo/' . $v['id'] . '/reservar')) ?>" class="form" id="form-reserva" data-diaria="<?= e((float) $v['preco']) ?>" data-hora="<?= e(($v['preco_hora'] ?? null) !== null ? (float) ($v['preco_hora'] ?? null) : '') ?>">
                <?= Csrf::campo() ?>
                <h2>Reservar</h2>
                <?php $modo = old('modalidade') === 'hora' && ($v['preco_hora'] ?? null) !== null ? 'hora' : 'dia'; ?>
                <?php if (($v['preco_hora'] ?? null) !== null): ?>
                    <div class="modos" role="radiogroup" aria-label="Tipo de locação">
                        <input type="radio" id="modo-dia" name="modalidade" value="dia" <?= $modo === 'dia' ? 'checked' : '' ?>><label for="modo-dia">Por dia<small><?= e(brl((float) $v['preco'])) ?>/dia</small></label>
                        <input type="radio" id="modo-hora" name="modalidade" value="hora" <?= $modo === 'hora' ? 'checked' : '' ?>><label for="modo-hora">Por hora<small><?= e(brl((float) ($v['preco_hora'] ?? null))) ?>/h</small></label>
                        <div class="bloco bloco--dia linha-2">
                            <label>Retirada <input type="date" name="retirada" min="<?= e($hoje) ?>" value="<?= e(old('retirada')) ?>"></label>
                            <label>Devolução <input type="date" name="devolucao" min="<?= e($hoje) ?>" value="<?= e(old('devolucao')) ?>"></label>
                        </div>
                        <div class="bloco bloco--hora">
                            <label>Data <input type="date" name="data_hora" min="<?= e($hoje) ?>" value="<?= e(old('data_hora')) ?>"></label>
                            <div class="linha-2">
                                <label>Retirada às
                                    <select name="hora_inicio">
                                        <?php for ($h = Dominio::HORA_PRIMEIRA; $h < Dominio::HORA_LIMITE; $h++): ?><option value="<?= $h ?>" <?= (string) old('hora_inicio', '9') === (string) $h ? 'selected' : '' ?>><?= sprintf('%02d', $h) ?>h</option><?php endfor; ?>
                                    </select>
                                </label>
                                <label>Duração
                                    <select name="horas">
                                        <?php for ($n = 1; $n <= Dominio::HORAS_MAX; $n++): ?><option value="<?= $n ?>" <?= (string) old('horas', '3') === (string) $n ? 'selected' : '' ?>><?= $n ?> <?= $n === 1 ? 'hora' : 'horas' ?></option><?php endfor; ?>
                                    </select>
                                </label>
                            </div>
                            <p class="ajuda-texto">Das 06h às 24h, no mesmo dia, de 1 a <?= Dominio::HORAS_MAX ?> horas. Para mais tempo, escolha “Por dia”.</p>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="linha-2">
                        <label>Retirada <input type="date" name="retirada" required min="<?= e($hoje) ?>" value="<?= e(old('retirada')) ?>"></label>
                        <label>Devolução <input type="date" name="devolucao" required min="<?= e($hoje) ?>" value="<?= e(old('devolucao')) ?>"></label>
                    </div>
                <?php endif; ?>
                <p class="estimativa" id="estimativa" aria-live="polite">Escolha o período para ver a estimativa.</p>
                <label>Nome completo do locatário
                    <input type="text" name="nome" required maxlength="120" value="<?= e(old('nome', $u['nome'])) ?>">
                </label>
                <div class="linha-2">
                    <label>Documento
                        <select name="tipo_documento">
                            <option value="cpf" <?= old('tipo_documento') !== 'cnh' ? 'selected' : '' ?>>CPF</option>
                            <option value="cnh" <?= old('tipo_documento') === 'cnh' ? 'selected' : '' ?>>CNH</option>
                        </select>
                    </label>
                    <label>Número <input type="text" name="documento" required inputmode="numeric" maxlength="14" placeholder="Somente números" autocomplete="off" value="<?= e(old('documento')) ?>"></label>
                </div>
                <p class="ajuda-texto">Idade mínima de 21 anos e CNH emitida há pelo menos 2 anos. O documento é guardado com acesso restrito e exibido sempre parcialmente oculto.</p>
                <button class="btn btn--laranja btn--cheio" type="submit">Confirmar reserva</button>
            </form>
        <?php elseif (!$locacao && Auth::pode('demonstrar_interesse')): ?>
            <?php if ($jaInteresse): ?>
                <p class="aviso aviso--ok">Você já demonstrou interesse neste veículo.</p>
            <?php else: ?>
                <form method="post" action="<?= e(url('/veiculo/' . $v['id'] . '/interesse')) ?>" class="form">
                    <?= Csrf::campo() ?>
                    <h2>Tenho interesse</h2>
                    <label>Mensagem para o anunciante (opcional)
                        <textarea name="mensagem" rows="3" maxlength="300"><?= e(old('mensagem')) ?></textarea>
                    </label>
                    <p class="ajuda-texto">O anunciante verá seu nome, e-mail e telefone para entrar em contato. Nenhum pagamento é feito no sistema.</p>
                    <button class="btn btn--laranja btn--cheio" type="submit">Demonstrar interesse</button>
                </form>
            <?php endif; ?>
        <?php elseif ($locacao): ?>
            <p class="aviso aviso--info">Contas de anunciante e loja anunciam veículos, mas não fazem reservas. Para alugar, use uma conta de comprador.</p>
        <?php endif; ?>
    </aside>
</div>

<?php if (!empty($semelhantes)): ?>
    <section class="secao">
        <h2 class="secao__tit">Veículos semelhantes</h2>
        <div class="grade grade--3"><?php foreach ($semelhantes as $s) { View::parcial('card', ['v' => $s]); } ?></div>
    </section>
<?php endif; ?>
