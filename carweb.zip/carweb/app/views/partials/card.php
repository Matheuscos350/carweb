<?php
/** @var array $v veículo (com campos de situação calculados) */
$situacao = Veiculo::situacao($v);
$locacao = $v['finalidade'] === 'locacao';
$nome = $v['marca'] . ' ' . $v['modelo'];
?>
<article class="card">
    <div class="card__img">
        <a class="card__link" href="<?= e(url('/veiculo/' . $v['id'])) ?>" aria-label="Ver <?= e($nome) ?>">
            <?php if ($v['imagem']): ?>
                <img src="<?= e(url('uploads/' . $v['imagem'])) ?>" alt="<?= e($nome) ?>" loading="lazy">
            <?php else: View::parcial('carro', ['categoria' => $v['categoria'], 'id' => $v['id']]); endif; ?>
        </a>
        <span class="etiqueta"><?= e($locacao ? 'Aluguel' : 'Venda') ?></span>
        <span class="status status--<?= e($situacao) ?>"><?= e(Dominio::STATUS[$situacao]) ?></span>
        <?php if (Auth::pode('demonstrar_interesse')): $fav = eh_favorito((int) $v['id']); ?>
            <form class="card__fav" method="post" action="<?= e(url('/veiculo/' . $v['id'] . '/favorito')) ?>">
                <?= Csrf::campo() ?>
                <input type="hidden" name="volta" value="<?= e(url_atual()) ?>">
                <button type="submit" class="coracao<?= $fav ? ' coracao--on' : '' ?>" aria-pressed="<?= $fav ? 'true' : 'false' ?>" aria-label="<?= $fav ? 'Remover dos favoritos' : 'Adicionar aos favoritos' ?>">
                    <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s-7.5-4.6-9.6-9.3C.9 8.3 3 5 6.4 5c2 0 3.6 1.1 4.6 2.7h2C14 6.1 15.6 5 17.6 5 21 5 23.1 8.3 21.6 11.7 19.500 16.400 12 21 12 21z"/></svg>
                </button>
            </form>
        <?php endif; ?>
    </div>
    <div class="card__corpo">
        <p class="card__cat"><?= e(Dominio::CATEGORIAS[$v['categoria']]) ?></p>
        <h3><a href="<?= e(url('/veiculo/' . $v['id'])) ?>"><?= e($nome) ?></a></h3>
        <p class="card__sub"><?= e($v['ano']) ?> · <?= e(number_format((int) $v['quilometragem'], 0, ',', '.')) ?> km</p>
        <ul class="specs">
            <li><?= e(Dominio::CAMBIOS[$v['cambio']]) ?></li>
            <li><?= e($v['lugares']) ?> lugares</li>
            <li><?= e(Dominio::COMBUSTIVEIS[$v['combustivel']]) ?></li>
        </ul>
        <div class="card__rodape">
            <div class="preco">
                <small><?= $locacao ? 'Diária' : 'À vista' ?></small>
                <strong><?= e(brl((float) $v['preco'])) ?><?= $locacao ? '<span>/dia</span>' : '' ?></strong>
                <?php if ($locacao && ($v['preco_hora'] ?? null) !== null): ?><em class="preco__hora">ou <?= e(brl((float) ($v['preco_hora'] ?? null))) ?>/hora</em><?php endif; ?>
            </div>
            <a class="btn btn--laranja btn--peq" href="<?= e(url('/veiculo/' . $v['id'])) ?>"><?= $locacao ? 'Reservar' : 'Ver oferta' ?></a>
        </div>
    </div>
</article>
