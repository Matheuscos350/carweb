<?php
/** @var array $v @var array $sim */
$locacao = $v['finalidade'] === 'locacao';
$f = $sim['form'];
$r = $sim['resultado'];
?>
<section class="simulador" id="simulador">
    <h2><?= $locacao ? 'Simule o parcelamento da locação' : 'Simule o financiamento' ?></h2>
    <form method="get" action="<?= e(url('/veiculo/' . $v['id'])) ?>#simulador">
        <input type="hidden" name="sim" value="1">
        <?php if ($locacao): ?>
            <div class="linha-2">
                <label>Quantidade de dias <input type="number" name="dias" min="1" max="<?= e((int) config('max_dias_locacao', 60)) ?>" value="<?= e($f['dias']) ?>"></label>
                <label>Parcelas (sem juros)
                    <select name="parcelas">
                        <?php for ($n = 1; $n <= 6; $n++): ?><option value="<?= $n ?>" <?= (string) $f['parcelas'] === (string) $n ? 'selected' : '' ?>><?= $n ?>x</option><?php endfor; ?>
                    </select>
                </label>
            </div>
        <?php else: ?>
            <div class="linha-2">
                <label>Entrada (R$) <input type="text" name="entrada" inputmode="decimal" value="<?= e($f['entrada']) ?>"></label>
                <label>Taxa de juros (% ao mês) <input type="text" name="taxa" inputmode="decimal" value="<?= e($f['taxa']) ?>"></label>
            </div>
            <label>Prazo
                <select name="prazo">
                    <?php foreach (Dominio::PRAZOS_FINANCIAMENTO as $n): ?><option value="<?= $n ?>" <?= (string) $f['prazo'] === (string) $n ? 'selected' : '' ?>><?= $n ?> meses</option><?php endforeach; ?>
                </select>
            </label>
        <?php endif; ?>
        <button class="btn btn--azul" type="submit">Simular</button>
    </form>

    <?php if ($sim['erro']): ?>
        <p class="aviso aviso--erro" role="alert"><?= e($sim['erro']) ?></p>
    <?php elseif ($r && $locacao): ?>
        <div class="simulador__resultado" aria-live="polite">
            <p><?= e($r['dias']) ?> <?= $r['dias'] === 1 ? 'dia' : 'dias' ?> de locação: <strong><?= e(brl($r['total'])) ?></strong></p>
            <p class="simulador__destaque"><?= e($r['parcelas']) ?>x de <strong><?= e(brl($r['parcela'])) ?></strong> <small>sem juros</small></p>
        </div>
    <?php elseif ($r): ?>
        <div class="simulador__resultado" aria-live="polite">
            <p class="simulador__destaque"><?= e($r['prazo']) ?>x de <strong><?= e(brl($r['parcela'])) ?></strong></p>
            <dl class="simulador__dados">
                <div><dt>Valor financiado</dt><dd><?= e(brl($r['financiado'])) ?></dd></div>
                <div><dt>Juros no período</dt><dd><?= e(brl($r['juros'])) ?></dd></div>
                <div><dt>Total pago (com entrada)</dt><dd><?= e(brl($r['total'])) ?></dd></div>
            </dl>
        </div>
        <table class="tabela tabela--sim">
            <caption>Comparação de prazos com a mesma entrada e taxa</caption>
            <thead><tr><th>Prazo</th><th>Parcela</th><th>Total pago</th></tr></thead>
            <tbody>
            <?php foreach ($sim['tabela'] as $t): ?>
                <tr class="<?= $t['prazo'] === $r['prazo'] ? 'linha-sel' : '' ?>"><td><?= e($t['prazo']) ?> meses</td><td><?= e(brl($t['parcela'])) ?></td><td><?= e(brl($t['total'])) ?></td></tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
    <p class="ajuda-texto"><?= $locacao
        ? 'Simulação informativa. O valor oficial é calculado na reserva, pelas datas escolhidas.'
        : 'Estimativa pela Tabela Price, sem IOF, tarifas, seguro ou CET. Não é uma proposta de crédito: as condições reais dependem da instituição financeira.' ?></p>
</section>
