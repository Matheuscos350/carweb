<?php
/** Ilustração do carro quando o anúncio não tem foto. @var string $categoria @var int $id */
$formas = [
    'hatch' => ['M34 118V104Q34 96 44 94L70 90Q84 66 112 62H178Q204 62 220 84L262 92Q284 96 286 112V118Z', 'M96 88Q104 72 120 70H150V88ZM158 70H178Q194 72 204 88H158Z', 90, 232, 21],
    'sedan' => ['M22 118V106Q22 98 34 96L74 90Q90 70 118 66H176Q204 66 222 88L268 94Q296 98 298 112V118Z', 'M100 88Q110 76 124 74H152V88ZM160 74H178Q196 76 208 88H160Z', 84, 244, 21],
    'suv'   => ['M30 120V98Q30 90 40 88L66 84Q76 58 104 54H206Q232 56 244 82L272 88Q290 92 292 106V120Z', 'M92 82Q100 66 116 64H150V82ZM158 64H204Q218 66 226 82H158Z', 84, 238, 24],
];
[$corpo, $janelas, $x1, $x2, $r] = $formas[$categoria] ?? $formas['hatch'];
$cor = ((int) $id) % 6;
?>
<svg class="carro cor-<?= $cor ?>" viewBox="0 0 320 160" role="img" aria-label="Ilustração de <?= e($categoria) ?>" xmlns="http://www.w3.org/2000/svg">
    <ellipse class="carro__sombra" cx="160" cy="144" rx="132" ry="9"/>
    <path class="carro__corpo" d="<?= e($corpo) ?>"/>
    <path class="carro__vidro" d="<?= e($janelas) ?>"/>
    <circle class="carro__farol" cx="<?= $x2 + 46 ?>" cy="104" r="5"/>
    <?php foreach ([$x1, $x2] as $x): ?>
        <circle class="carro__pneu" cx="<?= $x ?>" cy="122" r="<?= $r + 4 ?>"/>
        <circle class="carro__roda" cx="<?= $x ?>" cy="122" r="<?= $r - 6 ?>"/>
    <?php endforeach; ?>
</svg>
