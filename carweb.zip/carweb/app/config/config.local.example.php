<?php
/**
 * Copie este arquivo para config.local.php e ajuste. O config.local.php está no .gitignore
 * e substitui os valores de config.php.
 */
return [
    'db' => [
        'user' => 'carweb_app',
        'pass' => 'a_mesma_senha_definida_em_usuario_banco.sql',
    ],
    // Código exigido para criar uma conta de Administrador geral no cadastro. Vazio = desativado.
    'codigo_admin' => 'defina-um-codigo-longo-e-secreto',
    // 'debug' => true,   // só no seu computador, durante o desenvolvimento
];
