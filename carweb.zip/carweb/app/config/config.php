<?php
/**
 * Configuração padrão. NÃO coloque senhas reais aqui.
 * Para o seu ambiente, copie config.local.example.php para config.local.php (que fica fora do Git)
 * ou use as variáveis de ambiente CARWEB_DB_*.
 */
return [
    'nome_app' => 'CarWeb',
    'debug'    => false,               // em produção, mantenha false (RNF02: sem detalhes de erro ao usuário)

    'db' => [
        'host'    => getenv('CARWEB_DB_HOST') ?: '127.0.0.1',
        'port'    => getenv('CARWEB_DB_PORT') ?: '3306',
        'name'    => getenv('CARWEB_DB_NAME') ?: 'carweb',
        'user'    => getenv('CARWEB_DB_USER') ?: 'carweb_app',
        'pass'    => getenv('CARWEB_DB_PASS') !== false ? getenv('CARWEB_DB_PASS') : 'troque_esta_senha',
        'charset' => 'utf8mb4',
    ],

    'sessao_inatividade' => 1800,      // segundos (30 min) até a sessão expirar por inatividade
    'upload_max_bytes'   => 2 * 1024 * 1024,
    'max_dias_locacao'   => 60,
    'taxa_financiamento' => 1.89,   // % ao mês sugerida no simulador (estimativa, sem valor contratual)
    'itens_por_pagina'   => 9,
];
