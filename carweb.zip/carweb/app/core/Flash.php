<?php
declare(strict_types=1);

/** Mensagens exibidas uma única vez (sucesso, erro, informação) e valores antigos de formulário. */
final class Flash
{
    public static function adicionar(string $tipo, string $mensagem): void
    {
        $_SESSION['flash'][] = ['tipo' => $tipo, 'msg' => $mensagem];
    }

    /** @return array<int, array{tipo: string, msg: string}> */
    public static function ler(): array
    {
        $msgs = $_SESSION['flash'] ?? [];
        unset($_SESSION['flash']);
        return $msgs;
    }

    /** Guarda o que o usuário digitou (sem senhas) para repreencher o formulário após um erro. */
    public static function guardarEntrada(array $post): void
    {
        unset($post['senha'], $post['senha2'], $post['_csrf']);
        $_SESSION['_old'] = array_filter($post, 'is_string');
    }
}
