<?php
declare(strict_types=1);

define('ROOT', dirname(__DIR__, 2));
define('APP', ROOT . '/app');

spl_autoload_register(static function (string $classe): void {
    foreach (['core', 'models', 'controllers'] as $pasta) {
        $arquivo = APP . "/$pasta/$classe.php";
        if (is_file($arquivo)) {
            require $arquivo;
            return;
        }
    }
});

require APP . '/core/helpers.php';

$GLOBALS['config'] = require APP . '/config/config.php';
if (is_file(APP . '/config/config.local.php')) {
    $GLOBALS['config'] = array_replace_recursive($GLOBALS['config'], require APP . '/config/config.local.php');
}

/** Lê um valor da configuração com notação de pontos: config('db.host'). */
function config(string $chave, mixed $padrao = null): mixed
{
    $valor = $GLOBALS['config'];
    foreach (explode('.', $chave) as $parte) {
        if (!is_array($valor) || !array_key_exists($parte, $valor)) {
            return $padrao;
        }
        $valor = $valor[$parte];
    }
    return $valor;
}

// Tratamento seguro de erros (seção 6.4): detalhes vão para o log, o usuário vê só uma mensagem genérica.
error_reporting(E_ALL);
ini_set('display_errors', config('debug') ? '1' : '0');
ini_set('log_errors', '1');
if (!is_dir(ROOT . '/storage/logs')) {
    @mkdir(ROOT . '/storage/logs', 0775, true);
}
ini_set('error_log', ROOT . '/storage/logs/app.log');

set_exception_handler(static function (Throwable $e): void {
    error_log(sprintf('[%s] %s em %s:%d', get_class($e), $e->getMessage(), $e->getFile(), $e->getLine()));
    if (!headers_sent()) {
        http_response_code(500);
    }
    try {
        if (ob_get_level() > 0) {
            ob_end_clean();
        }
        // Só quando o acesso vem do próprio computador (localhost) o motivo técnico aparece na tela, para facilitar o diagnóstico.
        $local = in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1'], true);
        $detalhe = $local ? sprintf('%s: %s (%s:%d)', get_class($e), $e->getMessage(), basename($e->getFile()), $e->getLine()) : null;
        View::render('erro', ['codigo' => 500, 'mensagem' => 'Ocorreu um erro inesperado. Tente novamente em instantes.', 'detalhe' => $detalhe], 'Erro');
    } catch (Throwable) {
        echo 'Ocorreu um erro inesperado.';
    }
});
