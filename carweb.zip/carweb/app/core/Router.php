<?php
declare(strict_types=1);

/** Roteador mínimo: associa "MÉTODO /caminho/{id}" a uma função. */
final class Router
{
    /** @var array<int, array{string, string, callable}> */
    private array $rotas = [];

    public function adicionar(string $metodo, string $padrao, callable $acao): void
    {
        $regex = '#^' . preg_replace('#\{(\w+)\}#', '(?P<$1>\d+)', $padrao) . '$#';
        $this->rotas[] = [$metodo, $regex, $acao];
    }

    public function get(string $padrao, callable $acao): void
    {
        $this->adicionar('GET', $padrao, $acao);
    }

    public function post(string $padrao, callable $acao): void
    {
        $this->adicionar('POST', $padrao, $acao);
    }

    public function executar(string $metodo, string $caminho): void
    {
        $caminhoExiste = false;
        foreach ($this->rotas as [$m, $regex, $acao]) {
            if (!preg_match($regex, $caminho, $achados)) {
                continue;
            }
            $caminhoExiste = true;
            if ($m !== $metodo) {
                continue;
            }
            // Toda requisição que altera dados precisa de token CSRF válido.
            if ($metodo === 'POST' && !Csrf::validar()) {
                abort(419, 'Sessão expirada ou formulário inválido. Volte e tente novamente.');
            }
            $params = array_map('intval', array_filter($achados, 'is_string', ARRAY_FILTER_USE_KEY));
            $acao(...array_values($params));
            return;
        }
        if ($caminhoExiste) {
            header('Allow: GET, POST');
            abort(405, 'Método não permitido.');
        }
        abort(404);
    }
}
