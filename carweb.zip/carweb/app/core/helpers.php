<?php
declare(strict_types=1);

/** Escapa texto para saída em HTML (prevenção de XSS, RNF02). Use em TODA saída vinda de dados. */
function e(mixed $valor): string
{
    return htmlspecialchars((string) $valor, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** Pasta pública onde a aplicação está (ex.: /carweb/public no XAMPP, ou vazio com php -S). */
function base_path(): string
{
    static $base = null;
    if ($base === null) {
        $base = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '')), '/');
    }
    return $base;
}

function url(string $caminho = ''): string
{
    return base_path() . '/' . ltrim($caminho, '/');
}

/** Caminho da requisição atual, relativo à pasta pública (ex.: /alugar). */
function rota_atual(): string
{
    $caminho = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
    $base = base_path();
    if ($base !== '' && str_starts_with($caminho, $base)) {
        $caminho = substr($caminho, strlen($base));
    }
    if (str_starts_with($caminho, '/index.php')) {
        $caminho = substr($caminho, strlen('/index.php'));
    }
    $caminho = '/' . trim($caminho, '/');
    return $caminho;
}

function redirect(string $caminho): void
{
    header('Location: ' . url($caminho));
    exit;
}

function post(string $chave, string $padrao = ''): string
{
    $v = $_POST[$chave] ?? $padrao;
    return is_string($v) ? trim($v) : $padrao;
}

function get(string $chave, string $padrao = ''): string
{
    $v = $_GET[$chave] ?? $padrao;
    return is_string($v) ? trim($v) : $padrao;
}

/** Valor digitado no formulário anterior (devolvido após erro de validação). */
function old(string $chave, string $padrao = ''): string
{
    $v = $GLOBALS['_old'][$chave] ?? $padrao;
    return is_string($v) ? $v : $padrao;
}

function brl(float $valor): string
{
    $casas = floor($valor) == $valor ? 0 : 2;
    return 'R$ ' . number_format($valor, $casas, ',', '.');
}

function data_br(string $data): string
{
    $t = strtotime($data);
    return $t ? date('d/m/Y', $t) : $data;
}

/** Período de uma reserva em texto: "05/10/2026 a 10/10/2026" (por dia) ou "05/10/2026, 14h às 16h" (por hora). */
function periodo_br(array $r): string
{
    $a = strtotime($r['data_retirada']);
    $b = strtotime($r['data_devolucao']);
    if (($r['modalidade'] ?? 'dia') === 'hora' && $a && $b) {
        $fim = (int) date('G', $b) === 0 ? '24' : date('G', $b);
        return date('d/m/Y', $a) . ', ' . date('G', $a) . 'h às ' . $fim . 'h';
    }
    return data_br($r['data_retirada']) . ' a ' . data_br($r['data_devolucao']);
}

function abort(int $codigo, string $mensagem = ''): void
{
    http_response_code($codigo);
    $padrao = [403 => 'Você não tem permissão para acessar esta página.', 404 => 'Página não encontrada.'];
    View::render('erro', ['codigo' => $codigo, 'mensagem' => $mensagem ?: ($padrao[$codigo] ?? 'Erro.')], "Erro $codigo");
    exit;
}

function eh_post(): bool
{
    return ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST';
}

/** Cabeçalhos de segurança (seção 6.4). O CSP exige que não haja scripts ou estilos inline nas views. */
function enviar_cabecalhos_seguranca(): void
{
    header("Content-Security-Policy: default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; form-action 'self'; frame-ancestors 'none'; base-uri 'self'");
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header('Referrer-Policy: same-origin');
    header('Permissions-Policy: geolocation=(), microphone=(), camera=()');
}

/** O veículo está nos favoritos do usuário logado? (carrega a lista uma única vez por requisição) */
function eh_favorito(int $veiculoId): bool
{
    static $ids = null;
    if ($ids === null) {
        $uid = Auth::id();
        try {
            $ids = $uid !== null ? Favorito::ids($uid) : [];
        } catch (PDOException $e) {
            // Tabela "favoritos" ainda não criada (migração pendente): o site funciona, sem os corações marcados.
            error_log('[favoritos] ' . $e->getMessage());
            $ids = [];
        }
    }
    return isset($ids[$veiculoId]);
}

/** Caminho + consulta da página atual (usado para voltar após ações como favoritar). */
function url_atual(): string
{
    $c = rota_atual();
    $q = $_SERVER['QUERY_STRING'] ?? '';
    return $c . ($q !== '' ? '?' . $q : '');
}
