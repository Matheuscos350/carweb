<?php
declare(strict_types=1);

/**
 * Sessão e autenticação (seção 6.2). O PHP guarda a sessão no servidor; no navegador fica só o identificador.
 * O usuário é relido do banco a cada requisição: se o administrador desativar a conta ou mudar o perfil,
 * o efeito é imediato.
 */
final class Auth
{
    private static ?array $usuario = null;
    private static bool $carregado = false;

    public static function iniciar(): void
    {
        $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
        ini_set('session.use_strict_mode', '1');
        ini_set('session.use_only_cookies', '1');
        session_name('carweb_sid');
        session_set_cookie_params([
            'lifetime' => 0,
            'path'     => '/',
            'secure'   => $https,
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        session_start();

        // expira por inatividade
        $limite = (int) config('sessao_inatividade', 1800);
        if (isset($_SESSION['ultimo_acesso']) && time() - (int) $_SESSION['ultimo_acesso'] > $limite) {
            $_SESSION = [];
            session_regenerate_id(true);
        }
        $_SESSION['ultimo_acesso'] = time();

        // "old": valores do formulário anterior, válidos por uma única requisição
        $GLOBALS['_old'] = $_SESSION['_old'] ?? [];
        unset($_SESSION['_old']);
    }

    public static function usuario(): ?array
    {
        if (!self::$carregado) {
            self::$carregado = true;
            $id = $_SESSION['uid'] ?? null;
            if ($id) {
                $u = Usuario::buscar((int) $id);
                if ($u !== null && (int) $u['ativo'] === 1) {
                    self::$usuario = $u;
                } else {
                    unset($_SESSION['uid']);
                }
            }
        }
        return self::$usuario;
    }

    public static function entrar(array $usuario): void
    {
        session_regenerate_id(true);          // evita fixação de sessão
        $_SESSION['uid'] = (int) $usuario['id'];
        self::$usuario = $usuario;
        self::$carregado = true;
    }

    public static function sair(): void
    {
        $_SESSION = [];
        session_regenerate_id(true);
        self::$usuario = null;
        self::$carregado = true;
    }

    public static function perfil(): ?string
    {
        return self::usuario()['perfil'] ?? null;
    }

    public static function id(): ?int
    {
        $u = self::usuario();
        return $u ? (int) $u['id'] : null;
    }

    public static function pode(string $acao): bool
    {
        return Dominio::verificarPermissao(self::perfil(), $acao);
    }

    /** Exige login e permissão. A checagem é sempre feita no servidor (RNF12). */
    public static function exigir(string $acao): void
    {
        if (self::usuario() === null) {
            Flash::adicionar('info', 'Faça login para continuar.');
            redirect('/entrar');
        }
        if (!self::pode($acao)) {
            abort(403);
        }
    }
}
