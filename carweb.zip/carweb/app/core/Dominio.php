<?php
declare(strict_types=1);

/**
 * Regras de negócio puras (sem banco e sem navegador), por isso fáceis de testar de forma isolada.
 * Os nomes dos métodos seguem os casos de teste unitários do plano de testes (Quadro 5, CT-U01 a CT-U11).
 */
final class Dominio
{
    public const CATEGORIAS   = ['hatch' => 'Hatch / Compacto', 'sedan' => 'Sedan', 'suv' => 'SUV / Crossover'];
    public const CAMBIOS      = ['manual' => 'Manual', 'automatico' => 'Automático'];
    public const COMBUSTIVEIS = ['flex' => 'Flex', 'gasolina' => 'Gasolina', 'etanol' => 'Etanol', 'diesel' => 'Diesel', 'eletrico' => 'Elétrico', 'hibrido' => 'Híbrido'];
    public const FINALIDADES  = ['venda' => 'Venda', 'locacao' => 'Locação'];
    public const STATUS       = ['disponivel' => 'Disponível', 'reservado' => 'Reservado', 'alugado' => 'Alugado', 'vendido' => 'Vendido', 'inativo' => 'Inativo'];
    public const PERFIS       = ['cliente' => 'Comprador', 'anunciante' => 'Anunciante', 'loja' => 'Loja', 'administrador' => 'Administrador geral'];

    /** Quadro 10 da documentação: o que cada perfil pode fazer. Visitante = perfil nulo. */
    private const PERMISSOES = [
        'consultar'                 => ['visitante', 'cliente', 'anunciante', 'loja', 'administrador'],
        'demonstrar_interesse'      => ['cliente', 'anunciante', 'loja', 'administrador'],
        'solicitar_locacao'         => ['cliente', 'administrador'],   // anunciante e loja só anunciam: não alugam
        'anunciar'                  => ['anunciante', 'loja', 'administrador'],
        'editar_proprio_anuncio'    => ['anunciante', 'loja', 'administrador'],
        'ver_solicitacoes_proprias' => ['anunciante', 'loja', 'administrador'],
        'gerenciar_usuarios'        => ['administrador'],
        'editar_qualquer_anuncio'   => ['administrador'],
        'area_admin'                => ['administrador'],
    ];

    /** Transições permitidas para a situação do veículo (RF14). "vendido" é um estado final. */
    private const TRANSICOES = [
        'disponivel' => ['reservado', 'alugado', 'vendido', 'inativo'],
        'reservado'  => ['disponivel', 'alugado', 'inativo'],
        'alugado'    => ['disponivel', 'inativo'],
        'inativo'    => ['disponivel'],
        'vendido'    => [],
    ];

    // ------------------------------------------------------------------ locação (RF15, RF16)

    private static function data(string $texto): DateTimeImmutable
    {
        $d = DateTimeImmutable::createFromFormat('!Y-m-d', $texto);
        if ($d === false || $d->format('Y-m-d') !== $texto) {
            throw new InvalidArgumentException('Data inválida.');
        }
        return $d;
    }

    /** Quantidade de diárias entre a retirada e a devolução. */
    public static function dias(string $retirada, string $devolucao): int
    {
        $ini = self::data($retirada);
        $fim = self::data($devolucao);
        if ($fim <= $ini) {
            throw new InvalidArgumentException('A data de devolução deve ser posterior à data de retirada.');
        }
        return (int) $ini->diff($fim)->days;
    }

    /** CT-U01 e CT-U02: diária × quantidade de dias. */
    public static function calcularValorLocacao(float $diaria, string $retirada, string $devolucao): float
    {
        if ($diaria <= 0) {
            throw new InvalidArgumentException('Valor da diária inválido.');
        }
        return round($diaria * self::dias($retirada, $devolucao), 2);
    }

    /**
     * CT-U03 a CT-U05: há conflito se os períodos se sobrepõem. O dia da devolução de uma reserva
     * pode ser o dia da retirada da seguinte (sem sobreposição real de diárias).
     *
     * @param array<int, array{data_retirada: string, data_devolucao: string}> $reservas reservas ativas do veículo
     */
    public static function verificarConflito(string $retirada, string $devolucao, array $reservas): bool
    {
        // Aceita datas ('Y-m-d', tratadas como 00:00) ou data e hora ('Y-m-d H:i:s'), para valer tanto
        // para a locação por dia quanto para a locação por hora.
        $ini = self::instante($retirada);
        $fim = self::instante($devolucao);
        if ($fim <= $ini) {
            throw new InvalidArgumentException('A data de devolução deve ser posterior à data de retirada.');
        }
        foreach ($reservas as $r) {
            if ($ini < self::instante($r['data_devolucao']) && $fim > self::instante($r['data_retirada'])) {
                return true;
            }
        }
        return false;
    }

    /** Normaliza 'Y-m-d' ou 'Y-m-d H:i:s' para 'Y-m-d H:i:s' (comparável como texto). */
    private static function instante(string $texto): string
    {
        $t = strlen($texto) === 10 ? $texto . ' 00:00:00' : $texto;
        $d = DateTimeImmutable::createFromFormat('!Y-m-d H:i:s', $t);
        if ($d === false || $d->format('Y-m-d H:i:s') !== $t) {
            throw new InvalidArgumentException('Data inválida.');
        }
        return $t;
    }

    // ------------------------------------------------------------------ validações (RF01, RF04, RF12)

    /** CT-U06 */
    public static function validarEmail(string $email): bool
    {
        return strlen($email) <= 160
            && filter_var($email, FILTER_VALIDATE_EMAIL) !== false
            && preg_match('/@[^@]+\.[^@]+$/', $email) === 1;
    }

    /** CT-U07: confere os dígitos verificadores e recusa sequências repetidas. */
    public static function validarCpf(string $cpf): bool
    {
        $n = preg_replace('/\D/', '', $cpf) ?? '';
        if (strlen($n) !== 11 || preg_match('/^(\d)\1{10}$/', $n)) {
            return false;
        }
        for ($t = 9; $t < 11; $t++) {
            $soma = 0;
            for ($i = 0; $i < $t; $i++) {
                $soma += (int) $n[$i] * (($t + 1) - $i);
            }
            if ((int) $n[$t] !== ((10 * $soma) % 11) % 10) {
                return false;
            }
        }
        return true;
    }

    /** CNH: 11 dígitos, sem sequência repetida (a conferência completa fica para versão futura). */
    public static function validarCnh(string $cnh): bool
    {
        $n = preg_replace('/\D/', '', $cnh) ?? '';
        return strlen($n) === 11 && !preg_match('/^(\d)\1{10}$/', $n);
    }

    public static function validarDocumento(string $tipo, string $numero): bool
    {
        return match ($tipo) {
            'cpf'   => self::validarCpf($numero),
            'cnh'   => self::validarCnh($numero),
            default => false,
        };
    }

    /** Exibe o documento parcialmente oculto (LGPD: minimização da exposição). Ex.: ***.456.789-** */
    public static function mascararDocumento(string $numero, string $tipo): string
    {
        $n = preg_replace('/\D/', '', $numero) ?? '';
        if (strlen($n) !== 11) {
            return '***';
        }
        return $tipo === 'cpf'
            ? '***.' . substr($n, 3, 3) . '.' . substr($n, 6, 3) . '-**'
            : '*******' . substr($n, 7, 4);
    }

    /** Mínimo de 8 caracteres, com letra e número. */
    public static function validarSenha(string $senha): bool
    {
        return strlen($senha) >= 8 && strlen($senha) <= 72
            && preg_match('/[A-Za-z]/', $senha) === 1
            && preg_match('/\d/', $senha) === 1;
    }

    public static function validarTelefone(string $tel): bool
    {
        $n = preg_replace('/\D/', '', $tel) ?? '';
        return strlen($n) >= 10 && strlen($n) <= 11;
    }

    // ------------------------------------------------------------------ senhas (RF02, RNF02)

    /** CT-U08: a senha nunca é guardada em texto legível. */
    public static function gerarHashSenha(string $senha): string
    {
        return password_hash($senha, PASSWORD_DEFAULT);
    }

    public static function verificarSenha(string $senha, string $hash): bool
    {
        return password_verify($senha, $hash);
    }

    // ------------------------------------------------------------------ veículos (RF04, RF14)

    /**
     * CT-U09: devolve a lista de erros (campo => mensagem). Lista vazia = dados válidos.
     *
     * @return array<string, string>
     */
    public static function validarVeiculo(array $d): array
    {
        $erros = [];
        $marca = trim((string) ($d['marca'] ?? ''));
        $modelo = trim((string) ($d['modelo'] ?? ''));
        if ($marca === '' || mb_strlen($marca) > 60) {
            $erros['marca'] = 'Informe a marca (até 60 caracteres).';
        }
        if ($modelo === '' || mb_strlen($modelo) > 80) {
            $erros['modelo'] = 'Informe o modelo (até 80 caracteres).';
        }
        $ano = filter_var($d['ano'] ?? null, FILTER_VALIDATE_INT);
        if ($ano === false || $ano < 1950 || $ano > (int) date('Y') + 1) {
            $erros['ano'] = 'Informe um ano válido.';
        }
        $km = filter_var($d['quilometragem'] ?? null, FILTER_VALIDATE_INT);
        if ($km === false || $km < 0 || $km > 2000000) {
            $erros['quilometragem'] = 'Informe a quilometragem (zero ou mais).';
        }
        $preco = $d['preco'] ?? null;
        if (!is_numeric($preco) || (float) $preco <= 0 || (float) $preco > 99999999) {
            $erros['preco'] = 'Informe um preço maior que zero.';
        }
        $hora = $d['preco_hora'] ?? '';
        if (($d['finalidade'] ?? '') === 'locacao' && $hora !== '' && $hora !== null
            && (!is_numeric($hora) || (float) $hora <= 0 || (float) $hora > 99999)) {
            $erros['preco_hora'] = 'O valor por hora deve ser maior que zero (ou deixe em branco para alugar só por dia).';
        }
        if (!isset(self::CATEGORIAS[$d['categoria'] ?? ''])) {
            $erros['categoria'] = 'Escolha a categoria.';
        }
        if (!isset(self::CAMBIOS[$d['cambio'] ?? ''])) {
            $erros['cambio'] = 'Escolha o câmbio.';
        }
        if (!isset(self::COMBUSTIVEIS[$d['combustivel'] ?? ''])) {
            $erros['combustivel'] = 'Escolha o combustível.';
        }
        if (!isset(self::FINALIDADES[$d['finalidade'] ?? ''])) {
            $erros['finalidade'] = 'Escolha a finalidade (venda ou locação).';
        }
        $lugares = filter_var($d['lugares'] ?? null, FILTER_VALIDATE_INT);
        if ($lugares === false || $lugares < 2 || $lugares > 9) {
            $erros['lugares'] = 'Informe de 2 a 9 lugares.';
        }
        if (mb_strlen((string) ($d['descricao'] ?? '')) > 1000) {
            $erros['descricao'] = 'A descrição pode ter até 1000 caracteres.';
        }
        return $erros;
    }

    /** CT-U10 */
    public static function alterarStatusVeiculo(string $atual, string $novo): bool
    {
        return in_array($novo, self::TRANSICOES[$atual] ?? [], true);
    }

    /** Converte "108.500", "1.250,90" ou "120,5" em número. Devolve null se não for um valor válido. */
    public static function paraDecimal(string $texto): ?float
    {
        $t = trim(str_replace(['R$', ' '], '', $texto));
        if ($t === '') {
            return null;
        }
        if (str_contains($t, ',')) {
            $t = str_replace('.', '', $t);
            $t = str_replace(',', '.', $t);
        } elseif (preg_match('/^\d{1,3}(\.\d{3})+$/', $t)) {
            $t = str_replace('.', '', $t);
        }
        return is_numeric($t) ? (float) $t : null;
    }

    // ------------------------------------------------------------------ locação por hora

    public const MODALIDADES = ['dia' => 'Por dia', 'hora' => 'Por hora'];
    public const HORA_PRIMEIRA = 6;     // primeira retirada possível: 06h
    public const HORA_LIMITE = 24;      // a devolução termina, no máximo, à meia-noite do mesmo dia
    public const HORAS_MAX = 12;

    /**
     * Valor da locação por hora: valor da hora x número de horas inteiras (de 1 a 12).
     *
     * @throws InvalidArgumentException
     */
    public static function calcularValorHora(float $precoHora, int $horas): float
    {
        if ($precoHora <= 0) {
            throw new InvalidArgumentException('Este veículo não está disponível para locação por hora.');
        }
        if ($horas < 1 || $horas > self::HORAS_MAX) {
            throw new InvalidArgumentException('A locação por hora vai de 1 a ' . self::HORAS_MAX . ' horas.');
        }
        return round($precoHora * $horas, 2);
    }

    /**
     * Monta a janela de uma locação por hora no mesmo dia: início em hora cheia (a partir das 06h)
     * e fim até 24h. Devolve [retirada, devolução] como 'Y-m-d H:i:s'.
     *
     * @return array{0: string, 1: string}
     * @throws InvalidArgumentException
     */
    public static function janelaPorHora(string $data, int $horaInicio, int $horas): array
    {
        $d = DateTimeImmutable::createFromFormat('!Y-m-d', $data);
        if ($d === false || $d->format('Y-m-d') !== $data) {
            throw new InvalidArgumentException('Data inválida.');
        }
        if ($horas < 1 || $horas > self::HORAS_MAX) {
            throw new InvalidArgumentException('A locação por hora vai de 1 a ' . self::HORAS_MAX . ' horas.');
        }
        if ($horaInicio < self::HORA_PRIMEIRA || $horaInicio + $horas > self::HORA_LIMITE) {
            throw new InvalidArgumentException('A locação por hora começa a partir das 06h e deve terminar até as 24h do mesmo dia.');
        }
        $ini = $d->modify("+$horaInicio hours");
        return [$ini->format('Y-m-d H:i:s'), $ini->modify("+$horas hours")->format('Y-m-d H:i:s')];
    }

    // ------------------------------------------------------------------ simulações (apenas informativas)

    public const PRAZOS_FINANCIAMENTO = [12, 24, 36, 48, 60];

    /**
     * Simulação de financiamento pela Tabela Price (parcelas fixas): PMT = PV * i / (1 - (1 + i)^-n).
     * É só uma estimativa: não inclui IOF, tarifas, seguro nem o CET da instituição financeira.
     *
     * @return array{financiado: float, parcela: float, total: float, juros: float, prazo: int, taxa: float}
     */
    public static function simularFinanciamento(float $preco, float $entrada, int $prazo, float $taxaMensal): array
    {
        if ($preco <= 0) {
            throw new InvalidArgumentException('Preço inválido.');
        }
        if ($entrada < 0 || $entrada >= $preco) {
            throw new InvalidArgumentException('A entrada deve ser maior ou igual a zero e menor que o preço do veículo.');
        }
        if (!in_array($prazo, self::PRAZOS_FINANCIAMENTO, true)) {
            throw new InvalidArgumentException('Escolha um prazo de 12 a 60 meses.');
        }
        if ($taxaMensal < 0 || $taxaMensal > 10) {
            throw new InvalidArgumentException('Informe uma taxa mensal entre 0% e 10%.');
        }
        $financiado = round($preco - $entrada, 2);
        $i = $taxaMensal / 100;
        $parcela = $i == 0.0
            ? $financiado / $prazo
            : $financiado * $i / (1 - pow(1 + $i, -$prazo));
        $parcela = round($parcela, 2);
        $total = round($parcela * $prazo + $entrada, 2);
        return [
            'financiado' => $financiado,
            'parcela'    => $parcela,
            'total'      => $total,
            'juros'      => round($parcela * $prazo - $financiado, 2),
            'prazo'      => $prazo,
            'taxa'       => $taxaMensal,
        ];
    }

    /**
     * Parcelamento do valor da locação, sem juros, em até 6 vezes.
     *
     * @return array{dias: int, total: float, parcelas: int, parcela: float}
     */
    public static function simularLocacao(float $diaria, int $dias, int $parcelas, int $maxDias = 60): array
    {
        if ($diaria <= 0) {
            throw new InvalidArgumentException('Valor da diária inválido.');
        }
        if ($dias < 1 || $dias > $maxDias) {
            throw new InvalidArgumentException("Informe de 1 a $maxDias dias.");
        }
        if ($parcelas < 1 || $parcelas > 6) {
            throw new InvalidArgumentException('Escolha de 1 a 6 parcelas.');
        }
        $total = round($diaria * $dias, 2);
        return ['dias' => $dias, 'total' => $total, 'parcelas' => $parcelas, 'parcela' => round($total / $parcelas, 2)];
    }

    // ------------------------------------------------------------------ permissões (RF18, RNF12)

    /** CT-U11 */
    public static function verificarPermissao(?string $perfil, string $acao): bool
    {
        return in_array($perfil ?? 'visitante', self::PERMISSOES[$acao] ?? [], true);
    }
}
