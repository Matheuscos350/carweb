<?php
declare(strict_types=1);

/**
 * Acesso ao MySQL via PDO. Todas as consultas usam parâmetros vinculados (prepared statements),
 * nunca concatenação de texto do usuário: isso evita injeção de SQL (RNF02, caso CT-N02).
 */
final class Database
{
    private static ?PDO $pdo = null;

    public static function pdo(): PDO
    {
        if (self::$pdo === null) {
            $c = config('db');
            $dsn = "mysql:host={$c['host']};port={$c['port']};dbname={$c['name']};charset={$c['charset']}";
            self::$pdo = new PDO($dsn, $c['user'], $c['pass'], [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        }
        return self::$pdo;
    }

    /**
     * Informa se a coluna existe. Permite que o cadastro de veículos funcione mesmo em um banco criado antes
     * da coluna preco_hora (quem não executou migracao_hora.sql). O resultado fica em cache durante a requisição.
     */
    public static function temColuna(string $tabela, string $coluna): bool
    {
        static $cache = [];
        $k = $tabela . '.' . $coluna;
        if (!isset($cache[$k])) {
            $cache[$k] = (int) self::valor(
                'SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$tabela, $coluna]
            ) > 0;
        }
        return $cache[$k];
    }

    public static function temTabela(string $tabela): bool
    {
        static $cache = [];
        if (!isset($cache[$tabela])) {
            $cache[$tabela] = (int) self::valor('SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?', [$tabela]) > 0;
        }
        return $cache[$tabela];
    }

    /** @return array<int, array<string, mixed>> */
    public static function todos(string $sql, array $params = []): array
    {
        $st = self::pdo()->prepare($sql);
        $st->execute($params);
        return $st->fetchAll();
    }

    /** @return array<string, mixed>|null */
    public static function um(string $sql, array $params = []): ?array
    {
        $st = self::pdo()->prepare($sql);
        $st->execute($params);
        $linha = $st->fetch();
        return $linha === false ? null : $linha;
    }

    public static function valor(string $sql, array $params = []): mixed
    {
        $st = self::pdo()->prepare($sql);
        $st->execute($params);
        return $st->fetchColumn();
    }

    /** Executa INSERT/UPDATE/DELETE e devolve o número de linhas afetadas. */
    public static function executar(string $sql, array $params = []): int
    {
        $st = self::pdo()->prepare($sql);
        $st->execute($params);
        return $st->rowCount();
    }

    public static function ultimoId(): int
    {
        return (int) self::pdo()->lastInsertId();
    }
}
