<?php
declare(strict_types=1);

final class View
{
    /** Renderiza app/views/<modelo>.php dentro do layout. */
    public static function render(string $modelo, array $dados = [], string $titulo = ''): void
    {
        extract($dados, EXTR_SKIP);
        ob_start();
        require APP . "/views/$modelo.php";
        $conteudo = ob_get_clean();
        require APP . '/views/layout.php';
    }

    /** Inclui um trecho reutilizável (ex.: cartão de veículo). */
    public static function parcial(string $modelo, array $dados = []): void
    {
        extract($dados, EXTR_SKIP);
        require APP . "/views/partials/$modelo.php";
    }
}
