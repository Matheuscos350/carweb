<?php
declare(strict_types=1);

/** Proteção contra CSRF: todo formulário POST leva um token aleatório, conferido no servidor (seção 6.4). */
final class Csrf
{
    public static function token(): string
    {
        if (empty($_SESSION['csrf'])) {
            $_SESSION['csrf'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf'];
    }

    public static function campo(): string
    {
        return '<input type="hidden" name="_csrf" value="' . e(self::token()) . '">';
    }

    public static function validar(): bool
    {
        $enviado = $_POST['_csrf'] ?? '';
        return is_string($enviado) && isset($_SESSION['csrf']) && hash_equals($_SESSION['csrf'], $enviado);
    }
}
