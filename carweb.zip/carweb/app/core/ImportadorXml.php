<?php
declare(strict_types=1);

/**
 * Lê e valida um arquivo XML de veículos (cadastro em lote). Não grava nada no banco: devolve os
 * veículos válidos e a lista de problemas, para que o controlador importe tudo ou nada.
 *
 * Segurança (XML externo é entrada não confiável): tamanho máximo, DOCTYPE/ENTITY proibidos (evita XXE e
 * "billion laughs"), LIBXML_NONET, sem carregar entidades externas e limite de veículos por arquivo.
 */
final class ImportadorXml
{
    public const MAX_BYTES = 1048576;   // 1 MB
    public const MAX_VEICULOS = 100;

    private const OBRIGATORIOS = ['finalidade', 'marca', 'modelo', 'ano', 'quilometragem', 'categoria', 'cambio', 'lugares', 'combustivel', 'preco'];
    private const OPCIONAIS = ['preco_hora', 'descricao'];
    private const ENUMS = ['finalidade', 'categoria', 'cambio', 'combustivel'];

    /**
     * @return array{veiculos: array<int, array<string, string>>, erros: array<int, string>}
     */
    public static function processar(string $xml): array
    {
        if (strlen($xml) > self::MAX_BYTES) {
            return self::falha('O arquivo é maior que 1 MB.');
        }
        if (trim($xml) === '') {
            return self::falha('O arquivo está vazio.');
        }
        if (preg_match('/<!(DOCTYPE|ENTITY)/i', $xml)) {
            return self::falha('O arquivo não pode conter DOCTYPE nem ENTITY (por segurança).');
        }

        $anterior = libxml_use_internal_errors(true);
        try {
            $raiz = simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NONET | LIBXML_NOCDATA);
            if ($raiz === false) {
                $e = libxml_get_errors();
                $linha = $e ? $e[0]->line : 0;
                return self::falha('O XML está mal formado' . ($linha ? " (perto da linha $linha)" : '')
                    . '. Confira se todas as tags foram fechadas e use &amp; no lugar de "&".');
            }
        } finally {
            libxml_clear_errors();
            libxml_use_internal_errors($anterior);
        }

        if ($raiz->getName() !== 'veiculos') {
            return self::falha('O elemento principal deve ser <veiculos>. Baixe o modelo e siga o formato.');
        }
        $itens = $raiz->children();
        $total = count($itens);
        if ($total === 0) {
            return self::falha('Nenhum <veiculo> foi encontrado no arquivo.');
        }
        if ($total > self::MAX_VEICULOS) {
            return self::falha('O arquivo tem ' . $total . ' veículos; o máximo por arquivo é ' . self::MAX_VEICULOS . '.');
        }

        $veiculos = [];
        $erros = [];
        $n = 0;
        foreach ($itens as $nome => $no) {
            $n++;
            if ($nome !== 'veiculo') {
                $erros[] = "Item $n: elemento <$nome> inesperado (use <veiculo>).";
                continue;
            }
            [$d, $problemas] = self::ler($no);
            if ($problemas) {
                $rotulo = trim(($d['marca'] ?? '') . ' ' . ($d['modelo'] ?? ''));
                foreach ($problemas as $p) {
                    $erros[] = "Veículo $n" . ($rotulo !== '' ? " ($rotulo)" : '') . ': ' . $p;
                }
                continue;
            }
            $veiculos[] = $d;
        }
        return ['veiculos' => $erros ? [] : $veiculos, 'erros' => $erros];
    }

    /** @return array{0: array<string, string>, 1: array<int, string>} */
    private static function ler(SimpleXMLElement $no): array
    {
        $d = [];
        $problemas = [];
        foreach ($no->children() as $campo => $valor) {
            if (!in_array($campo, [...self::OBRIGATORIOS, ...self::OPCIONAIS], true)) {
                $problemas[] = "campo desconhecido <$campo> (confira a grafia).";
                continue;
            }
            if (isset($d[$campo])) {
                $problemas[] = "campo <$campo> repetido.";
                continue;
            }
            $d[$campo] = trim((string) $valor);
        }
        foreach (self::OBRIGATORIOS as $c) {
            if (!isset($d[$c]) || $d[$c] === '') {
                $problemas[] = "campo <$c> é obrigatório.";
            }
        }
        foreach (self::ENUMS as $c) {
            if (isset($d[$c])) {
                $d[$c] = self::normalizar($d[$c]);
            }
        }
        foreach (['preco', 'preco_hora'] as $c) {
            if (isset($d[$c]) && $d[$c] !== '') {
                $v = Dominio::paraDecimal($d[$c]);
                $d[$c] = $v === null ? 'x' : (string) $v;      // 'x' faz a validação recusar
            }
        }
        $d += ['preco_hora' => '', 'descricao' => ''];
        if (($d['finalidade'] ?? '') === 'venda') {
            $d['preco_hora'] = '';                              // valor por hora só existe na locação
        }
        if (!$problemas) {
            foreach (Dominio::validarVeiculo($d) as $msg) {
                $problemas[] = $msg;
            }
        }
        return [$d, $problemas];
    }

    /** "Automático " -> "automatico", "Elétrico" -> "eletrico", "Locação" -> "locacao". */
    private static function normalizar(string $v): string
    {
        $v = mb_strtolower(trim($v));
        return strtr($v, ['á' => 'a', 'à' => 'a', 'â' => 'a', 'ã' => 'a', 'é' => 'e', 'ê' => 'e', 'í' => 'i',
                          'ó' => 'o', 'ô' => 'o', 'õ' => 'o', 'ú' => 'u', 'ç' => 'c']);
    }

    /** @return array{veiculos: array, erros: array<int, string>} */
    private static function falha(string $msg): array
    {
        return ['veiculos' => [], 'erros' => [$msg]];
    }
}
