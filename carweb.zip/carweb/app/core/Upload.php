<?php
declare(strict_types=1);

/**
 * Envio seguro de imagens (seção 6.4): só JPG e PNG, confere o tipo real do arquivo (não o nome),
 * limita o tamanho e renomeia com nome aleatório. A pasta uploads/ não executa scripts (.htaccess).
 */
final class Upload
{
    private const TIPOS = ['image/jpeg' => 'jpg', 'image/png' => 'png'];

    /** @return string|null nome do arquivo salvo, ou null se nenhum arquivo foi enviado */
    public static function salvarImagem(?array $arquivo): ?string
    {
        if ($arquivo === null || ($arquivo['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
            return null;
        }
        if ($arquivo['error'] !== UPLOAD_ERR_OK) {
            throw new RuntimeException('Não foi possível enviar a imagem. Tente novamente.');
        }
        if ($arquivo['size'] > (int) config('upload_max_bytes')) {
            throw new RuntimeException('A imagem deve ter no máximo 2 MB.');
        }
        $info = @getimagesize($arquivo['tmp_name']);
        $mime = class_exists('finfo') ? (new finfo(FILEINFO_MIME_TYPE))->file($arquivo['tmp_name']) : ($info['mime'] ?? '');
        if (!isset(self::TIPOS[$mime]) || @getimagesize($arquivo['tmp_name']) === false) {
            throw new RuntimeException('Envie uma imagem JPG ou PNG válida.');
        }
        $nome = bin2hex(random_bytes(16)) . '.' . self::TIPOS[$mime];
        $destino = ROOT . '/public/uploads/' . $nome;
        if (!move_uploaded_file($arquivo['tmp_name'], $destino)) {
            throw new RuntimeException('Não foi possível salvar a imagem.');
        }
        return $nome;
    }

    /**
     * Converte $_FILES['campo'] de envio múltiplo (name="campo[]") em uma lista de arquivos simples, ignorando campos vazios.
     * @return array<int, array<string, mixed>>
     */
    public static function normalizarMultiplos(?array $f): array
    {
        if ($f === null || !isset($f['name']) || !is_array($f['name'])) {
            return [];
        }
        $lista = [];
        foreach (array_keys($f['name']) as $i) {
            if (($f['error'][$i] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
                continue;
            }
            $lista[] = ['name' => $f['name'][$i], 'type' => $f['type'][$i] ?? '', 'tmp_name' => $f['tmp_name'][$i] ?? '',
                        'error' => $f['error'][$i], 'size' => $f['size'][$i] ?? 0];
        }
        return $lista;
    }

    /**
     * Salva várias imagens. Se uma falhar, as já salvas nesta chamada são apagadas e a exceção é repassada.
     * @return array<int, string>
     */
    public static function salvarVarias(?array $f): array
    {
        $salvos = [];
        try {
            foreach (self::normalizarMultiplos($f) as $arquivo) {
                $nome = self::salvarImagem($arquivo);
                if ($nome !== null) {
                    $salvos[] = $nome;
                }
            }
        } catch (RuntimeException $e) {
            foreach ($salvos as $n) {
                self::remover($n);
            }
            throw $e;
        }
        return $salvos;
    }

    public static function remover(?string $nome): void
    {
        if ($nome && preg_match('/^[a-f0-9]{32}\.(jpg|png)$/', $nome)) {
            @unlink(ROOT . '/public/uploads/' . $nome);
        }
    }
}
