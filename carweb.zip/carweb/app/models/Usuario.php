<?php
declare(strict_types=1);

final class Usuario
{
    public static function buscar(int $id): ?array
    {
        return Database::um('SELECT id, nome, email, senha_hash, telefone, perfil, ativo, criado_em FROM usuarios WHERE id = ?', [$id]);
    }

    public static function buscarPorEmail(string $email): ?array
    {
        return Database::um('SELECT id, nome, email, senha_hash, telefone, perfil, ativo FROM usuarios WHERE email = ?', [mb_strtolower($email)]);
    }

    /** O perfil já vem validado pelo controlador (administrador só com o código de segurança). */
    public static function criar(string $nome, string $email, string $hash, ?string $telefone, string $perfil = 'cliente'): int
    {
        self::inserir('INSERT INTO usuarios (nome, email, senha_hash, telefone, perfil) VALUES (?, ?, ?, ?, ?)',
            [$nome, mb_strtolower($email), $hash, $telefone, $perfil]);
        return self::conferirPerfil(Database::ultimoId(), $perfil);
    }

    /** Em modo estrito o banco recusa o tipo desconhecido (erro 1265); trata como perfil não suportado. */
    private static function inserir(string $sql, array $params): void
    {
        try {
            Database::executar($sql, $params);
        } catch (PDOException $e) {
            if ((int) ($e->errorInfo[1] ?? 0) === 1265) {
                throw new RuntimeException('perfil_nao_suportado');
            }
            throw $e;
        }
    }

    /**
     * Garante que o tipo de conta foi realmente gravado. Em banco criado antes do perfil "loja" (coluna ENUM antiga),
     * o MySQL/MariaDB em modo não estrito grava um valor vazio em silêncio; nesse caso o cadastro é desfeito.
     */
    private static function conferirPerfil(int $id, string $esperado): int
    {
        $gravado = (string) Database::valor('SELECT perfil FROM usuarios WHERE id = ?', [$id]);
        if ($gravado !== $esperado) {
            Database::executar('DELETE FROM usuarios WHERE id = ?', [$id]);
            throw new RuntimeException('perfil_nao_suportado');
        }
        return $id;
    }

    /** Uso exclusivo do script de carga inicial (database/seed.php). */
    public static function criarComPerfil(string $nome, string $email, string $hash, string $perfil): int
    {
        self::inserir('INSERT INTO usuarios (nome, email, senha_hash, perfil) VALUES (?, ?, ?, ?)',
            [$nome, mb_strtolower($email), $hash, $perfil]);
        return self::conferirPerfil(Database::ultimoId(), $perfil);
    }

    /** @return array<int, array<string, mixed>> */
    public static function todos(): array
    {
        return Database::todos('SELECT id, nome, email, telefone, perfil, ativo, criado_em FROM usuarios ORDER BY nome');
    }

    public static function atualizarDados(int $id, string $nome, ?string $telefone): void
    {
        Database::executar('UPDATE usuarios SET nome = ?, telefone = ? WHERE id = ?', [$nome, $telefone, $id]);
    }

    public static function atualizarSenha(int $id, string $hash): void
    {
        Database::executar('UPDATE usuarios SET senha_hash = ? WHERE id = ?', [$hash, $id]);
    }

    public static function definirPerfil(int $id, string $perfil): void
    {
        Database::executar('UPDATE usuarios SET perfil = ? WHERE id = ?', [$perfil, $id]);
    }

    public static function definirAtivo(int $id, bool $ativo): void
    {
        Database::executar('UPDATE usuarios SET ativo = ? WHERE id = ?', [$ativo ? 1 : 0, $id]);
    }

    public static function contar(): int
    {
        return (int) Database::valor('SELECT COUNT(*) FROM usuarios');
    }
}
