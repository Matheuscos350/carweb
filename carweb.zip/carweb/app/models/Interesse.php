<?php
declare(strict_types=1);

final class Interesse
{
    /** @throws DomainException se o usuário já demonstrou interesse neste veículo */
    public static function criar(int $veiculoId, int $usuarioId, ?string $mensagem): void
    {
        try {
            Database::executar(
                'INSERT INTO interesses (veiculo_id, usuario_id, mensagem) VALUES (?, ?, ?)',
                [$veiculoId, $usuarioId, $mensagem]
            );
        } catch (PDOException $e) {
            if ($e->getCode() === '23000') { // violação da chave única (veiculo_id, usuario_id)
                throw new DomainException('Você já demonstrou interesse neste veículo.');
            }
            throw $e;
        }
    }

    public static function existe(int $veiculoId, int $usuarioId): bool
    {
        return (int) Database::valor('SELECT COUNT(*) FROM interesses WHERE veiculo_id = ? AND usuario_id = ?', [$veiculoId, $usuarioId]) > 0;
    }

    /** @return array<int, array<string, mixed>> */
    public static function doUsuario(int $usuarioId): array
    {
        return Database::todos(
            'SELECT i.*, v.marca, v.modelo, v.preco FROM interesses i JOIN veiculos v ON v.id = i.veiculo_id
             WHERE i.usuario_id = ? ORDER BY i.id DESC',
            [$usuarioId]
        );
    }

    /**
     * Interessados nos veículos do anunciante. Os dados de contato só aparecem para o dono do veículo
     * (princípio da necessidade, seção 6.3). @return array<int, array<string, mixed>>
     */
    public static function doAnunciante(int $anuncianteId): array
    {
        return Database::todos(
            'SELECT i.*, v.marca, v.modelo, u.nome AS cliente_nome, u.email AS cliente_email, u.telefone AS cliente_telefone
             FROM interesses i JOIN veiculos v ON v.id = i.veiculo_id JOIN usuarios u ON u.id = i.usuario_id
             WHERE v.anunciante_id = ? ORDER BY i.id DESC',
            [$anuncianteId]
        );
    }
}
