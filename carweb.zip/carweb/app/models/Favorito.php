<?php
declare(strict_types=1);

/** Veículos favoritados pelo usuário (lista de desejos). */
final class Favorito
{
    /** Liga ou desliga o favorito. Devolve true se ficou favoritado. */
    public static function alternar(int $usuarioId, int $veiculoId): bool
    {
        if (self::existe($usuarioId, $veiculoId)) {
            Database::executar('DELETE FROM favoritos WHERE usuario_id = ? AND veiculo_id = ?', [$usuarioId, $veiculoId]);
            return false;
        }
        try {
            Database::executar('INSERT INTO favoritos (usuario_id, veiculo_id) VALUES (?, ?)', [$usuarioId, $veiculoId]);
        } catch (PDOException $e) {
            if ($e->getCode() !== '23000') {   // duplicado por clique duplo: já está favoritado
                throw $e;
            }
        }
        return true;
    }

    public static function existe(int $usuarioId, int $veiculoId): bool
    {
        return (int) Database::valor('SELECT COUNT(*) FROM favoritos WHERE usuario_id = ? AND veiculo_id = ?', [$usuarioId, $veiculoId]) > 0;
    }

    /** @return array<int, true> ids dos veículos favoritados (para marcar os corações nas listas) */
    public static function ids(int $usuarioId): array
    {
        $r = Database::todos('SELECT veiculo_id FROM favoritos WHERE usuario_id = ?', [$usuarioId]);
        return array_fill_keys(array_map('intval', array_column($r, 'veiculo_id')), true);
    }

    /** @return array<int, array<string, mixed>> */
    public static function doUsuario(int $usuarioId): array
    {
        return Veiculo::dosFavoritos($usuarioId);
    }
}
