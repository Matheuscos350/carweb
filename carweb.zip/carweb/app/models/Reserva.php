<?php
declare(strict_types=1);

final class Reserva
{
    private const ATIVAS = "('pendente','confirmada')";

    /** Há reserva ativa em conflito com o período? (mesma regra de Dominio::verificarConflito, aplicada no banco) */
    public static function existeConflito(int $veiculoId, string $retirada, string $devolucao): bool
    {
        return (int) Database::valor(
            'SELECT COUNT(*) FROM reservas WHERE veiculo_id = ? AND status IN ' . self::ATIVAS . ' AND ? < data_devolucao AND ? > data_retirada',
            [$veiculoId, $retirada, $devolucao]
        ) > 0;
    }

    /**
     * Cria a reserva dentro de uma transação (RNF04). O veículo é travado (FOR UPDATE) enquanto o conflito é
     * verificado, para que duas solicitações simultâneas não reservem o mesmo período.
     *
     * @throws DomainException quando a reserva não pode ser feita
     */
    public static function criar(int $veiculoId, int $usuarioId, string $modalidade, string $retirada, string $devolucao, string $nome, string $tipoDoc, string $documento): int
    {
        $pdo = Database::pdo();
        $pdo->beginTransaction();
        try {
            $v = Database::um('SELECT * FROM veiculos WHERE id = ? FOR UPDATE', [$veiculoId]);
            if ($v === null || $v['finalidade'] !== 'locacao' || $v['status'] !== 'disponivel') {
                throw new DomainException('Este veículo não está disponível para locação.');
            }
            if ((int) $v['anunciante_id'] === $usuarioId) {
                throw new DomainException('Você não pode alugar o seu próprio veículo.');
            }
            if (self::existeConflito($veiculoId, $retirada, $devolucao)) {
                throw new DomainException('O veículo já está reservado em parte do período escolhido.');
            }
            if ($modalidade === 'hora') {
                if (($v['preco_hora'] ?? null) === null) {
                    throw new DomainException('Este veículo não é alugado por hora.');
                }
                $horas = (int) round((strtotime($devolucao) - strtotime($retirada)) / 3600);
                $valor = Dominio::calcularValorHora((float) ($v['preco_hora'] ?? null), $horas);
            } else {
                $modalidade = 'dia';
                $valor = Dominio::calcularValorLocacao((float) $v['preco'], substr($retirada, 0, 10), substr($devolucao, 0, 10));
            }
            Database::executar(
                'INSERT INTO reservas (veiculo_id, usuario_id, modalidade, data_retirada, data_devolucao, valor_total, nome_locatario, tipo_documento, documento)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                [$veiculoId, $usuarioId, $modalidade, $retirada, $devolucao, $valor, $nome, $tipoDoc, $documento]
            );
            $id = Database::ultimoId();
            $pdo->commit();
            return $id;
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }
    }

    public static function buscar(int $id): ?array
    {
        return Database::um(
            'SELECT r.*, v.anunciante_id, v.marca, v.modelo FROM reservas r JOIN veiculos v ON v.id = r.veiculo_id WHERE r.id = ?',
            [$id]
        );
    }

    /** @return array<int, array<string, mixed>> */
    public static function doUsuario(int $usuarioId): array
    {
        return Database::todos(
            'SELECT r.*, v.marca, v.modelo, v.id AS veiculo_id FROM reservas r JOIN veiculos v ON v.id = r.veiculo_id
             WHERE r.usuario_id = ? ORDER BY r.id DESC',
            [$usuarioId]
        );
    }

    /** Solicitações de locação recebidas pelo anunciante (somente dos veículos dele). @return array<int, array<string, mixed>> */
    public static function doAnunciante(int $anuncianteId): array
    {
        return Database::todos(
            'SELECT r.*, v.marca, v.modelo, u.nome AS cliente_nome, u.email AS cliente_email, u.telefone AS cliente_telefone
             FROM reservas r JOIN veiculos v ON v.id = r.veiculo_id JOIN usuarios u ON u.id = r.usuario_id
             WHERE v.anunciante_id = ? ORDER BY r.id DESC',
            [$anuncianteId]
        );
    }

    /** Períodos já ocupados (apenas datas, nenhum dado pessoal) para mostrar na página do veículo. */
    public static function periodosOcupados(int $veiculoId): array
    {
        return Database::todos(
            'SELECT modalidade, data_retirada, data_devolucao FROM reservas WHERE veiculo_id = ? AND status IN ' . self::ATIVAS . '
             AND data_devolucao >= NOW() ORDER BY data_retirada',
            [$veiculoId]
        );
    }

    /** Quantidade de solicitações aguardando resposta do anunciante. */
    public static function pendentesDoAnunciante(int $anuncianteId): int
    {
        return (int) Database::valor(
            "SELECT COUNT(*) FROM reservas r JOIN veiculos v ON v.id = r.veiculo_id WHERE v.anunciante_id = ? AND r.status = 'pendente'",
            [$anuncianteId]
        );
    }

    public static function definirStatus(int $id, string $status): void
    {
        Database::executar('UPDATE reservas SET status = ? WHERE id = ?', [$status, $id]);
    }

    /** @return array<string, int> */
    public static function contarPorStatus(): array
    {
        $r = Database::todos('SELECT status, COUNT(*) AS n FROM reservas GROUP BY status');
        return array_column($r, 'n', 'status');
    }
}
