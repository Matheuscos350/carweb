<?php
declare(strict_types=1);

final class Veiculo
{
    /** Colunas + situação calculada: alugado hoje (reserva confirmada em andamento) ou reservado para o futuro. */
    private const BASE = "SELECT v.*, u.nome AS anunciante_nome,
        EXISTS(SELECT 1 FROM reservas r WHERE r.veiculo_id = v.id AND r.status = 'confirmada'
               AND NOW() >= r.data_retirada AND NOW() < r.data_devolucao) AS alugado_hoje,
        EXISTS(SELECT 1 FROM reservas r WHERE r.veiculo_id = v.id AND r.status IN ('pendente','confirmada')
               AND r.data_retirada > NOW()) AS reservado_futuro
        FROM veiculos v JOIN usuarios u ON u.id = v.anunciante_id";

    private const ORDEM = [
        'recomendados' => 'v.id DESC',
        'menor_preco'  => 'v.preco ASC',
        'maior_preco'  => 'v.preco DESC',
        'mais_novos'   => 'v.ano DESC, v.id DESC',
    ];

    public static function buscar(int $id): ?array
    {
        return Database::um(self::BASE . ' WHERE v.id = ?', [$id]);
    }

    public const MAX_FOTOS_EXTRAS = 8;

    /** Fotos adicionais (carrossel). Vazio se a tabela ainda não existe (banco sem a migração de fotos). */
    public static function fotosExtras(int $id): array
    {
        if (!Database::temTabela('veiculo_fotos')) {
            return [];
        }
        return Database::todos('SELECT id, arquivo FROM veiculo_fotos WHERE veiculo_id = ? ORDER BY id', [$id]);
    }

    /** Arquivos do carrossel: a capa primeiro e depois as fotos adicionais. */
    public static function galeria(array $v): array
    {
        $arquivos = $v['imagem'] ? [$v['imagem']] : [];
        foreach (self::fotosExtras((int) $v['id']) as $f) {
            $arquivos[] = $f['arquivo'];
        }
        return $arquivos;
    }

    /** @param array<int, string> $arquivos */
    public static function adicionarFotos(int $id, array $arquivos): void
    {
        if (!Database::temTabela('veiculo_fotos')) {
            return;
        }
        foreach ($arquivos as $a) {
            Database::executar('INSERT INTO veiculo_fotos (veiculo_id, arquivo) VALUES (?, ?)', [$id, $a]);
        }
    }

    /** Remove fotos adicionais do veículo (só as que pertencem a ele) e apaga os arquivos. */
    public static function removerFotos(int $id, array $ids): void
    {
        if (!Database::temTabela('veiculo_fotos')) {
            return;
        }
        foreach (array_unique(array_map('intval', $ids)) as $fid) {
            $nome = Database::valor('SELECT arquivo FROM veiculo_fotos WHERE id = ? AND veiculo_id = ?', [$fid, $id]);
            if ($nome) {
                Database::executar('DELETE FROM veiculo_fotos WHERE id = ? AND veiculo_id = ?', [$fid, $id]);
                Upload::remover((string) $nome);
            }
        }
    }

    /** Situação exibida ao público (RF14): combina o status gravado com as reservas em andamento. */
    public static function situacao(array $v): string
    {
        if ($v['status'] !== 'disponivel') {
            return $v['status'];
        }
        if (!empty($v['alugado_hoje'])) {
            return 'alugado';
        }
        return !empty($v['reservado_futuro']) ? 'reservado' : 'disponivel';
    }

    /**
     * Pesquisa com filtros (RF07, RF08). Quando há período de retirada/devolução, esconde os veículos
     * que já têm reserva em conflito (RF15).
     *
     * @return array{itens: array<int, array<string, mixed>>, total: int}
     */
    public static function pesquisar(array $f, int $pagina, int $porPagina): array
    {
        $onde = ["v.status = 'disponivel'"];
        $p = [];
        if (isset(Dominio::FINALIDADES[$f['finalidade'] ?? ''])) {
            $onde[] = 'v.finalidade = ?';
            $p[] = $f['finalidade'];
        }
        if (isset(Dominio::CATEGORIAS[$f['categoria'] ?? ''])) {
            $onde[] = 'v.categoria = ?';
            $p[] = $f['categoria'];
        }
        $max = Dominio::paraDecimal((string) ($f['preco_max'] ?? ''));
        if ($max !== null && $max > 0) {
            $onde[] = 'v.preco <= ?';
            $p[] = $max;
        }
        if (isset(Dominio::CAMBIOS[$f['cambio'] ?? ''])) {
            $onde[] = 'v.cambio = ?';
            $p[] = $f['cambio'];
        }
        if (isset(Dominio::COMBUSTIVEIS[$f['combustivel'] ?? ''])) {
            $onde[] = 'v.combustivel = ?';
            $p[] = $f['combustivel'];
        }
        $anoMin = filter_var($f['ano_min'] ?? null, FILTER_VALIDATE_INT);
        if ($anoMin !== false && $anoMin >= 1950) {
            $onde[] = 'v.ano >= ?';
            $p[] = $anoMin;
        }
        $q = trim((string) ($f['q'] ?? ''));
        if ($q !== '') {
            $like = '%' . addcslashes(mb_substr($q, 0, 60), '%_\\') . '%';
            $onde[] = '(v.marca LIKE ? OR v.modelo LIKE ?)';
            array_push($p, $like, $like);
        }
        $ini = (string) ($f['retirada'] ?? '');
        $fim = (string) ($f['devolucao'] ?? '');
        if (($f['finalidade'] ?? '') === 'locacao' && $ini !== '' && $fim !== '') {
            try {
                Dominio::dias($ini, $fim);
                $onde[] = "NOT EXISTS (SELECT 1 FROM reservas r WHERE r.veiculo_id = v.id
                           AND r.status IN ('pendente','confirmada') AND ? < r.data_devolucao AND ? > r.data_retirada)";
                array_push($p, $ini . ' 00:00:00', $fim . ' 00:00:00');
            } catch (InvalidArgumentException) {
                // datas inválidas: ignora o filtro de período
            }
        }
        $clausula = ' WHERE ' . implode(' AND ', $onde);
        $ordem = self::ORDEM[$f['ordem'] ?? ''] ?? self::ORDEM['recomendados'];

        $total = (int) Database::valor('SELECT COUNT(*) FROM veiculos v' . $clausula, $p);
        $limite = max(1, $porPagina);
        $desloc = max(0, ($pagina - 1) * $limite);
        $itens = Database::todos(self::BASE . $clausula . " ORDER BY $ordem LIMIT $limite OFFSET $desloc", $p);
        return ['itens' => $itens, 'total' => $total];
    }

    /** @return array<int, array<string, mixed>> */
    public static function ofertas(string $finalidade, int $limite = 6): array
    {
        $limite = max(1, $limite);
        return Database::todos(
            self::BASE . " WHERE v.status = 'disponivel' AND v.finalidade = ? ORDER BY v.preco ASC LIMIT $limite",
            [$finalidade]
        );
    }

    /** @return array<int, array<string, mixed>> */
    public static function semelhantes(array $v, int $limite = 3): array
    {
        $limite = max(1, $limite);
        return Database::todos(
            self::BASE . " WHERE v.status = 'disponivel' AND v.id <> ? AND v.finalidade = ?
             ORDER BY (v.categoria = ?) DESC, ABS(v.preco - ?) ASC LIMIT $limite",
            [$v['id'], $v['finalidade'], $v['categoria'], $v['preco']]
        );
    }

    /** @return array<int, array<string, mixed>> */
    public static function dosFavoritos(int $usuarioId): array
    {
        return Database::todos(
            self::BASE . ' JOIN favoritos f ON f.veiculo_id = v.id WHERE f.usuario_id = ? ORDER BY f.id DESC',
            [$usuarioId]
        );
    }

    /** Números da vitrine (home): veículos disponíveis para cada finalidade. */
    public static function totaisDisponiveis(): array
    {
        $r = Database::todos("SELECT finalidade, COUNT(*) AS n FROM veiculos WHERE status = 'disponivel' GROUP BY finalidade");
        $t = array_column($r, 'n', 'finalidade');
        return ['locacao' => (int) ($t['locacao'] ?? 0), 'venda' => (int) ($t['venda'] ?? 0)];
    }

    /** @return array<int, array<string, mixed>> */
    public static function doAnunciante(int $anuncianteId): array
    {
        return Database::todos(self::BASE . ' WHERE v.anunciante_id = ? ORDER BY v.id DESC', [$anuncianteId]);
    }

    /** @return array<int, array<string, mixed>> */
    public static function todosParaAdmin(): array
    {
        return Database::todos(self::BASE . ' ORDER BY v.id DESC');
    }

    /** Valor por hora (só existe em anúncios de locação; em branco = não aluga por hora). */
    private static function precoHora(array $d): ?float
    {
        $h = $d['preco_hora'] ?? '';
        return ($d['finalidade'] ?? '') === 'locacao' && $h !== '' && $h !== null ? (float) $h : null;
    }

    public static function criar(int $anuncianteId, array $d, ?string $imagem): int
    {
        $colunas = ['anunciante_id' => $anuncianteId, 'finalidade' => $d['finalidade'], 'marca' => $d['marca'], 'modelo' => $d['modelo'],
            'ano' => (int) $d['ano'], 'quilometragem' => (int) $d['quilometragem'], 'categoria' => $d['categoria'], 'cambio' => $d['cambio'],
            'lugares' => (int) $d['lugares'], 'combustivel' => $d['combustivel'], 'descricao' => ($d['descricao'] ?? '') ?: null,
            'preco' => (float) $d['preco'], 'imagem' => $imagem];
        // preco_hora só existe após a migração do aluguel por hora; sem ela, o anúncio é gravado sem esse campo.
        if (Database::temColuna('veiculos', 'preco_hora')) {
            $colunas['preco_hora'] = self::precoHora($d);
        }
        Database::executar(
            'INSERT INTO veiculos (' . implode(', ', array_keys($colunas)) . ') VALUES (' . implode(', ', array_fill(0, count($colunas), '?')) . ')',
            array_values($colunas)
        );
        return Database::ultimoId();
    }

    public static function atualizar(int $id, array $d, ?string $imagem): void
    {
        $sql = 'UPDATE veiculos SET marca = ?, modelo = ?, ano = ?, quilometragem = ?, categoria = ?, cambio = ?, lugares = ?,
                combustivel = ?, descricao = ?, preco = ?, status = ?';
        $p = [$d['marca'], $d['modelo'], (int) $d['ano'], (int) $d['quilometragem'], $d['categoria'], $d['cambio'],
              (int) $d['lugares'], $d['combustivel'], $d['descricao'] ?: null, (float) $d['preco'], $d['status']];
        if (Database::temColuna('veiculos', 'preco_hora')) {
            $sql .= ', preco_hora = ?';
            $p[] = self::precoHora($d);
        }
        if ($imagem !== null) {
            $sql .= ', imagem = ?';
            $p[] = $imagem;
        }
        Database::executar($sql . ' WHERE id = ?', [...$p, $id]);
    }

    public static function definirStatus(int $id, string $status): void
    {
        Database::executar('UPDATE veiculos SET status = ? WHERE id = ?', [$status, $id]);
    }

    /** @return array<string, int> */
    public static function contarPorStatus(): array
    {
        $r = Database::todos('SELECT status, COUNT(*) AS n FROM veiculos GROUP BY status');
        return array_column($r, 'n', 'status');
    }
}
