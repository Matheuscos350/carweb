<?php
declare(strict_types=1);

/** Área "minha conta": dados pessoais, troca de senha e favoritos. */
final class ContaController
{
    public static function formulario(): void
    {
        Auth::exigir('demonstrar_interesse');
        View::render('conta/minha_conta', ['u' => Auth::usuario()], 'Minha conta');
    }

    public static function salvarDados(): void
    {
        Auth::exigir('demonstrar_interesse');
        $nome = post('nome');
        $tel = post('telefone');
        $erros = [];
        if (mb_strlen($nome) < 3 || mb_strlen($nome) > 120) {
            $erros[] = 'Informe seu nome completo.';
        }
        if ($tel !== '' && !Dominio::validarTelefone($tel)) {
            $erros[] = 'Telefone inválido. Use DDD + número.';
        }
        if ($erros) {
            foreach ($erros as $e) {
                Flash::adicionar('erro', $e);
            }
            redirect('/minha-conta');
        }
        Usuario::atualizarDados((int) Auth::id(), $nome, $tel !== '' ? preg_replace('/\D/', '', $tel) : null);
        Flash::adicionar('ok', 'Dados atualizados.');
        redirect('/minha-conta');
    }

    public static function trocarSenha(): void
    {
        Auth::exigir('demonstrar_interesse');
        $atual = is_string($_POST['senha_atual'] ?? null) ? $_POST['senha_atual'] : '';
        $nova = is_string($_POST['senha_nova'] ?? null) ? $_POST['senha_nova'] : '';
        $conf = is_string($_POST['senha_nova2'] ?? null) ? $_POST['senha_nova2'] : '';
        $u = Usuario::buscar((int) Auth::id());
        if ($u === null || !Dominio::verificarSenha($atual, $u['senha_hash'])) {
            Flash::adicionar('erro', 'A senha atual não confere.');
        } elseif (!Dominio::validarSenha($nova)) {
            Flash::adicionar('erro', 'A nova senha deve ter de 8 a 72 caracteres, com letras e números.');
        } elseif ($nova !== $conf) {
            Flash::adicionar('erro', 'A confirmação da nova senha não confere.');
        } else {
            Usuario::atualizarSenha((int) $u['id'], Dominio::gerarHashSenha($nova));
            session_regenerate_id(true);
            Flash::adicionar('ok', 'Senha alterada com sucesso.');
        }
        redirect('/minha-conta');
    }

    public static function favoritos(): void
    {
        Auth::exigir('demonstrar_interesse');
        View::render('conta/favoritos', ['itens' => Favorito::doUsuario((int) Auth::id())], 'Favoritos');
    }

    public static function alternarFavorito(int $veiculoId): void
    {
        Auth::exigir('demonstrar_interesse');
        $v = Veiculo::buscar($veiculoId);
        if ($v === null || $v['status'] === 'inativo') {
            abort(404);
        }
        $agora = Favorito::alternar((int) Auth::id(), $veiculoId);
        Flash::adicionar('ok', $agora ? 'Adicionado aos favoritos.' : 'Removido dos favoritos.');
        // Volta para a página de origem, só se for do próprio site (evita redirecionamento aberto).
        $volta = (string) ($_POST['volta'] ?? '');
        redirect(preg_match('#^/[A-Za-z0-9/_\-?=&%.]*$#', $volta) && !str_starts_with($volta, '//') ? $volta : "/veiculo/$veiculoId");
    }
}
