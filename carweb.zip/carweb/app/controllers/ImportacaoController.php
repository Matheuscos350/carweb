<?php
declare(strict_types=1);

/** Cadastro de veículos em lote por arquivo XML (anunciantes, lojas e administradores). */
final class ImportacaoController
{
    public static function formulario(): void
    {
        Auth::exigir('anunciar');
        View::render('veiculos/importar', ['erros' => [], 'enviado' => false], 'Importar veículos');
    }

    /** Baixa o modelo de XML (o mesmo arquivo database/modelo_veiculos.xml). */
    public static function modelo(): void
    {
        Auth::exigir('anunciar');
        $arquivo = ROOT . '/database/modelo_veiculos.xml';
        if (!is_file($arquivo)) {
            abort(404);
        }
        header('Content-Type: application/xml; charset=utf-8');
        header('Content-Disposition: attachment; filename="modelo_veiculos_carweb.xml"');
        header('Content-Length: ' . filesize($arquivo));
        readfile($arquivo);
        exit;
    }

    public static function importar(): void
    {
        Auth::exigir('anunciar');
        $f = $_FILES['arquivo'] ?? null;
        $erros = [];
        $xml = '';
        if (!is_array($f) || ($f['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
            $erros[] = 'Escolha um arquivo XML para enviar.';
        } elseif ($f['error'] === UPLOAD_ERR_INI_SIZE || $f['error'] === UPLOAD_ERR_FORM_SIZE || ($f['size'] ?? 0) > ImportadorXml::MAX_BYTES) {
            $erros[] = 'O arquivo é maior que 1 MB.';
        } elseif ($f['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($f['tmp_name'])) {
            $erros[] = 'Não foi possível receber o arquivo. Tente novamente.';
        } elseif (strtolower(pathinfo((string) $f['name'], PATHINFO_EXTENSION)) !== 'xml') {
            $erros[] = 'O arquivo precisa ter a extensão .xml.';
        } else {
            $xml = (string) file_get_contents($f['tmp_name'], false, null, 0, ImportadorXml::MAX_BYTES + 1);
        }

        $veiculos = [];
        if (!$erros) {
            $r = ImportadorXml::processar($xml);
            $erros = $r['erros'];
            $veiculos = $r['veiculos'];
        }

        if (!$erros) {
            $uid = (int) Auth::id();
            $pdo = Database::pdo();
            $pdo->beginTransaction();
            try {
                foreach ($veiculos as $d) {
                    Veiculo::criar($uid, $d, null);
                }
                $pdo->commit();
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                throw $e;
            }
            Flash::adicionar('ok', count($veiculos) . (count($veiculos) === 1 ? ' veículo importado' : ' veículos importados') . ' com sucesso. Adicione as fotos em “Editar”.');
            redirect('/meus-veiculos');
        }

        View::render('veiculos/importar', ['erros' => $erros, 'enviado' => true], 'Importar veículos');
    }
}
