<?php
declare(strict_types=1);

final class ReservaController
{
    // ------------------------------------------------------------ cliente (RF11, RF12, RF16, RF20)

    public static function reservar(int $veiculoId): void
    {
        Auth::exigir('solicitar_locacao');
        $v = Veiculo::buscar($veiculoId);
        if ($v === null || $v['finalidade'] !== 'locacao') {
            abort(404);
        }

        $modalidade = post('modalidade') === 'hora' ? 'hora' : 'dia';
        $nome = post('nome');
        $tipo = post('tipo_documento');
        $doc = preg_replace('/\D/', '', post('documento')) ?? '';

        $erros = [];
        $ini = $fim = '';
        try {
            if ($modalidade === 'hora') {
                if (($v['preco_hora'] ?? null) === null) {
                    throw new InvalidArgumentException('Este veículo não é alugado por hora.');
                }
                [$ini, $fim] = Dominio::janelaPorHora(post('data_hora'), (int) post('hora_inicio'), (int) post('horas'));
                if (strtotime($ini) <= time()) {
                    $erros[] = 'O horário de retirada precisa ser futuro.';
                }
            } else {
                $dataIni = post('retirada');
                $dataFim = post('devolucao');
                $dias = Dominio::dias($dataIni, $dataFim);
                if ($dataIni < date('Y-m-d')) {
                    $erros[] = 'A data de retirada não pode estar no passado.';
                }
                if ($dias > (int) config('max_dias_locacao', 60)) {
                    $erros[] = 'O período máximo de locação é de ' . config('max_dias_locacao') . ' dias.';
                }
                [$ini, $fim] = [$dataIni . ' 00:00:00', $dataFim . ' 00:00:00'];
            }
        } catch (InvalidArgumentException $e) {
            $erros[] = $e->getMessage();
        }
        if (mb_strlen($nome) < 3 || mb_strlen($nome) > 120) {
            $erros[] = 'Informe o nome completo do locatário.';
        }
        if (!Dominio::validarDocumento($tipo, $doc)) {
            $erros[] = 'Documento inválido. Confira o número do ' . ($tipo === 'cnh' ? 'CNH' : 'CPF') . '.';
        }
        if ($erros) {
            foreach ($erros as $e) {
                Flash::adicionar('erro', $e);
            }
            Flash::guardarEntrada($_POST);
            redirect("/veiculo/$veiculoId");
        }

        try {
            Reserva::criar($veiculoId, (int) Auth::id(), $modalidade, $ini, $fim, $nome, $tipo, $doc);
            Flash::adicionar('ok', 'Solicitação de locação enviada! Aguarde a confirmação do anunciante.');
            redirect('/minhas-reservas');
        } catch (DomainException $e) {
            Flash::adicionar('erro', $e->getMessage());
            Flash::guardarEntrada($_POST);
            redirect("/veiculo/$veiculoId");
        }
    }

    /** Demonstração de interesse: simula a negociação de compra, sem pagamento (RF11, RF20). */
    public static function interesse(int $veiculoId): void
    {
        Auth::exigir('demonstrar_interesse');
        $v = Veiculo::buscar($veiculoId);
        if ($v === null || $v['finalidade'] !== 'venda' || $v['status'] !== 'disponivel') {
            abort(404);
        }
        if ((int) $v['anunciante_id'] === Auth::id()) {
            Flash::adicionar('erro', 'Você não pode demonstrar interesse no seu próprio anúncio.');
            redirect("/veiculo/$veiculoId");
        }
        $msg = post('mensagem');
        if (mb_strlen($msg) > 300) {
            Flash::adicionar('erro', 'A mensagem pode ter até 300 caracteres.');
            redirect("/veiculo/$veiculoId");
        }
        try {
            Interesse::criar($veiculoId, (int) Auth::id(), $msg !== '' ? $msg : null);
            Flash::adicionar('ok', 'Interesse registrado! O anunciante poderá entrar em contato com você.');
        } catch (DomainException $e) {
            Flash::adicionar('erro', $e->getMessage());
        }
        redirect("/veiculo/$veiculoId");
    }

    public static function minhas(): void
    {
        Auth::exigir('solicitar_locacao');
        $uid = (int) Auth::id();
        View::render('reservas/minhas', [
            'reservas'   => Reserva::doUsuario($uid),
            'interesses' => Interesse::doUsuario($uid),
        ], 'Minhas reservas');
    }

    public static function cancelar(int $id): void
    {
        Auth::exigir('solicitar_locacao');
        $r = Reserva::buscar($id);
        if ($r === null || (int) $r['usuario_id'] !== Auth::id()) {
            abort(404);   // não revela se a reserva existe para outro usuário
        }
        if (in_array($r['status'], ['pendente', 'confirmada'], true) && $r['data_retirada'] > date('Y-m-d', strtotime('-1 day'))) {
            Reserva::definirStatus($id, 'cancelada');
            Flash::adicionar('ok', 'Reserva cancelada.');
        } else {
            Flash::adicionar('erro', 'Esta reserva não pode mais ser cancelada.');
        }
        redirect('/minhas-reservas');
    }

    // ------------------------------------------------------------ anunciante (RF13)

    public static function solicitacoes(): void
    {
        Auth::exigir('ver_solicitacoes_proprias');
        $uid = (int) Auth::id();
        View::render('reservas/solicitacoes', [
            'reservas'   => Reserva::doAnunciante($uid),
            'interesses' => Interesse::doAnunciante($uid),
        ], 'Solicitações recebidas');
    }

    public static function atualizarStatus(int $id): void
    {
        Auth::exigir('ver_solicitacoes_proprias');
        $r = Reserva::buscar($id);
        // Só o dono do veículo (ou o administrador) mexe na reserva.
        if ($r === null || ((int) $r['anunciante_id'] !== Auth::id() && !Auth::pode('area_admin'))) {
            abort(404);
        }
        $novo = post('status');
        $permitidas = ['pendente' => ['confirmada', 'cancelada'], 'confirmada' => ['concluida', 'cancelada']];
        if (!in_array($novo, $permitidas[$r['status']] ?? [], true)) {
            Flash::adicionar('erro', 'Mudança de situação não permitida.');
        } else {
            Reserva::definirStatus($id, $novo);
            Flash::adicionar('ok', 'Reserva atualizada.');
        }
        redirect('/solicitacoes');
    }
}
