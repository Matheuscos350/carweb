<?php
declare(strict_types=1);

/**
 * Página de diagnóstico da instalação (só abre em localhost). Confere versão do PHP, extensões, pastas graváveis,
 * conexão com o banco e se as tabelas/colunas estão na versão atual, e indica a migração necessária.
 */
final class DiagnosticoController
{
    private const ESQUEMA = [
        'usuarios'   => ['id', 'nome', 'email', 'senha_hash', 'telefone', 'perfil', 'ativo', 'criado_em'],
        'veiculos'   => ['id', 'anunciante_id', 'finalidade', 'marca', 'modelo', 'ano', 'quilometragem', 'categoria', 'cambio', 'lugares', 'combustivel', 'descricao', 'preco', 'preco_hora', 'status', 'imagem', 'criado_em'],
        'reservas'   => ['id', 'veiculo_id', 'usuario_id', 'modalidade', 'data_retirada', 'data_devolucao', 'valor_total', 'nome_locatario', 'tipo_documento', 'documento', 'status', 'criado_em'],
        'interesses' => ['id', 'veiculo_id', 'usuario_id', 'mensagem', 'criado_em'],
        'veiculo_fotos' => ['id', 'veiculo_id', 'arquivo', 'criado_em'],
        'favoritos'  => ['id', 'usuario_id', 'veiculo_id', 'criado_em'],
    ];

    public static function mostrar(): void
    {
        if (!in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1'], true)) {
            abort(404);
        }
        $itens = [];
        $ok = static function (string $nome, bool $bom, string $msg) use (&$itens): void {
            $itens[] = ['nome' => $nome, 'ok' => $bom, 'msg' => $msg];
        };

        $ok('Versão do PHP', version_compare(PHP_VERSION, '8.0.0', '>='), PHP_VERSION . ' (mínimo 8.0)');
        foreach (['pdo_mysql', 'mbstring', 'fileinfo'] as $ext) {
            $ok("Extensão $ext", extension_loaded($ext), extension_loaded($ext) ? 'ativa' : 'desativada: ative em php.ini (remova o ; da linha extension=' . $ext . ') e reinicie o Apache');
        }
        foreach (['public/uploads', 'storage/logs'] as $dir) {
            $ok("Pasta $dir", is_dir(ROOT . "/$dir") && is_writable(ROOT . "/$dir"), is_dir(ROOT . "/$dir") ? (is_writable(ROOT . "/$dir") ? 'gravável' : 'sem permissão de escrita') : 'não existe: crie a pasta');
        }
        $ok('Limite de upload do PHP', true, 'upload_max_filesize=' . ini_get('upload_max_filesize') . ', post_max_size=' . ini_get('post_max_size') . ', file_uploads=' . (ini_get('file_uploads') ? 'on' : 'off'));

        $conectou = false;
        try {
            Database::valor('SELECT 1');
            $conectou = true;
            $ok('Conexão com o banco', true, 'conectado a "' . Database::valor('SELECT DATABASE()') . '" (' . Database::valor('SELECT VERSION()') . ')');
        } catch (Throwable $e) {
            $ok('Conexão com o banco', false, $e->getMessage());
        }

        $migracao = false;
        if ($conectou) {
            foreach (self::ESQUEMA as $tabela => $colunas) {
                $existentes = array_column(Database::todos(
                    'SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?', [$tabela]
                ), 'COLUMN_NAME');
                if (!$existentes) {
                    $ok("Tabela $tabela", false, 'não existe: importe database/schema.sql (ou ' . 'migracao_tudo.sql' . ')');
                    $migracao = true;
                    continue;
                }
                $faltam = array_values(array_diff($colunas, $existentes));
                $ok("Tabela $tabela", !$faltam, $faltam ? 'faltam as colunas: ' . implode(', ', $faltam) : 'atualizada');
                $migracao = $migracao || $faltam;
            }
            try {
                $enum = (string) Database::valor("SELECT COLUMN_TYPE FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'usuarios' AND COLUMN_NAME = 'perfil'");
                $faltam = array_filter(array_keys(Dominio::PERFIS), fn($p) => !str_contains($enum, "'$p'"));
                $ok('Tipos de conta (perfil)', !$faltam, $faltam ? 'o banco não aceita: ' . implode(', ', $faltam) . ' — execute database/migracao_tudo.sql' : 'comprador, anunciante, loja e administrador');
                $vazios = (int) Database::valor("SELECT COUNT(*) FROM usuarios WHERE perfil = ''");
                $ok('Contas com tipo vazio', $vazios === 0, $vazios === 0 ? 'nenhuma' : "$vazios conta(s) sem tipo: veja a seção de correção no README");
                $migracao = $migracao || $faltam;
            } catch (Throwable) {
            }
        }
        View::render('paginas/diagnostico', ['itens' => $itens, 'migracao' => $migracao], 'Diagnóstico');
    }
}
