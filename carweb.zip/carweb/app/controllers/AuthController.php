<?php
declare(strict_types=1);

final class AuthController
{
    /** Hash de mentira usado quando o e-mail não existe, para que o tempo de resposta não revele quais e-mails têm conta. */
    private const HASH_FALSO = '$2y$10$0gwtk0Edo6bwtJEFtgUQfO4182RhWI6Om/P0V1mpbdl25SajTuZp6';

    public static function formLogin(): void
    {
        if (Auth::usuario()) {
            redirect('/');
        }
        View::render('auth/login', [], 'Entrar');
    }

    public static function login(): void
    {
        $email = post('email');
        $senha = $_POST['senha'] ?? '';
        $u = Usuario::buscarPorEmail($email);
        $hash = $u['senha_hash'] ?? self::HASH_FALSO;
        $ok = is_string($senha) && Dominio::verificarSenha($senha, $hash);

        // Mensagem genérica: não informa se o erro foi no e-mail ou na senha (seção 6.2).
        if (!$ok || $u === null || (int) $u['ativo'] !== 1) {
            Flash::guardarEntrada(['email' => $email]);
            Flash::adicionar('erro', 'E-mail ou senha inválidos.');
            redirect('/entrar');
        }
        if (!isset(Dominio::PERFIS[$u['perfil']])) {
            // Conta criada quando o banco ainda não aceitava o tipo escolhido: não entra como outro perfil.
            Flash::guardarEntrada(['email' => $email]);
            Flash::adicionar('erro', 'O tipo desta conta não foi gravado corretamente (banco desatualizado). Execute database/migracao_tudo.sql no phpMyAdmin e peça ao administrador para corrigir o tipo da conta.');
            redirect('/entrar');
        }
        Auth::entrar($u);
        Flash::adicionar('ok', 'Bem-vindo(a), ' . $u['nome'] . '!');
        redirect('/');
    }

    public static function formCadastro(): void
    {
        if (Auth::usuario()) {
            redirect('/');
        }
        View::render('auth/cadastro', [], 'Criar conta');
    }

    public static function cadastrar(): void
    {
        $nome = post('nome');
        $email = mb_strtolower(post('email'));
        $tel = post('telefone');
        $senha = is_string($_POST['senha'] ?? null) ? $_POST['senha'] : '';
        $senha2 = is_string($_POST['senha2'] ?? null) ? $_POST['senha2'] : '';

        // Tipo de conta. Comprador, anunciante e loja são escolhidos livremente; o administrador geral
        // exige o código de segurança definido em config.local.php (sem código configurado, fica desativado).
        $tipo = post('tipo');
        $codigo = is_string($_POST['codigo_admin'] ?? null) ? $_POST['codigo_admin'] : '';
        $configurado = (string) config('codigo_admin', '');
        $erros = [];
        if (!in_array($tipo, ['cliente', 'anunciante', 'loja', 'administrador'], true)) {
            $erros[] = 'Escolha o tipo de conta.';
        } elseif ($tipo === 'administrador' && ($configurado === '' || !hash_equals($configurado, $codigo))) {
            $erros[] = 'Código de administrador inválido ou não configurado neste servidor.';
        }
        if (mb_strlen($nome) < 3 || mb_strlen($nome) > 120) {
            $erros[] = 'Informe seu nome completo.';
        }
        if (!Dominio::validarEmail($email)) {
            $erros[] = 'Informe um e-mail válido.';
        }
        if ($tel !== '' && !Dominio::validarTelefone($tel)) {
            $erros[] = 'Telefone inválido. Use DDD + número.';
        }
        if (!Dominio::validarSenha($senha)) {
            $erros[] = 'A senha deve ter de 8 a 72 caracteres, com letras e números.';
        }
        if ($senha !== $senha2) {
            $erros[] = 'As senhas não conferem.';
        }
        if (!$erros && Usuario::buscarPorEmail($email) !== null) {
            $erros[] = 'Este e-mail já possui cadastro.';
        }
        if ($erros) {
            foreach ($erros as $e) {
                Flash::adicionar('erro', $e);
            }
            unset($_POST['codigo_admin']);
            Flash::guardarEntrada($_POST);
            redirect('/cadastro');
        }

        try {
            $id = Usuario::criar($nome, $email, Dominio::gerarHashSenha($senha), $tel !== '' ? preg_replace('/\D/', '', $tel) : null, $tipo);
        } catch (PDOException $e) {
            if ($e->getCode() === '23000') { // corrida: outro cadastro com o mesmo e-mail
                Flash::adicionar('erro', 'Este e-mail já possui cadastro.');
                redirect('/cadastro');
            }
            throw $e;
        } catch (RuntimeException $e) {
            // O banco não aceita este tipo de conta (coluna "perfil" antiga): nada foi criado.
            unset($_POST['codigo_admin']);
            Flash::adicionar('erro', 'O banco de dados está desatualizado e não aceita o tipo de conta escolhido. Execute o arquivo database/migracao_tudo.sql no phpMyAdmin e tente de novo.');
            Flash::guardarEntrada($_POST);
            redirect('/cadastro');
        }
        Auth::entrar(Usuario::buscar($id));
        Flash::adicionar('ok', 'Cadastro realizado com sucesso!');
        redirect('/');
    }

    public static function sair(): void
    {
        Auth::sair();
        Flash::adicionar('info', 'Você saiu do sistema.');
        redirect('/');
    }
}
