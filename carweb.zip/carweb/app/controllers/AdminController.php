<?php
declare(strict_types=1);

/** Área administrativa (RF03, RF17, RF18): acesso somente ao perfil administrador, verificado no servidor. */
final class AdminController
{
    public static function painel(): void
    {
        Auth::exigir('area_admin');
        View::render('admin/painel', [
            'totalUsuarios' => Usuario::contar(),
            'veiculos'      => Veiculo::contarPorStatus(),
            'reservas'      => Reserva::contarPorStatus(),
        ], 'Administração');
    }

    public static function usuarios(): void
    {
        Auth::exigir('gerenciar_usuarios');
        View::render('admin/usuarios', ['usuarios' => Usuario::todos()], 'Usuários');
    }

    public static function definirPerfil(int $id): void
    {
        Auth::exigir('gerenciar_usuarios');
        $perfil = post('perfil');
        if (!isset(Dominio::PERFIS[$perfil]) || Usuario::buscar($id) === null) {
            Flash::adicionar('erro', 'Dados inválidos.');
        } elseif ($id === Auth::id()) {
            Flash::adicionar('erro', 'Você não pode alterar o seu próprio perfil.');   // evita ficar sem administrador
        } else {
            Usuario::definirPerfil($id, $perfil);
            Flash::adicionar('ok', 'Perfil atualizado.');
        }
        redirect('/admin/usuarios');
    }

    public static function alternarAtivo(int $id): void
    {
        Auth::exigir('gerenciar_usuarios');
        $u = Usuario::buscar($id);
        if ($u === null) {
            abort(404);
        }
        if ($id === Auth::id()) {
            Flash::adicionar('erro', 'Você não pode desativar a sua própria conta.');
        } else {
            Usuario::definirAtivo($id, (int) $u['ativo'] !== 1);
            Flash::adicionar('ok', (int) $u['ativo'] === 1 ? 'Usuário desativado.' : 'Usuário reativado.');
        }
        redirect('/admin/usuarios');
    }

    public static function veiculos(): void
    {
        Auth::exigir('area_admin');
        View::render('admin/veiculos', ['itens' => Veiculo::todosParaAdmin()], 'Anúncios');
    }
}
