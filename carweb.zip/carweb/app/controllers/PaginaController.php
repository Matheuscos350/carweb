<?php
declare(strict_types=1);

final class PaginaController
{
    public static function inicio(): void
    {
        View::render('paginas/inicio', [
            'totais'   => Veiculo::totaisDisponiveis(),
            'locacao'  => Veiculo::ofertas('locacao', 3),
            'venda'    => Veiculo::ofertas('venda', 3),
        ], '');
    }

    /** Busca da home: encaminha para a lista de compra ou de aluguel com os filtros escolhidos. */
    public static function buscar(): void
    {
        $destino = get('finalidade') === 'venda' ? '/comprar' : '/alugar';
        $q = array_filter(['q' => get('q'), 'categoria' => get('categoria')], static fn($v) => $v !== '');
        redirect($destino . ($q ? '?' . http_build_query($q) : ''));
    }

    public static function ajuda(): void
    {
        View::render('paginas/ajuda', [], 'Ajuda');
    }
}
