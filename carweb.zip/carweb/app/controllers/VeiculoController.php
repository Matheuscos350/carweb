<?php
declare(strict_types=1);

final class VeiculoController
{
    // ------------------------------------------------------------ área pública (RF07 a RF09)

    public static function listar(string $finalidade): void
    {
        $filtros = [
            'finalidade' => $finalidade,
            'q'          => get('q'),
            'categoria'  => get('categoria'),
            'preco_max'  => get('preco_max'),
            'cambio'     => get('cambio'),
            'combustivel' => get('combustivel'),
            'ano_min'    => get('ano_min'),
            'ordem'      => get('ordem', 'recomendados'),
            'retirada'   => get('retirada'),
            'devolucao'  => get('devolucao'),
        ];
        $porPagina = (int) config('itens_por_pagina', 9);
        $pagina = max(1, (int) get('pagina', '1'));
        $r = Veiculo::pesquisar($filtros, $pagina, $porPagina);
        View::render('veiculos/lista', [
            'finalidade' => $finalidade,
            'filtros'    => $filtros,
            'itens'      => $r['itens'],
            'total'      => $r['total'],
            'pagina'     => $pagina,
            'paginas'    => max(1, (int) ceil($r['total'] / $porPagina)),
        ], $finalidade === 'locacao' ? 'Alugar' : 'Comprar');
    }

    public static function ofertas(): void
    {
        View::render('veiculos/ofertas', [
            'locacao' => Veiculo::ofertas('locacao'),
            'venda'   => Veiculo::ofertas('venda'),
        ], 'Ofertas');
    }

    public static function mostrar(int $id): void
    {
        $v = Veiculo::buscar($id);
        if ($v === null || ($v['status'] === 'inativo' && !self::podeEditar($v))) {
            abort(404);
        }
        $uid = Auth::id();
        $sim = self::simular($v);
        View::render('veiculos/mostrar', [
            'sim'        => $sim,
            'v'          => $v,
            'situacao'   => Veiculo::situacao($v),
            'periodos'   => $v['finalidade'] === 'locacao' ? Reserva::periodosOcupados($id) : [],
            'eDono'      => $uid !== null && $uid === (int) $v['anunciante_id'],
            'jaInteresse' => $uid !== null && Interesse::existe($id, $uid),
            'favorito'   => $uid !== null && Favorito::existe($id, $uid),
            'semelhantes' => Veiculo::semelhantes($v, 3),
        ], $v['marca'] . ' ' . $v['modelo']);
    }

    /**
     * Simulador (financiamento na venda, parcelamento na locação). Roda no servidor com os valores
     * da URL (GET), então funciona sem JavaScript. Devolve os valores do formulário e o resultado ou o erro.
     */
    private static function simular(array $v): array
    {
        $locacao = $v['finalidade'] === 'locacao';
        $preco = (float) $v['preco'];
        $form = $locacao
            ? ['dias' => get('dias', '5'), 'parcelas' => get('parcelas', '1')]
            : [
                'entrada' => get('entrada', number_format($preco * 0.3, 2, ',', '')),
                'prazo'   => get('prazo', '48'),
                'taxa'    => get('taxa', number_format((float) config('taxa_financiamento', 1.89), 2, ',', '')),
            ];
        $r = ['form' => $form, 'ativo' => get('sim') === '1', 'resultado' => null, 'tabela' => [], 'erro' => null];
        if (!$r['ativo']) {
            return $r;
        }
        try {
            if ($locacao) {
                $r['resultado'] = Dominio::simularLocacao($preco, (int) $form['dias'], (int) $form['parcelas'], (int) config('max_dias_locacao', 60));
            } else {
                $entrada = Dominio::paraDecimal($form['entrada']) ?? 0.0;
                $taxa = Dominio::paraDecimal($form['taxa']) ?? -1.0;
                $r['resultado'] = Dominio::simularFinanciamento($preco, $entrada, (int) $form['prazo'], $taxa);
                foreach (Dominio::PRAZOS_FINANCIAMENTO as $n) {
                    $r['tabela'][] = Dominio::simularFinanciamento($preco, $entrada, $n, $taxa);
                }
            }
        } catch (InvalidArgumentException $e) {
            $r['erro'] = $e->getMessage();
        }
        return $r;
    }

    // ------------------------------------------------------------ anunciante (RF04 a RF06, RF10)

    private static function podeEditar(array $v): bool
    {
        $uid = Auth::id();
        if ($uid === null) {
            return false;
        }
        // O anunciante só altera os próprios anúncios; o administrador altera qualquer um (Quadro 10).
        return ($uid === (int) $v['anunciante_id'] && Auth::pode('editar_proprio_anuncio'))
            || Auth::pode('editar_qualquer_anuncio');
    }

    public static function meus(): void
    {
        Auth::exigir('anunciar');
        $uid = (int) Auth::id();
        $itens = Veiculo::doAnunciante($uid);
        $resumo = ['total' => count($itens), 'disponiveis' => 0, 'pendentes' => Reserva::pendentesDoAnunciante($uid)];
        foreach ($itens as $i) {
            if ($i['status'] === 'disponivel') {
                $resumo['disponiveis']++;
            }
        }
        View::render('veiculos/meus', ['itens' => $itens, 'resumo' => $resumo], 'Meus anúncios');
    }

    public static function formNovo(): void
    {
        if (Auth::usuario() !== null && !Auth::pode('anunciar')) {
            View::render('veiculos/sem_perfil', [], 'Vender');
            return;
        }
        Auth::exigir('anunciar');
        View::render('veiculos/form', ['v' => null], 'Anunciar veículo');
    }

    public static function criar(): void
    {
        Auth::exigir('anunciar');
        [$dados, $erros] = self::coletar(null);
        if ($erros) {
            self::falha($erros, '/veiculo/novo');
        }
        try {
            $imagem = Upload::salvarImagem($_FILES['imagem'] ?? null);
        } catch (RuntimeException $e) {
            self::falha([$e->getMessage()], '/veiculo/novo');
        }
        $extras = self::fotosExtrasEnviadas(0, $imagem);
        $id = Veiculo::criar((int) Auth::id(), $dados, $imagem);
        Veiculo::adicionarFotos($id, $extras);
        Flash::adicionar('ok', 'Anúncio publicado com sucesso!');
        redirect('/veiculo/' . $id);
    }

    public static function formEditar(int $id): void
    {
        $v = self::carregarEditavel($id);
        View::render('veiculos/form', ['v' => $v], 'Editar anúncio');
    }

    public static function atualizar(int $id): void
    {
        $v = self::carregarEditavel($id);
        [$dados, $erros] = self::coletar($v);
        if ($erros) {
            self::falha($erros, "/veiculo/$id/editar");
        }
        try {
            $imagem = Upload::salvarImagem($_FILES['imagem'] ?? null);
        } catch (RuntimeException $e) {
            self::falha([$e->getMessage()], "/veiculo/$id/editar");
        }
        $remover = is_array($_POST['remover_fotos'] ?? null) ? $_POST['remover_fotos'] : [];
        $extras = self::fotosExtrasEnviadas($id, $imagem, count($remover));
        Veiculo::atualizar($id, $dados, $imagem);
        Veiculo::removerFotos($id, $remover);
        Veiculo::adicionarFotos($id, $extras);
        if ($imagem !== null) {
            Upload::remover($v['imagem']);
        }
        Flash::adicionar('ok', 'Anúncio atualizado.');
        redirect('/veiculo/' . $id);
    }

    /** Exclusão lógica (RF06): o anúncio fica inativo e o histórico de reservas é preservado. */
    public static function inativar(int $id): void
    {
        $v = self::carregarEditavel($id);
        if (!Dominio::alterarStatusVeiculo($v['status'], 'inativo')) {
            Flash::adicionar('erro', 'Este anúncio não pode ser inativado.');
        } else {
            Veiculo::definirStatus($id, 'inativo');
            Flash::adicionar('ok', 'Anúncio inativado. Ele não aparece mais nas buscas.');
        }
        redirect(Auth::pode('area_admin') && (int) $v['anunciante_id'] !== Auth::id() ? '/admin/veiculos' : '/meus-veiculos');
    }

    /** Carrega o veículo e confere a propriedade: impede editar o anúncio de outra pessoa trocando o número na URL. */
    private static function carregarEditavel(int $id): array
    {
        Auth::exigir('editar_proprio_anuncio');
        $v = Veiculo::buscar($id);
        if ($v === null) {
            abort(404);
        }
        if (!self::podeEditar($v)) {
            abort(403);
        }
        return $v;
    }

    /** @return array{0: array<string, mixed>, 1: array<int, string>} dados limpos e lista de erros */
    private static function coletar(?array $existente): array
    {
        $d = [
            'marca'         => post('marca'),
            'modelo'        => post('modelo'),
            'ano'           => post('ano'),
            'quilometragem' => post('quilometragem'),
            'categoria'     => post('categoria'),
            'cambio'        => post('cambio'),
            'lugares'       => post('lugares'),
            'combustivel'   => post('combustivel'),
            'descricao'     => post('descricao'),
            'finalidade'    => $existente['finalidade'] ?? post('finalidade'),  // não muda depois de criado
        ];
        $preco = Dominio::paraDecimal(post('preco'));
        $d['preco'] = $preco === null ? '' : (string) $preco;
        $hora = Dominio::paraDecimal(post('preco_hora'));
        $d['preco_hora'] = post('preco_hora') === '' ? '' : ($hora === null ? 'x' : (string) $hora);
        $erros = array_values(Dominio::validarVeiculo($d));

        if ($existente !== null) {
            $novo = post('status', $existente['status']);
            if ($novo !== $existente['status']) {
                $valido = Dominio::alterarStatusVeiculo($existente['status'], $novo)
                    && ($novo !== 'vendido' || $existente['finalidade'] === 'venda');
                if (!$valido) {
                    $erros[] = 'Mudança de situação não permitida.';
                }
            }
            $d['status'] = $novo;
        }
        return [$d, $erros];
    }

    /**
     * Salva as fotos adicionais enviadas em "fotos[]", respeitando o limite do anúncio. Se algo falhar, apaga o que
     * já foi gravado (inclusive a capa nova) e volta ao formulário com a mensagem.
     * @return array<int, string>
     */
    private static function fotosExtrasEnviadas(int $id, ?string $capaNova, int $removidas = 0): array
    {
        $volta = $id > 0 ? "/veiculo/$id/editar" : '/veiculo/novo';
        try {
            if (!Database::temTabela('veiculo_fotos')) {
                return [];
            }
            $enviadas = Upload::normalizarMultiplos($_FILES['fotos'] ?? null);
            $atuais = $id > 0 ? count(Veiculo::fotosExtras($id)) : 0;
            if ($atuais - $removidas + count($enviadas) > Veiculo::MAX_FOTOS_EXTRAS) {
                throw new RuntimeException('Cada anúncio pode ter até ' . Veiculo::MAX_FOTOS_EXTRAS . ' fotos adicionais além da capa.');
            }
            return Upload::salvarVarias($_FILES['fotos'] ?? null);
        } catch (RuntimeException $e) {
            Upload::remover($capaNova);
            self::falha([$e->getMessage()], $volta);
        }
        return [];
    }

    private static function falha(array $erros, string $volta): void
    {
        foreach ($erros as $e) {
            Flash::adicionar('erro', $e);
        }
        Flash::guardarEntrada($_POST);
        redirect($volta);
    }
}
