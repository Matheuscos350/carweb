# CarWeb — Sistema web para compra, venda e locação de veículos

Projeto acadêmico (Ciências da Computação, UNINOVE, 2026). Implementa o que foi descrito na documentação de software:
PHP 8.0+ (puro, sem framework, padrão MVC), MySQL/MariaDB, PDO e XAMPP.

## Instalação no XAMPP (Windows)

1. Copie esta pasta para `C:\xampp\htdocs\carweb`.
2. Inicie **Apache** e **MySQL** no painel do XAMPP.
3. No phpMyAdmin (http://localhost/phpmyadmin), importe `database/schema.sql`.
4. Abra `database/usuario_banco.sql`, **troque a senha `troque_esta_senha`** e execute o script (cria o usuário `carweb_app`, que só tem SELECT/INSERT/UPDATE/DELETE).
5. Copie `app/config/config.local.example.php` para `app/config/config.local.php` e coloque a mesma senha. Esse arquivo não vai para o git.
6. Contas de demonstração (opcional, sem veículos): no terminal, `C:\xampp\php\php.exe database\seed.php`.
7. Já tem veículos genéricos de demonstração no banco? No phpMyAdmin, execute `database/limpar_dados_demo.sql` (apaga só os veículos das contas de demonstração e o que está ligado a eles).
8. Acesse http://localhost/carweb/public/ (ou http://localhost/carweb/).

Contas de demonstração (senha `Carweb@123` — troque ou apague antes de qualquer uso real):
`admin@carweb.local`, `anunciante@carweb.local`, `cliente@carweb.local`.

Rodar sem XAMPP: `php -S 127.0.0.1:8080 -t public public/index.php`.

## Novidades desta versão

Página inicial com busca e destaques, menu responsivo, ilustração de carro nos anúncios sem foto, filtros de câmbio, combustível e ano, favoritos (coração nos anúncios e página `/favoritos`), página **Minha conta** (editar dados e trocar senha), resumo no painel do anunciante e veículos semelhantes na página de detalhe e um **simulador** (financiamento pela Tabela Price nos veículos à venda; parcelamento sem juros da locação nos de aluguel).
Quem já importou o banco antes precisa executar `database/migracao_favoritos.sql` (e `migracao_loja.sql`, se ainda não executou).

## Locação por dia e por hora

O anunciante pode informar, no anúncio de locação, o **valor por hora** (opcional). Os veículos com valor por hora aceitam reservas **por hora** (um único dia, início a partir das 06h, de 1 a 12 horas, término até as 24h) além das reservas por dia. O conflito é verificado em dias e horas, nas duas modalidades.
Quem já importou o banco antes desta versão deve executar `database/migracao_hora.sql` (adiciona `preco_hora` e `modalidade` e converte as datas das reservas para data e hora). O script também define um valor por hora de teste (diária ÷ 6) para os carros da Loja Demo.

## Várias fotos e carrossel

Ao criar ou editar um anúncio, envie a **foto de capa** e até **8 fotos adicionais** (JPG ou PNG, 2 MB cada). Na página do veículo, as fotos aparecem em um carrossel com setas, miniaturas, contador, teclado (← →) e deslizar no celular. Ao editar, marque “Remover” nas fotos que não quer mais. Bancos antigos precisam de `database/migracao_tudo.sql` (sem ela o anúncio continua funcionando, apenas só com a capa).

## Tipos de conta (comprador, anunciante, loja) não separam?

Acontece quando o banco foi criado antes do tipo “loja”: o cadastro era gravado com o tipo em branco. Execute `database/migracao_tudo.sql` no phpMyAdmin (aba SQL, com o banco `carweb` selecionado). A partir desta versão o cadastro avisa o problema em vez de criar a conta errada, e o login recusa contas com tipo em branco. Para corrigir contas já criadas em branco, use os `UPDATE` indicados no final do `migracao_tudo.sql`.

## Erro 500 ao anunciar?

Quase sempre é banco criado antes de uma versão nova. Execute no phpMyAdmin (aba SQL, com o banco `carweb` selecionado) o conteúdo de `database/migracao_hora.sql` (pode ser executado mais de uma vez; o `database/migracao_tudo.sql` aplica todas as migrações de uma vez). Desde esta versão o cadastro e a edição de anúncios funcionam mesmo sem essa migração, mas a locação por hora exige ela. O motivo real do erro sempre fica em `storage/logs/app.log`.

## Cadastro de veículos por XML

Em **Meus anúncios → Importar XML** (anunciante, loja ou administrador) é possível cadastrar até 100 veículos de uma vez. Baixe o modelo em `/veiculos/modelo` (arquivo `database/modelo_veiculos.xml`, com comentários e três exemplos), preencha e envie. O arquivo é validado por inteiro com as mesmas regras do cadastro individual: havendo qualquer erro, **nada é importado** e todos os problemas são listados; estando tudo certo, os anúncios são criados em uma transação. Limites: 1 MB, sem DOCTYPE/ENTITY (proteção contra XXE). Não exige migração de banco. Fotos são adicionadas depois, em “Editar anúncio”.

## Fotos reais dos veículos

Veículos sem foto mostram uma ilustração; a foto é enviada ao criar ou editar o anúncio.

## Testes

`php tests/run.php` executa os casos CT-U01 a CT-U11 do plano de testes (cálculo de locação, conflito de datas, CPF, e-mail, hash, validação de veículo, status e permissões).

## Estrutura

```
public/      único diretório exposto (index.php, assets, uploads)
app/core/    Router, Auth, Csrf, Database (PDO), Dominio (regras de negócio), View, Upload
app/models/  Usuario, Veiculo, Reserva, Interesse
app/controllers/, app/views/
database/    schema.sql, usuario_banco.sql, seed.php
scripts/     backup.sh / backup.bat (mysqldump)
tests/       run.php
```

## Perfis (Quadro 10)

| Ação | Visitante | Cliente | Anunciante | Admin |
|---|---|---|---|---|
| Consultar veículos | ✔ | ✔ | ✔ | ✔ |
| Reservar / demonstrar interesse | | ✔ | ✔ | ✔ |
| Anunciar e editar o próprio anúncio | | | ✔ | ✔ |
| Ver solicitações dos próprios anúncios | | | ✔ | ✔ |
| Gerenciar usuários e qualquer anúncio | | | | ✔ |

No cadastro a pessoa escolhe **Comprador**, **Anunciante** ou **Loja** (as duas últimas publicam anúncios). A conta de **Administrador geral** só pode ser criada informando o `codigo_admin` definido em `config.local.php`; sem esse código configurado, a opção fica desativada.

Se você já importou o `schema.sql` antes desta versão, execute também `database/migracao_loja.sql`.

## Segurança implementada (capítulo 6)

- Senhas com `password_hash` (bcrypt); mensagem de login genérica e tempo de resposta equalizado.
- Sessão: cookie HttpOnly + SameSite, `use_strict_mode`, regeneração do ID no login, expiração por inatividade (30 min); o usuário é relido do banco a cada requisição.
- Token CSRF em todo POST (verificado no Router).
- PDO com prepared statements reais (`EMULATE_PREPARES=false`); escape de saída com `e()`.
- Cabeçalhos CSP (sem scripts/estilos inline), X-Frame-Options, nosniff, Referrer-Policy.
- Upload: valida tipo real (finfo + getimagesize), JPG/PNG, 2 MB, nome aleatório, `.htaccess` sem execução.
- Verificação de propriedade (IDOR) e de perfil no servidor; exclusão lógica; reserva em transação com `SELECT ... FOR UPDATE`.
- Erros ocultos do usuário e gravados em `storage/logs/app.log`; documento exibido mascarado; contato do cliente visível só ao anunciante envolvido.
- Backup: `scripts/backup.sh` / `backup.bat`.

## Limitações conhecidas

Sem HTTPS local (use HTTPS em produção e ative o cookie `secure`), sem 2FA nem limite de tentativas de login, CNH validada só pelo tamanho, datas sem horário, sem pagamento real (a compra é simulada por "demonstrar interesse"), e-mails não são enviados. Testado com PHP 8.3 e MariaDB em Linux; não foi executado em um XAMPP real no Windows.
