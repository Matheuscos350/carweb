-- CarWeb · esquema do banco de dados (MySQL / MariaDB do XAMPP)
-- Importe este arquivo pelo phpMyAdmin (aba "Importar") ou pelo console:
--   mysql -u root -p < database/schema.sql

CREATE DATABASE IF NOT EXISTS carweb CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE carweb;

-- RF01, RF02, RF03, RF18: usuários e perfis de acesso (RNF02: apenas o hash da senha é guardado)
CREATE TABLE IF NOT EXISTS usuarios (
    id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    nome        VARCHAR(120) NOT NULL,
    email       VARCHAR(160) NOT NULL,
    senha_hash  VARCHAR(255) NOT NULL,
    telefone    VARCHAR(20)  NULL,
    perfil      ENUM('cliente','anunciante','loja','administrador') NOT NULL DEFAULT 'cliente',
    ativo       TINYINT(1)   NOT NULL DEFAULT 1,
    criado_em   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_usuarios_email (email)            -- RNF03: sem contas duplicadas
) ENGINE=InnoDB;

-- RF04 a RF10, RF14: veículos e anúncios (a exclusão é lógica: status = 'inativo')
CREATE TABLE IF NOT EXISTS veiculos (
    id             INT UNSIGNED NOT NULL AUTO_INCREMENT,
    anunciante_id  INT UNSIGNED NOT NULL,
    finalidade     ENUM('venda','locacao') NOT NULL,
    marca          VARCHAR(60)  NOT NULL,
    modelo         VARCHAR(80)  NOT NULL,
    ano            SMALLINT UNSIGNED NOT NULL,
    quilometragem  INT UNSIGNED NOT NULL DEFAULT 0,
    categoria      ENUM('hatch','sedan','suv') NOT NULL,
    cambio         ENUM('manual','automatico') NOT NULL,
    lugares        TINYINT UNSIGNED NOT NULL DEFAULT 5,
    combustivel    ENUM('flex','gasolina','etanol','diesel','eletrico','hibrido') NOT NULL DEFAULT 'flex',
    descricao      VARCHAR(1000) NULL,
    preco          DECIMAL(12,2) NOT NULL,           -- venda: preço à vista; locação: valor da diária
    preco_hora     DECIMAL(10,2) NULL,               -- locação por hora (opcional); NULL = só aluga por dia
    status         ENUM('disponivel','reservado','alugado','vendido','inativo') NOT NULL DEFAULT 'disponivel',
    imagem         VARCHAR(60)  NULL,                -- só o nome do arquivo; o arquivo fica em public/uploads
    criado_em      TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY ix_veiculos_busca (status, finalidade, categoria, preco),
    KEY ix_veiculos_marca (marca, modelo),
    KEY ix_veiculos_anunciante (anunciante_id),
    CONSTRAINT fk_veiculos_anunciante FOREIGN KEY (anunciante_id) REFERENCES usuarios (id),
    CONSTRAINT ck_veiculos_preco CHECK (preco > 0),
    CONSTRAINT ck_veiculos_preco_hora CHECK (preco_hora IS NULL OR preco_hora > 0)
) ENGINE=InnoDB;

-- RF12, RF13, RF15, RF16: reservas de locação
CREATE TABLE IF NOT EXISTS reservas (
    id               INT UNSIGNED NOT NULL AUTO_INCREMENT,
    veiculo_id       INT UNSIGNED NOT NULL,
    usuario_id       INT UNSIGNED NOT NULL,
    modalidade       ENUM('dia','hora') NOT NULL DEFAULT 'dia',
    data_retirada    DATETIME NOT NULL,              -- dia: 00:00 da retirada; hora: início da janela
    data_devolucao   DATETIME NOT NULL,              -- dia: 00:00 da devolução (esse dia fica livre); hora: fim da janela
    valor_total      DECIMAL(12,2) NOT NULL,
    nome_locatario   VARCHAR(120) NOT NULL,
    tipo_documento   ENUM('cpf','cnh') NOT NULL,
    documento        VARCHAR(11) NOT NULL,           -- só dígitos; exibido sempre mascarado
    status           ENUM('pendente','confirmada','cancelada','concluida') NOT NULL DEFAULT 'pendente',
    criado_em        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY ix_reservas_periodo (veiculo_id, status, data_retirada, data_devolucao),
    KEY ix_reservas_usuario (usuario_id),
    CONSTRAINT fk_reservas_veiculo FOREIGN KEY (veiculo_id) REFERENCES veiculos (id),
    CONSTRAINT fk_reservas_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios (id),
    CONSTRAINT ck_reservas_datas CHECK (data_devolucao > data_retirada)
) ENGINE=InnoDB;

-- RF11, RF20: demonstração de interesse na compra (sem pagamento)
CREATE TABLE IF NOT EXISTS interesses (
    id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    veiculo_id  INT UNSIGNED NOT NULL,
    usuario_id  INT UNSIGNED NOT NULL,
    mensagem    VARCHAR(300) NULL,
    criado_em   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_interesse (veiculo_id, usuario_id),
    CONSTRAINT fk_interesses_veiculo FOREIGN KEY (veiculo_id) REFERENCES veiculos (id),
    CONSTRAINT fk_interesses_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS favoritos (
    id         INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT UNSIGNED NOT NULL,
    veiculo_id INT UNSIGNED NOT NULL,
    criado_em  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_favorito (usuario_id, veiculo_id),
    CONSTRAINT fk_fav_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE CASCADE,
    CONSTRAINT fk_fav_veiculo FOREIGN KEY (veiculo_id) REFERENCES veiculos (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Fotos adicionais do veículo (a capa fica em veiculos.imagem); exibidas no carrossel.
CREATE TABLE IF NOT EXISTS veiculo_fotos (
    id         INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    veiculo_id INT UNSIGNED NOT NULL,
    arquivo    VARCHAR(60) NOT NULL,
    criado_em  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY ix_fotos_veiculo (veiculo_id),
    CONSTRAINT fk_fotos_veiculo FOREIGN KEY (veiculo_id) REFERENCES veiculos (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
