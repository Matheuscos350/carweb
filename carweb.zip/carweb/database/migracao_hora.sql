-- Para quem já importou o banco antes desta versão: adiciona o aluguel por hora.
USE carweb;

-- Pode ser executado mais de uma vez sem erro (MariaDB/XAMPP).
ALTER TABLE veiculos
    ADD COLUMN IF NOT EXISTS preco_hora DECIMAL(10,2) NULL AFTER preco;

ALTER TABLE reservas
    ADD COLUMN IF NOT EXISTS modalidade ENUM('dia','hora') NOT NULL DEFAULT 'dia' AFTER usuario_id,
    MODIFY data_retirada DATETIME NOT NULL,
    MODIFY data_devolucao DATETIME NOT NULL;

-- Opcional (dados de teste): valor por hora = diária / 6 para os carros de aluguel da Loja Demo.
UPDATE veiculos SET preco_hora = ROUND(preco / 6, 0)
 WHERE finalidade = 'locacao' AND preco_hora IS NULL
   AND anunciante_id = (SELECT id FROM usuarios WHERE email = 'lojademo@carweb.local');
