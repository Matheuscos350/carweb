<?php
declare(strict_types=1);
/** Contas de demonstração (sem veículos: cadastre os seus pelo site ou por XML). Uso (CLI): php database/seed.php  — só roda pela linha de comando. */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require __DIR__ . '/../app/core/bootstrap.php';

if (Usuario::contar() > 0) { fwrite(STDERR, "O banco já possui usuários; seed cancelado.\n"); exit(1); }

$h = Dominio::gerarHashSenha('Carweb@123');
Usuario::criarComPerfil('Administrador CarWeb', 'admin@carweb.local', $h, 'administrador');
Usuario::criarComPerfil('Anunciante Demo', 'anunciante@carweb.local', $h, 'anunciante');
Usuario::criarComPerfil('Cliente Demo', 'cliente@carweb.local', $h, 'cliente');

echo "Seed concluído. Usuários: admin@carweb.local, anunciante@carweb.local, cliente@carweb.local (senha Carweb@123 — troque!).\n";
