-- CarWeb: apaga os veículos de demonstração (os "genéricos" de venda e aluguel) e tudo que está ligado a eles
-- (reservas, interesses e favoritos). Os veículos das SUAS contas não são tocados.
-- Veículos de demonstração = os cadastrados pelas contas lojademo@carweb.local e anunciante@carweb.local.
-- Use no phpMyAdmin: selecione o banco carweb > aba SQL > colar > Executar. Pode ser executado mais de uma vez.

DELETE FROM reservas
 WHERE veiculo_id IN (SELECT id FROM veiculos WHERE anunciante_id IN
       (SELECT id FROM usuarios WHERE email IN ('lojademo@carweb.local', 'anunciante@carweb.local')));

DELETE FROM interesses
 WHERE veiculo_id IN (SELECT id FROM veiculos WHERE anunciante_id IN
       (SELECT id FROM usuarios WHERE email IN ('lojademo@carweb.local', 'anunciante@carweb.local')));

-- (favoritos são apagados junto, por ON DELETE CASCADE)
DELETE FROM veiculos
 WHERE anunciante_id IN (SELECT id FROM usuarios WHERE email IN ('lojademo@carweb.local', 'anunciante@carweb.local'));

-- Conferência: quantos veículos restam e de quem são.
SELECT u.email, COUNT(*) AS veiculos FROM veiculos v JOIN usuarios u ON u.id = v.anunciante_id GROUP BY u.email;
