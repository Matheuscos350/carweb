-- CarWeb · conta de banco dedicada à aplicação (seção 6.1 e Quadro 12 da documentação)
-- O XAMPP cria o usuário "root" sem senha: ele serve só para administrar o banco, nunca para a aplicação.
-- 1) TROQUE a senha abaixo; 2) use a mesma senha em app/config/config.local.php.

CREATE USER IF NOT EXISTS 'carweb_app'@'localhost' IDENTIFIED BY 'troque_esta_senha';
CREATE USER IF NOT EXISTS 'carweb_app'@'127.0.0.1' IDENTIFIED BY 'troque_esta_senha';

-- Somente o necessário: consultar, inserir, alterar e excluir registros do banco carweb.
GRANT SELECT, INSERT, UPDATE, DELETE ON carweb.* TO 'carweb_app'@'localhost';
GRANT SELECT, INSERT, UPDATE, DELETE ON carweb.* TO 'carweb_app'@'127.0.0.1';
FLUSH PRIVILEGES;
