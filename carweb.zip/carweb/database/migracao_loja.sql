-- Para quem já importou o schema.sql antes: adiciona o perfil "loja".
USE carweb;
ALTER TABLE usuarios MODIFY perfil ENUM('cliente','anunciante','loja','administrador') NOT NULL DEFAULT 'cliente';
