-- CarWeb: atualiza um banco criado em QUALQUER versão anterior para a versão atual.
-- Use no phpMyAdmin: clique no banco carweb > aba SQL > cole tudo > Executar. Pode ser executado várias vezes.

-- 1) Tipos de conta: comprador (cliente), anunciante, loja e administrador geral.
ALTER TABLE usuarios MODIFY perfil ENUM('cliente','anunciante','loja','administrador') NOT NULL DEFAULT 'cliente';

-- 2) Aluguel por hora.
ALTER TABLE veiculos ADD COLUMN IF NOT EXISTS preco_hora DECIMAL(10,2) NULL AFTER preco;
ALTER TABLE reservas ADD COLUMN IF NOT EXISTS modalidade ENUM('dia','hora') NOT NULL DEFAULT 'dia' AFTER usuario_id;

-- 3) Favoritos.
CREATE TABLE IF NOT EXISTS favoritos (
    id         INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT UNSIGNED NOT NULL,
    veiculo_id INT UNSIGNED NOT NULL,
    criado_em  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_favorito (usuario_id, veiculo_id),
    CONSTRAINT fk_fav_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE CASCADE,
    CONSTRAINT fk_fav_veiculo FOREIGN KEY (veiculo_id) REFERENCES veiculos (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4) Várias fotos por veículo (carrossel).
CREATE TABLE IF NOT EXISTS veiculo_fotos (
    id         INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    veiculo_id INT UNSIGNED NOT NULL,
    arquivo    VARCHAR(60) NOT NULL,
    criado_em  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY ix_fotos_veiculo (veiculo_id),
    CONSTRAINT fk_fotos_veiculo FOREIGN KEY (veiculo_id) REFERENCES veiculos (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5) Contas criadas com o tipo em branco (aconteceu quando o banco ainda não aceitava "loja"): liste e corrija.
SELECT id, nome, email FROM usuarios WHERE perfil = '';
-- Para cada conta listada, escolha o tipo certo, por exemplo:
--   UPDATE usuarios SET perfil = 'loja'       WHERE email = 'email-da-loja@exemplo.com';
--   UPDATE usuarios SET perfil = 'anunciante' WHERE email = 'email-do-vendedor@exemplo.com';
--   UPDATE usuarios SET perfil = 'cliente'    WHERE email = 'email-do-comprador@exemplo.com';
