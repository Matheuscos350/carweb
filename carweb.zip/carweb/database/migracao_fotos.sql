-- CarWeb: várias fotos por veículo (carrossel). Pode ser executado mais de uma vez.
CREATE TABLE IF NOT EXISTS veiculo_fotos (
    id         INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    veiculo_id INT UNSIGNED NOT NULL,
    arquivo    VARCHAR(60) NOT NULL,
    criado_em  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY ix_fotos_veiculo (veiculo_id),
    CONSTRAINT fk_fotos_veiculo FOREIGN KEY (veiculo_id) REFERENCES veiculos (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
