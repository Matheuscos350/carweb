<?php
declare(strict_types=1);
/** Testes unitários (CT-U01 a CT-U11) sem dependências. Uso: php tests/run.php */
define('ROOT', dirname(__DIR__));
require ROOT . '/app/core/Dominio.php';

$ok = 0; $falhas = [];
function t(string $id, string $desc, callable $f): void {
    global $ok, $falhas;
    try { $r = $f(); } catch (Throwable $e) { $r = false; $desc .= ' [' . $e->getMessage() . ']'; }
    if ($r === true) { $ok++; echo "  OK   $id  $desc\n"; } else { $falhas[] = $id; echo "  FALHA $id  $desc\n"; }
}
function lanca(callable $f): bool { try { $f(); } catch (InvalidArgumentException) { return true; } return false; }

echo "CarWeb — testes unitários\n";
t('CT-U01', '5 dias x R$120 = R$600', fn() => Dominio::calcularValorLocacao(120, '2026-10-05', '2026-10-10') === 600.0);
t('CT-U02', 'devolução anterior à retirada é rejeitada', fn() => lanca(fn() => Dominio::calcularValorLocacao(120, '2026-10-10', '2026-10-05')) && lanca(fn() => Dominio::calcularValorLocacao(120, '2026-10-05', '2026-10-05')));
$res = [['data_retirada' => '2026-10-10', 'data_devolucao' => '2026-10-15']];
t('CT-U03', 'período sobreposto gera conflito', fn() => Dominio::verificarConflito('2026-10-12', '2026-10-18', $res) === true);
t('CT-U04', 'período livre não gera conflito', fn() => Dominio::verificarConflito('2026-10-20', '2026-10-25', $res) === false);
t('CT-U05', 'devolução no dia da retirada seguinte é permitida', fn() => Dominio::verificarConflito('2026-10-15', '2026-10-18', $res) === false && Dominio::verificarConflito('2026-10-05', '2026-10-10', $res) === false);
t('CT-U06', 'e-mail válido/inválido', fn() => Dominio::validarEmail('ana@exemplo.com') && !Dominio::validarEmail('ana@') && !Dominio::validarEmail('ana exemplo.com') && !Dominio::validarEmail(''));
t('CT-U07', 'CPF válido e inválidos', fn() => Dominio::validarCpf('529.982.247-25') && Dominio::validarCpf('52998224725') && !Dominio::validarCpf('529.982.247-24') && !Dominio::validarCpf('111.111.111-11') && !Dominio::validarCpf('123'));
t('CT-U08', 'hash de senha não é texto puro e confere', function () {
    $h = Dominio::gerarHashSenha('Carweb@123');
    return $h !== 'Carweb@123' && Dominio::verificarSenha('Carweb@123', $h) && !Dominio::verificarSenha('errada1', $h) && $h !== Dominio::gerarHashSenha('Carweb@123');
});
$v = ['finalidade' => 'locacao', 'marca' => 'VW', 'modelo' => 'Polo', 'ano' => 2023, 'quilometragem' => 100, 'categoria' => 'hatch', 'cambio' => 'manual', 'combustivel' => 'flex', 'lugares' => 5, 'preco' => '120', 'descricao' => ''];
t('CT-U09', 'veículo válido passa; preço zero, marca vazia e ano absurdo falham', fn() =>
    Dominio::validarVeiculo($v) === [] && isset(Dominio::validarVeiculo(array_merge($v, ['preco' => '0']))['preco'])
    && isset(Dominio::validarVeiculo(array_merge($v, ['marca' => '']))['marca']) && isset(Dominio::validarVeiculo(array_merge($v, ['ano' => 1800]))['ano']));
t('CT-U10', 'transições de status; vendido é final', fn() =>
    Dominio::alterarStatusVeiculo('disponivel', 'reservado') && Dominio::alterarStatusVeiculo('inativo', 'disponivel')
    && !Dominio::alterarStatusVeiculo('vendido', 'disponivel') && !Dominio::alterarStatusVeiculo('inativo', 'vendido'));
t('CT-U11', 'permissões por perfil (Quadro 10)', fn() =>
    Dominio::verificarPermissao(null, 'consultar') && !Dominio::verificarPermissao(null, 'solicitar_locacao')
    && Dominio::verificarPermissao('cliente', 'solicitar_locacao') && !Dominio::verificarPermissao('cliente', 'anunciar')
    && !Dominio::verificarPermissao('anunciante', 'solicitar_locacao') && !Dominio::verificarPermissao('loja', 'solicitar_locacao')
    && Dominio::verificarPermissao('anunciante', 'anunciar') && !Dominio::verificarPermissao('anunciante', 'area_admin')
    && Dominio::verificarPermissao('administrador', 'gerenciar_usuarios') && !Dominio::verificarPermissao('cliente', 'inexistente'));
t('EXTRA', 'documento mascarado e senha fraca recusada', fn() =>
    Dominio::mascararDocumento('52998224725', 'cpf') === '***.982.247-**' && !Dominio::validarSenha('12345678') && !Dominio::validarSenha('abc') && Dominio::validarSenha('Carweb@123'));

t('SIM-01', 'financiamento Price: R$ 70.000 / 48x / 1,89% a.m. dá parcela de R$ 2.231,35', function () {
    $r = Dominio::simularFinanciamento(100000, 30000, 48, 1.89);
    return abs($r['parcela'] - 2231.35) < 0.02 && $r['financiado'] === 70000.0 && $r['juros'] > 0 && abs($r['total'] - ($r['parcela'] * 48 + 30000)) < 0.01;
});
t('SIM-02', 'juros zero divide o valor em parcelas iguais', fn() => Dominio::simularFinanciamento(60000, 12000, 48, 0.0)['parcela'] === 1000.0);
t('SIM-03', 'entrada, prazo e taxa inválidos são recusados', fn() => lanca(fn() => Dominio::simularFinanciamento(50000, 50000, 48, 1.5))
    && lanca(fn() => Dominio::simularFinanciamento(50000, 10000, 18, 1.5)) && lanca(fn() => Dominio::simularFinanciamento(50000, 10000, 48, 25)) && lanca(fn() => Dominio::simularFinanciamento(50000, -1, 48, 1.5)));
t('SIM-04', 'locação: 5 dias x R$ 120 em 3x = 3 x R$ 200', function () {
    $r = Dominio::simularLocacao(120, 5, 3);
    return $r['total'] === 600.0 && $r['parcela'] === 200.0 && lanca(fn() => Dominio::simularLocacao(120, 0, 1)) && lanca(fn() => Dominio::simularLocacao(120, 5, 7));
});

t('HORA-01', 'valor por hora: 3h x R$ 25 = R$ 75; 0 h, 13 h e hora sem preço são recusadas', fn() => Dominio::calcularValorHora(25, 3) === 75.0
    && lanca(fn() => Dominio::calcularValorHora(25, 0)) && lanca(fn() => Dominio::calcularValorHora(25, 13)) && lanca(fn() => Dominio::calcularValorHora(0, 2)));
t('HORA-02', 'janela por hora: 14h + 3h; antes das 06h ou além das 24h é recusado', fn() =>
    Dominio::janelaPorHora('2026-12-01', 14, 3) === ['2026-12-01 14:00:00', '2026-12-01 17:00:00']
    && Dominio::janelaPorHora('2026-12-01', 21, 3) === ['2026-12-01 21:00:00', '2026-12-02 00:00:00']
    && lanca(fn() => Dominio::janelaPorHora('2026-12-01', 5, 2)) && lanca(fn() => Dominio::janelaPorHora('2026-12-01', 22, 3)) && lanca(fn() => Dominio::janelaPorHora('2026-02-31', 9, 2)));
$ocup = [['data_retirada' => '2026-10-05 00:00:00', 'data_devolucao' => '2026-10-10 00:00:00'], ['data_retirada' => '2026-10-12 14:00:00', 'data_devolucao' => '2026-10-12 17:00:00']];
t('HORA-03', 'conflito hora x dia: hora dentro da diária conflita; no dia da devolução, não; horas vizinhas não conflitam', fn() =>
    Dominio::verificarConflito('2026-10-07 14:00:00', '2026-10-07 16:00:00', $ocup) === true
    && Dominio::verificarConflito('2026-10-10 09:00:00', '2026-10-10 11:00:00', $ocup) === false
    && Dominio::verificarConflito('2026-10-12 16:00:00', '2026-10-12 18:00:00', $ocup) === true
    && Dominio::verificarConflito('2026-10-12 17:00:00', '2026-10-12 19:00:00', $ocup) === false
    && Dominio::verificarConflito('2026-10-12 12:00:00', '2026-10-12 14:00:00', $ocup) === false);
t('HORA-04', 'validação do anúncio: valor por hora inválido é recusado; em branco é permitido', fn() =>
    isset(Dominio::validarVeiculo(array_merge($v, ['preco_hora' => '0']))['preco_hora'])
    && Dominio::validarVeiculo(array_merge($v, ['preco_hora' => ''])) === [] && Dominio::validarVeiculo(array_merge($v, ['preco_hora' => '25'])) === []);

require ROOT . '/app/core/ImportadorXml.php';
$modelo = (string) file_get_contents(ROOT . '/database/modelo_veiculos.xml');
$xmlUm = static fn(string $campos): string => '<?xml version="1.0" encoding="UTF-8"?><veiculos><veiculo>' . $campos . '</veiculo></veiculos>';
$base = '<finalidade>locacao</finalidade><marca>Fiat</marca><modelo>Mobi</modelo><ano>2022</ano><quilometragem>21000</quilometragem><categoria>hatch</categoria><cambio>manual</cambio><lugares>4</lugares><combustivel>flex</combustivel><preco>95,00</preco>';
t('XML-01', 'o modelo de XML distribuído é válido (3 veículos)', function () use ($modelo) {
    $r = ImportadorXml::processar($modelo);
    return $r['erros'] === [] && count($r['veiculos']) === 3 && $r['veiculos'][0]['preco'] === '120' && $r['veiculos'][0]['preco_hora'] === '20'
        && $r['veiculos'][1]['preco_hora'] === '' && $r['veiculos'][2]['preco'] === '108500';
});
t('XML-02', 'aceita acentos e maiúsculas nos valores (Automático, Locação, Elétrico)', function () use ($xmlUm, $base) {
    $x = str_replace(['<cambio>manual', '<finalidade>locacao'], ['<cambio>Automático', '<finalidade>Locação'], $base) . '<combustivel>x</combustivel>';
    $r = ImportadorXml::processar($xmlUm(str_replace('<combustivel>flex</combustivel>', '<combustivel>Elétrico</combustivel>', str_replace(['<cambio>manual', '<finalidade>locacao'], ['<cambio>Automático', '<finalidade>Locação'], $base))));
    return $r['erros'] === [] && $r['veiculos'][0]['cambio'] === 'automatico' && $r['veiculos'][0]['finalidade'] === 'locacao' && $r['veiculos'][0]['combustivel'] === 'eletrico';
});
t('XML-03', 'lista todos os erros de uma vez e não importa nada', function () use ($xmlUm, $base) {
    $x = '<?xml version="1.0"?><veiculos><veiculo>' . str_replace('<preco>95,00</preco>', '<preco>0</preco>', $base) . '</veiculo><veiculo>' . str_replace(['<ano>2022</ano>', '<categoria>hatch</categoria>'], ['<ano>1800</ano>', '<categoria>buggy</categoria>'], $base) . '</veiculo></veiculos>';
    $r = ImportadorXml::processar($x);
    return $r['veiculos'] === [] && count($r['erros']) === 3 && str_contains($r['erros'][0], 'Veículo 1') && str_contains($r['erros'][2], 'Veículo 2');
});
t('XML-04', 'campo ausente, campo desconhecido e campo repetido são apontados', function () use ($xmlUm, $base) {
    $a = ImportadorXml::processar($xmlUm(str_replace('<modelo>Mobi</modelo>', '', $base)));
    $b = ImportadorXml::processar($xmlUm($base . '<prece>1</prece>'));
    $c = ImportadorXml::processar($xmlUm($base . '<ano>2020</ano>'));
    return str_contains($a['erros'][0], '<modelo>') && str_contains($b['erros'][0], 'desconhecido') && str_contains($c['erros'][0], 'repetido');
});
t('XML-05', 'XML mal formado, raiz errada e vazio são recusados com mensagem clara', fn() =>
    str_contains(ImportadorXml::processar('<veiculos><veiculo>')['erros'][0], 'mal formado')
    && str_contains(ImportadorXml::processar('<carros/>')['erros'][0], '<veiculos>')
    && str_contains(ImportadorXml::processar('<veiculos/>')['erros'][0], 'Nenhum')
    && ImportadorXml::processar('   ')['erros'] !== []);
t('XML-06', 'segurança: DOCTYPE/ENTITY (XXE), arquivo grande e mais de 100 veículos são recusados', function () use ($xmlUm, $base) {
    $xxe = '<?xml version="1.0"?><!DOCTYPE v [<!ENTITY x SYSTEM "file:///etc/passwd">]><veiculos><veiculo><marca>&x;</marca></veiculo></veiculos>';
    $muitos = '<?xml version="1.0"?><veiculos>' . str_repeat('<veiculo>' . $base . '</veiculo>', 101) . '</veiculos>';
    return str_contains(ImportadorXml::processar($xxe)['erros'][0], 'DOCTYPE')
        && str_contains(ImportadorXml::processar(str_repeat('a', ImportadorXml::MAX_BYTES + 1))['erros'][0], '1 MB')
        && str_contains(ImportadorXml::processar($muitos)['erros'][0], 'máximo');
});
t('XML-07', 'valor por hora é ignorado na venda e validado na locação', function () use ($xmlUm, $base) {
    $venda = str_replace('<finalidade>locacao</finalidade>', '<finalidade>venda</finalidade>', $base) . '<preco_hora>10</preco_hora>';
    $ruim = $base . '<preco_hora>abc</preco_hora>';
    return ImportadorXml::processar($xmlUm($venda))['veiculos'][0]['preco_hora'] === '' && ImportadorXml::processar($xmlUm($ruim))['erros'] !== [];
});

t('FOTO-01', 'envio múltiplo de fotos é normalizado e campos vazios são ignorados', function () {
    require_once ROOT . '/app/core/Upload.php';
    $f = ['name' => ['a.png', '', 'b.jpg'], 'type' => ['image/png', '', 'image/jpeg'], 'tmp_name' => ['/tmp/a', '', '/tmp/b'],
          'error' => [0, UPLOAD_ERR_NO_FILE, 0], 'size' => [10, 0, 20]];
    $l = Upload::normalizarMultiplos($f);
    return count($l) === 2 && $l[1]['name'] === 'b.jpg' && $l[1]['size'] === 20 && Upload::normalizarMultiplos(null) === [] && Upload::normalizarMultiplos(['name' => 'x']) === [];
});

echo "\n$ok aprovados, " . count($falhas) . " falhas\n";
exit($falhas ? 1 : 0);
