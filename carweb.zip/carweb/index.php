<?php
// Na raiz do projeto apenas redireciona: o site público fica em public/.
header('Location: public/');
exit;
