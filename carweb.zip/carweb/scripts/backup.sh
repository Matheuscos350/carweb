#!/usr/bin/env bash
# Backup diário do banco. Credenciais: ~/.my.cnf (seção [client]) ou variáveis de ambiente.
set -euo pipefail
DESTINO="${CARWEB_BACKUP_DIR:-$(dirname "$0")/../backups}"
mkdir -p "$DESTINO"
ARQ="$DESTINO/carweb_$(date +%Y%m%d).sql"
mysqldump --single-transaction --routines --default-character-set=utf8mb4 \
  -u "${CARWEB_DB_USER:-carweb_app}" ${CARWEB_DB_PASS:+-p"$CARWEB_DB_PASS"} carweb > "$ARQ"
chmod 600 "$ARQ"
find "$DESTINO" -name 'carweb_*.sql' -mtime +30 -delete
echo "Backup gerado: $ARQ"
