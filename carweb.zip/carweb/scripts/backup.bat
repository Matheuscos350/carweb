@echo off
rem Backup do banco no XAMPP. Ajuste o caminho se necessario.
set DEST=%~dp0..\backups
if not exist "%DEST%" mkdir "%DEST%"
set DATA=%date:~6,4%%date:~3,2%%date:~0,2%
C:\xampp\mysql\bin\mysqldump.exe --single-transaction -u root carweb > "%DEST%\carweb_%DATA%.sql"
echo Backup gerado em %DEST%\carweb_%DATA%.sql
