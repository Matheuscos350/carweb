-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 20/11/2026 às 03:25
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `carweb`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `favoritos`
--

CREATE TABLE `favoritos` (
  `id` int(10) UNSIGNED NOT NULL,
  `usuario_id` int(10) UNSIGNED NOT NULL,
  `veiculo_id` int(10) UNSIGNED NOT NULL,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `interesses`
--

CREATE TABLE `interesses` (
  `id` int(10) UNSIGNED NOT NULL,
  `veiculo_id` int(10) UNSIGNED NOT NULL,
  `usuario_id` int(10) UNSIGNED NOT NULL,
  `mensagem` varchar(300) DEFAULT NULL,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `interesses`
--

INSERT INTO `interesses` (`id`, `veiculo_id`, `usuario_id`, `mensagem`, `criado_em`) VALUES
(1, 2, 2, 'Olá, tenho interesse no veiculo', '2026-11-20 02:18:56');

-- --------------------------------------------------------

--
-- Estrutura para tabela `reservas`
--

CREATE TABLE `reservas` (
  `id` int(10) UNSIGNED NOT NULL,
  `veiculo_id` int(10) UNSIGNED NOT NULL,
  `usuario_id` int(10) UNSIGNED NOT NULL,
  `modalidade` enum('dia','hora') NOT NULL DEFAULT 'dia',
  `data_retirada` datetime NOT NULL,
  `data_devolucao` datetime NOT NULL,
  `valor_total` decimal(12,2) NOT NULL,
  `nome_locatario` varchar(120) NOT NULL,
  `tipo_documento` enum('cpf','cnh') NOT NULL,
  `documento` varchar(11) NOT NULL,
  `status` enum('pendente','confirmada','cancelada','concluida') NOT NULL DEFAULT 'pendente',
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp()
) ;

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(10) UNSIGNED NOT NULL,
  `nome` varchar(120) NOT NULL,
  `email` varchar(160) NOT NULL,
  `senha_hash` varchar(255) NOT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  `perfil` enum('cliente','anunciante','loja','administrador') NOT NULL DEFAULT 'cliente',
  `ativo` tinyint(1) NOT NULL DEFAULT 1,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `email`, `senha_hash`, `telefone`, `perfil`, `ativo`, `criado_em`) VALUES
(1, 'Tcar motors', 'tcarmotors@gmail.com', '$2y$10$7qDS7VJHPA58drBXcngAAOgNp09PiPk4jVURVzzdSM.lb8jzT3wpC', '11961814273', 'loja', 1, '2026-11-18 19:51:34'),
(2, 'Matheus Costa Machado', 'matheusmachado@gmail.com', '$2y$10$VHJXuwb6h5w9f7nV6Mb9EOOr20e8ZgaRw9DYjWnoquLD/Ig3nBn46', '11961812135', 'cliente', 1, '2026-11-20 02:17:45');

-- --------------------------------------------------------

--
-- Estrutura para tabela `veiculos`
--

CREATE TABLE `veiculos` (
  `id` int(10) UNSIGNED NOT NULL,
  `anunciante_id` int(10) UNSIGNED NOT NULL,
  `finalidade` enum('venda','locacao') NOT NULL,
  `marca` varchar(60) NOT NULL,
  `modelo` varchar(80) NOT NULL,
  `ano` smallint(5) UNSIGNED NOT NULL,
  `quilometragem` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `categoria` enum('hatch','sedan','suv') NOT NULL,
  `cambio` enum('manual','automatico') NOT NULL,
  `lugares` tinyint(3) UNSIGNED NOT NULL DEFAULT 5,
  `combustivel` enum('flex','gasolina','etanol','diesel','eletrico','hibrido') NOT NULL DEFAULT 'flex',
  `descricao` varchar(1000) DEFAULT NULL,
  `preco` decimal(12,2) NOT NULL,
  `preco_hora` decimal(10,2) DEFAULT NULL,
  `status` enum('disponivel','reservado','alugado','vendido','inativo') NOT NULL DEFAULT 'disponivel',
  `imagem` varchar(60) DEFAULT NULL,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp()
) ;

--
-- Despejando dados para a tabela `veiculos`
--

INSERT INTO `veiculos` (`id`, `anunciante_id`, `finalidade`, `marca`, `modelo`, `ano`, `quilometragem`, `categoria`, `cambio`, `lugares`, `combustivel`, `descricao`, `preco`, `preco_hora`, `status`, `imagem`, `criado_em`) VALUES
(1, 1, 'venda', 'NISSAN', 'KICKS PLAY', 2025, 0, 'suv', 'automatico', 5, 'flex', 'Ar quente\r\nBanco com regulagem de altura\r\nComputador de bordo\r\nControle de tração\r\nDesembaçador traseiro\r\nAr condicionado\r\nFreio ABS\r\nLimpador traseiro\r\nRodas de liga leve\r\nSensor de chuva\r\nSensor de estacionamento\r\nTravas elétricas\r\nVidros elétricos\r\nVolante com regulagem de altura\r\nBancos em couro\r\nDireção hidráulica\r\nDireção com Ajuste\r\nChave Inteligente/Presencial\r\nBotão de Ignição/Start button\r\nAlarme com acionamento a distância\r\nFreios ABS com EBD\r\nFreios ABS com BAS\r\nControle de estabilidade\r\nAlerta de colisão\r\nTela Multimídia\r\nEspelhamento com Smartphone\r\nUSB\r\nBluetooth', 135000.00, NULL, 'disponivel', 'bce532e23ec19d417bfea41f2723064e.jpg', '2026-11-18 20:11:55'),
(2, 1, 'venda', 'NISSAN', 'KICKS PLAY', 2025, 0, 'suv', 'automatico', 5, 'flex', 'Ar quente\r\nBanco com regulagem de altura\r\nComputador de bordo\r\nControle de tração\r\nDesembaçador traseiro\r\nAr condicionado\r\nFreio ABS\r\nLimpador traseiro\r\nRodas de liga leve\r\nSensor de chuva\r\nSensor de estacionamento\r\nTravas elétricas\r\nVidros elétricos\r\nVolante com regulagem de altura\r\nBancos em couro\r\nDireção hidráulica\r\nDireção com Ajuste\r\nChave Inteligente/Presencial\r\nBotão de Ignição/Start button\r\nAlarme com acionamento a distância\r\nFreios ABS com EBD\r\nFreios ABS com BAS\r\nControle de estabilidade\r\nAlerta de colisão\r\nTela Multimídia\r\nEspelhamento com Smartphone\r\nUSB\r\nBluetooth', 130000.00, NULL, 'disponivel', '53f8da3ec6141dd094db764a55bdbf86.jpg', '2026-11-18 20:14:20'),
(3, 1, 'locacao', 'AUDI', 'Q5', 2025, 0, 'suv', 'automatico', 5, 'gasolina', 'Direção com Ajuste\r\nComputador de Bordo\r\nChave Inteligente/Presencial\r\nBotão de Ignição/Start button\r\nAjuste retrovisor elétrico\r\nAlarme com acionamento a distância\r\nFreios ABS com EBD\r\nFreios ABS com BAS\r\nControle de estabilidade\r\nAlerta de colisão\r\nSensor de ponto cego\r\nSensor de pressão dos pneus\r\nFaróis Full LED\r\nTela Multimídia\r\nEspelhamento com Smartphone\r\nBluetooth\r\nCarregador de smartphone por Indução', 250.00, NULL, 'disponivel', '7418bf5e1e203d24dbfb908ba8cf56ec.jpg', '2026-11-20 01:20:54'),
(4, 1, 'locacao', 'VOLKSWAGEN', 'T-CROSS', 2023, 18000, 'suv', 'automatico', 5, 'flex', 'Airbag\r\nDireção com Ajuste\r\nComputador de Bordo\r\nChave Inteligente/Presencial\r\nBotão de Ignição/Start button\r\nAjuste retrovisor elétrico\r\nAlarme com acionamento a distância\r\nFreios ABS com EBD\r\nFreios ABS com BAS\r\nControle de estabilidade\r\nSensor de ponto cego\r\nSensor de pressão dos pneus\r\nFaróis Full LED\r\nTela Multimídia\r\nEspelhamento com Smartphone\r\nUSB\r\nBluetooth', 150.00, NULL, 'disponivel', 'bd2cd3c6ff24dd8e16c9eef8223ed45e.jpg', '2026-11-20 01:32:33'),
(5, 1, 'locacao', 'MINI', 'COOPER', 2025, 0, 'hatch', 'automatico', 5, 'flex', 'Teto solar\r\nDireção com Ajuste\r\nComputador de Bordo\r\nChave Inteligente/Presencial\r\nBotão de Ignição/Start button\r\nAlarme com acionamento a distância\r\nFreios ABS com EBD\r\nFreios ABS com BAS\r\nControle de estabilidade\r\nAssistente de mudança de faixa\r\nAlerta de colisão\r\nSensor de ponto cego\r\nSensor de pressão dos pneus\r\nFaróis Full LED\r\nTela Multimídia\r\nEspelhamento com Smartphone\r\nUSB', 200.00, NULL, 'disponivel', 'c39df9c68d1b994b06e59ce4e3483848.jpg', '2026-11-20 01:49:19');

-- --------------------------------------------------------

--
-- Estrutura para tabela `veiculo_fotos`
--

CREATE TABLE `veiculo_fotos` (
  `id` int(10) UNSIGNED NOT NULL,
  `veiculo_id` int(10) UNSIGNED NOT NULL,
  `arquivo` varchar(60) NOT NULL,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `veiculo_fotos`
--

INSERT INTO `veiculo_fotos` (`id`, `veiculo_id`, `arquivo`, `criado_em`) VALUES
(1, 1, '8846423514e892f24bf597eace450065.jpg', '2026-11-18 20:11:55'),
(2, 1, '3f7a86bf093dc3685cf3eebc1bceee05.jpg', '2026-11-18 20:11:55'),
(3, 1, '1b6fa853d628c9b35234ba557677809a.jpg', '2026-11-18 20:11:55'),
(4, 2, '92043b48704172117103646700bc45f7.jpg', '2026-11-18 20:14:20'),
(5, 2, '6254e33955863aa8c47785e81d18e8ee.jpg', '2026-11-18 20:14:20'),
(6, 2, '8fe9603b931800fa9035f06a119e6397.jpg', '2026-11-18 20:14:20'),
(7, 2, '706edadc80ed0d389572e4d1ee3b606c.jpg', '2026-11-18 20:14:20'),
(8, 2, 'f3638ca10f2296729b30e3a7674f8796.jpg', '2026-11-18 20:14:20'),
(9, 2, 'c54f739005c3ee1df9d324c179616f5c.jpg', '2026-11-18 20:14:20'),
(10, 3, 'ec673a7325876d59215a629c5ff8e2e2.jpg', '2026-11-20 01:20:54'),
(11, 3, '73d85fdc71dcd5ff4e53a89115718585.jpg', '2026-11-20 01:20:54'),
(12, 4, 'bebf0767684fc2058c634d7cb39e028b.jpg', '2026-11-20 01:32:33'),
(13, 4, '4df7ff6e23f5eb744e8042d3694e7c56.jpg', '2026-11-20 01:32:33'),
(14, 4, 'c5c6f5bbf28f6d5dbf24ea683fc1b6bf.jpg', '2026-11-20 01:32:33'),
(15, 5, 'a75cc9cae62f6fe720ce193b08add674.jpg', '2026-11-20 01:49:19'),
(16, 5, '8cddd1445023b00f52f49024b7b05d12.jpg', '2026-11-20 01:49:19'),
(17, 5, '754028aca23285f31d162911e9b59705.jpg', '2026-11-20 01:49:19'),
(18, 5, 'fdbd9f2a8847e65ceb2faab5448c6ee5.jpg', '2026-11-20 01:49:19');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `favoritos`
--
ALTER TABLE `favoritos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_favorito` (`usuario_id`,`veiculo_id`),
  ADD KEY `fk_fav_veiculo` (`veiculo_id`);

--
-- Índices de tabela `interesses`
--
ALTER TABLE `interesses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_interesse` (`veiculo_id`,`usuario_id`),
  ADD KEY `fk_interesses_usuario` (`usuario_id`);

--
-- Índices de tabela `reservas`
--
ALTER TABLE `reservas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ix_reservas_periodo` (`veiculo_id`,`status`,`data_retirada`,`data_devolucao`),
  ADD KEY `ix_reservas_usuario` (`usuario_id`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_usuarios_email` (`email`);

--
-- Índices de tabela `veiculos`
--
ALTER TABLE `veiculos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ix_veiculos_busca` (`status`,`finalidade`,`categoria`,`preco`),
  ADD KEY `ix_veiculos_marca` (`marca`,`modelo`),
  ADD KEY `ix_veiculos_anunciante` (`anunciante_id`);

--
-- Índices de tabela `veiculo_fotos`
--
ALTER TABLE `veiculo_fotos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ix_fotos_veiculo` (`veiculo_id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `favoritos`
--
ALTER TABLE `favoritos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `interesses`
--
ALTER TABLE `interesses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `reservas`
--
ALTER TABLE `reservas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `veiculos`
--
ALTER TABLE `veiculos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `veiculo_fotos`
--
ALTER TABLE `veiculo_fotos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `favoritos`
--
ALTER TABLE `favoritos`
  ADD CONSTRAINT `fk_fav_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_fav_veiculo` FOREIGN KEY (`veiculo_id`) REFERENCES `veiculos` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `interesses`
--
ALTER TABLE `interesses`
  ADD CONSTRAINT `fk_interesses_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `fk_interesses_veiculo` FOREIGN KEY (`veiculo_id`) REFERENCES `veiculos` (`id`);

--
-- Restrições para tabelas `reservas`
--
ALTER TABLE `reservas`
  ADD CONSTRAINT `fk_reservas_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `fk_reservas_veiculo` FOREIGN KEY (`veiculo_id`) REFERENCES `veiculos` (`id`);

--
-- Restrições para tabelas `veiculos`
--
ALTER TABLE `veiculos`
  ADD CONSTRAINT `fk_veiculos_anunciante` FOREIGN KEY (`anunciante_id`) REFERENCES `usuarios` (`id`);

--
-- Restrições para tabelas `veiculo_fotos`
--
ALTER TABLE `veiculo_fotos`
  ADD CONSTRAINT `fk_fotos_veiculo` FOREIGN KEY (`veiculo_id`) REFERENCES `veiculos` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
